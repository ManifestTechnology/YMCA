'use strict';

// Declare app level module which depends on filters, and services
angular.module('sweepstakes', ['sweepstakes.filters', 'sweepstakes.services', 'sweepstakes.directives']).
  config(['$routeProvider', function ($routeProvider) {
  	  $routeProvider.when('/loading', { templateUrl: 'partials/loading.html', controller: LoadingController });
  	  $routeProvider.when('/introduction', { templateUrl: 'partials/introduction.html', controller: IntroController });
  	  $routeProvider.when('/rules', { templateUrl: 'partials/rules.html', controller: RulesController });
      $routeProvider.when('/fangate', { templateUrl: 'partials/fangate.html', controller: FanGateController });
      $routeProvider.when('/entryform', { templateUrl: 'partials/entryform.html', controller: FormController });
      $routeProvider.when('/returningLanding', { templateUrl: 'partials/return.html', controller: ReturningLandingController });
      $routeProvider.when('/gallery', { templateUrl: 'partials/galleryList.html', controller: GalleryPageController });
      $routeProvider.when('/galleryDetail/:photoId', { templateUrl: 'partials/galleryDetail.html', controller: GalleryDetailController });
      $routeProvider.when('/thankyou', { templateUrl: 'partials/thankyou.html', controller: ThankYouController });
      $routeProvider.when('/timeout', { templateUrl: 'partials/timeout.html', controller: TimeOutController });
      $routeProvider.when('/winner', { templateUrl: 'partials/winner.html', controller: WinningController });

      $routeProvider.otherwise({ redirectTo: '/loading' });
  }]);