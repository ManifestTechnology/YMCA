'use strict';

/* Controllers */

function LoadingController($scope, $window, facebook, $http) {
	facebook.scrollToTop();
	facebook.setHeight( 824 );
	$http.get("/api/application/" + facebook.appID).success(function (applicationData, status, headers, config) {
		facebook.checkLoginStatus(function(loginData) {
    		if (loginData.status !== "connected") {
				// needs to authorize app
    			facebook.authorize(function (response) {
    				top.location.href = "https://www.facebook.com/" + applicationData.pageTabName + "/app_" + facebook.appID;
    			});
			} else {
				// connected. Get the app's facebook tab page (for fangate)
    			facebook.get("/me/likes/" + applicationData.pageTabId, function (apiResponse) {
    				if (apiResponse.data) {
	    				if (apiResponse.data.length == 0) {
	    					// no likey. Show fangate
	    					$window.location.href = "#/fangate";
	    				} else {
							// use the access token to check for a previous entry
							$http.get("/api/entry/" + loginData.authResponse.accessToken).success(function (entryData, status, headers, config) {
								if (entryData.length > 0) {
									// the user has an entry. Take them to the reentry page
									$window.location.href = "#/returningLanding";
								} else {
									// the user does NOT have an entry. Take them to the intro page
			    					$window.location.href = "#/introduction";
								}
							});
	    				}
	    			} else {
    					$window.location.href = "#/fangate";
    				}
				});
    		}
		});
    });
}

function FormController($scope, facebook, $location, $http) {
	facebook.scrollToTop();
	facebook.setHeight( 1064 );

    $scope.save = function (user) {
    	facebook.checkLoginStatus(function (response) {
    		$scope.user.authToken = response.authResponse.accessToken;
    		$scope.user.field.submissioncount = "1";
    		// Email address should only be entered the first time
			var data = {
			    accessToken : response.authResponse.accessToken,
			    emailAddress: $scope.user.field.email,
			    listID: "7128723dd4",
			    fields: {
			        FNAME: $scope.user.field.firstname,
			        LNAME: $scope.user.field.lastname,
			        CAMPAIGN: "Send A Smile Sweepstakes"
			    }
			};
			if( $scope.user.field.specialOffer ){
				$http.post("/api/mailchimp", data).success(function(data) {
				    console.log(data);
				});
			}
    		$http.post("/api/entry", $scope.user).success(function (data, status, headers, config) {
    			$location.path('/thankyou');
    		});
    	});
    }
    $scope.validate = function (user) {
    }
}

function RulesController($scope, facebook, $http) {
	var markdown = new MarkdownDeep.Markdown();
	$http.get("/api/variable/" + facebook.appID).success(function (data, status, headers, config) {
		for (var i = 0; i < data.length; i++) {
			if (data[i].name == "AppRules") {
				$scope.rules = markdown.Transform(data[i].value);
				break;
			}
		}
	});
}

function IntroController($scope, $window, facebook, $http) {
	facebook.scrollToTop();
	facebook.setHeight( 1358 );
}

function GalleryListController($scope, $window, facebook, $http, $timeout, $route) {
	$scope.backToGallery = function() { $window.location.href = "#/gallery"; }
	
	$scope.loadEntryForm = function() {
		facebook.checkLoginStatus(function(loginData) {
			$http.get("/api/component/" + facebook.appID).success(function (appData, status, headers, config) {
				$http.get("/api/entry/" + loginData.authResponse.accessToken).success(function (entryData, status, headers, config) {
					if (entryData.length > 0) {
						$window.location.href = "#/returningLanding";
					} else {
						$window.location.href = "#/entryform";
					}
				});
			});
		});
	}
	
	var instagramApi = 'https://api.instagram.com/v1/';
	var instagramDefaultVars = '?callback=JSON_CALLBACK';
	var instagramRecentCall = 'tags/honeybunchesofsmiles/media/recent';
	var instagramCountCall = 'tags/honeybunchesofsmiles';

	$scope.currentPage = 0;
	$scope.pageSize = 12;
	
	var instagramUrl = instagramApi;
	$scope.apiResults = [];
	
	$scope.getPhotoCount = function() {
		instagramUrl = instagramApi + instagramCountCall + instagramDefaultVars;
		$http.jsonp(instagramUrl).success( function( data ) {
			$scope.photo_count = data.data.media_count;
			$scope.loadPhotoSet();
		}).error( function() {
			$scope.photo_count = 0;
			$scope.loadPhotoSet();
		});
	}
	
	$scope.range = function (start, end){
		var ret = [];
		if(!end){
			end = start;
			start = 0;
		}
		for (var i=start; i<end; i++){
			ret.push(i);
		}
		return ret;
	};
		
	$scope.loadPhotoSet = function() {
		instagramUrl = instagramApi + instagramRecentCall + instagramDefaultVars;
		delete $scope.photos;
		$scope.loadingClass = 'loading';
		$scope.pageLinks = [];
		
		$scope.getPhotosFromApi(instagramUrl + "&count=" + $scope.photo_count);
		
	}
	
	$scope.getPhotosFromApi = function( givenUrl ) {
		$http.jsonp( givenUrl ).success( function( data ) {
	
			$scope.apiResults = $scope.apiResults.concat( data.data );
			
			if ( ( data.pagination.next_url != '' ) && ( data.pagination.next_url ) ) {
				var position_of_id = data.pagination.next_url.indexOf("&client_id");
				var queryParameters = data.pagination.next_url.substr( position_of_id );

				$scope.getPhotosFromApi( instagramApi + instagramRecentCall + instagramDefaultVars + queryParameters );
			}
			else {
				$scope.removeFlaggedPhotos( $scope.apiResults );
			}
			
		}).error( function() {
			// Do nothing on error
		});
	}
	
	$scope.removeFlaggedPhotos = function(photos) {
		facebook.checkLoginStatus(function(loginData) {
			$http.get("/api/flaggeditem/getflaggeditems?accessToken=" + loginData.authResponse.accessToken).success(function (data) {
				var flaggedList = new Array();
				var flaggedListStr = "";
				var filteredPhotos = new Array();
				
				for (var i = 0; i < data.length; i++) {
					flaggedList.push(data[i].value);
					flaggedListStr += "," + data[i].value;
				}
				//shouldn't assume we have black-list entries
				//if(flaggedList.length > 0){
					for (var j = 0; j < photos.length; j++) {
						if(flaggedListStr.indexOf(photos[j].id)==-1){
							filteredPhotos.push(photos[j]);
						}
					}
				//}
//				$scope.flaggedList = flaggedList;
				$scope.photos = filteredPhotos;
				$scope.true_photo_count = $scope.photos.length;
				$scope.page_count = Math.ceil($scope.photos.length/$scope.pageSize);
				$scope.flagged_items = data.length;
			}).error( function() {
				$scope.true_photo_count = $scope.photos.length;
				$scope.page_count = Math.ceil($scope.photos.length/$scope.pageSize);
				$scope.flagged_items = 20;
			});
		});
	}
	
    $scope.prevPage = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };
    
    $scope.nextPage = function () {
        if ($scope.currentPage < $scope.page_count - 1) {
            $scope.currentPage++;
        }
    };
	$scope.setPage = function () {
        $scope.currentPage = this.n;
    };

	// Fetch images
	$http.get("/api/variable/" + facebook.appID).success(function (data, status, headers, config) {
		for (var i = 0; i < data.length; i++) {
			if (data[i].name == "InstagramAPIKey") {
				instagramDefaultVars = instagramDefaultVars + '&client_id='+data[i].value;
				$timeout( $scope.getPhotoCount );
			}
		}
	});

}

function GalleryPageController($scope, facebook, $http) {
	facebook.scrollTo(0,550);
	facebook.setHeight( 1614 );
}

function GalleryDetailController($scope, facebook, $routeParams) {
	facebook.scrollTo(0,430);
	facebook.setHeight( 1400 );
	$scope.photoId = $routeParams.photoId;
}

function FanGateController($scope, facebook) {
	facebook.scrollToTop();
	facebook.setHeight( 824 );
}

function ThankYouController($scope, $window, facebook) {
	facebook.scrollToTop();
	facebook.setHeight( 981 );
    $scope.backToGallery = function() { $window.location.href = "#/gallery"; }
}

function ReturningLandingController($scope, facebook, $http, $window, $location) {
	facebook.scrollToTop();
	facebook.setHeight( 2090 );
	$scope.submissioncount = "...";
	// use the access token to check for a previous entry
	facebook.checkLoginStatus(function(loginData) {
		$http.get("/api/component/" + facebook.appID).success(function (appData, status, headers, config) {
			if (appData.entryTimeout) {
		    	$scope.authToken = loginData.authResponse.accessToken;
				$http.get("/api/entry/" + $scope.authToken).success(function (entryData, status, headers, config) {
					if (entryData.length > 0) {
						entryDetails = entryData[0];
						var parts = entryData[0].created.split("T");
						var dateParts = parts[0].split("-");
						var timeParts = parts[1].split(":");
						var lastEntryDate = new Date(dateParts[0], dateParts[1] - 1, dateParts[2], timeParts[0], timeParts[1], timeParts[2]);
						var nextEntryDate = new Date(lastEntryDate.getTime() + appData.entryTimeout * 60000);
						var entryDetails = {};
						$scope.submissioncount = entryData.length;
						for (var m = 0; m < entryData.length; m++) {
							if(entryData[m].fields.length > 0){
								entryDetails = entryData[m];
							}
						}
		
						// Has the user waited long enough for the timeout to pass?
						if (new Date() < nextEntryDate) {
							$scope.resubmitAllowed = false;
						} else {
							$scope.resubmitAllowed = true;
							$scope.user = { field : {} };
							
							$scope.fieldStr = '';
							for (var k = 0; k < entryDetails.fields.length; k++) {
								switch(entryDetails.fields[k]["field"])
								{
								case "firstname":
								  $scope.user.field.firstname = entryDetails.fields[k]["value"];
								  break;
								case "lastname":
								  $scope.user.field.lastname = entryDetails.fields[k]["value"];
								  break;
								case "instagramid":
								  $scope.user.field.instagramid = entryDetails.fields[k]["value"];
								  break;
								case "email":
								  $scope.user.field.email = entryDetails.fields[k]["value"];
								  break;
								case "specialOffer":
								  $scope.user.field.specialOffer = entryDetails.fields[k]["value"];
								  break;
								case "acceptRules":
								  $scope.user.field.acceptRules = entryDetails.fields[k]["value"];
								  break;
								case "submissioncount":
								  $scope.user.field.submissioncount = entryDetails.fields[k]["value"];
								  break;
								default:
								  break;
								}
							}
						}
						$scope.datecheck = new Date().toString() + ',' + nextEntryDate;
					} else {
						$scope.resubmitAllowed = false;
					}
				});
			}
		});
	});

	$scope.sorry = function () {
		/* Sorry Modal */
		$.fancybox(
		'<h2>We\'re sorry,</h2><p>but it appears you have already submitted an entry today. Entries are limited to once per day - but come back tomorrow to increase your chances of winning!</p>',
		{
        	'autoDimensions'	: false,
			'width'         	: 604,
			'height'        	: 320,
			'padding'			: [10, 10, 40, 10],
			'showCloseButton'	: true,
			'transitionIn'		: 'none',
			'transitionOut'		: 'none'
		});		
	}

    $scope.save = function (user) {
    	if(!$scope.resubmitAllowed){
    		$scope.sorry();
    	}else{
	    	facebook.checkLoginStatus(function (response) {
	    		$scope.user.authToken = response.authResponse.accessToken;
	    		$scope.user.field.submissioncount = "1";
	    		$http.post("/api/entry", $scope.user).success(function (data, status, headers, config) {
	    			$location.path('/thankyou');
	    		});
	    	});
    	}
    }
}

function TimeOutController($scope) {}

function WinningController($scope, facebook) {
	facebook.scrollToTop();
	facebook.setHeight( 2300 );
}