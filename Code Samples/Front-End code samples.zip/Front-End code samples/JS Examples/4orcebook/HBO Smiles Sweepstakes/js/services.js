'use strict';

/* Services */

angular.module('sweepstakes.services', [], function ($provide) {
    $provide.factory('facebook', function ($http) {
        // EDIT THIS VARIABLE /////////////////////////////////////////////////
		var _appID = '190745654400147';
        ///////////////////////////////////////////////////////////////////////

        FB.init({
        	appId: _appID,
        	channelUrl: "/fbchannel.ashx",
            status: false,
            cookie: true,
            xfbml: false,
            oauth: true
        });

        return {
            /** Global FB Application ID **/
            appID: _appID,

            /**
             * Gets the login status of the user.
             * Calls a passed-in callback function when the check is complete.
             */
            checkLoginStatus: function (callback) {
                FB.getLoginStatus(function (response) {
                    callback(response);
                });
            },

            /**
             * Shows auth dialog to the user.
             * Calls an optional passed-in callback function when the authorization is complete.
             */
            authorize: function (callback) {
                // Get the Applications permissions from the 4ORCEBook API
            	$http({ method:"GET", url:"/api/application/" + _appID }).success(function (data, status, headers, config) {
                    // Once the service returns, pass the "appPermissions" property to the login form
                	FB.login(function (response) {
                		if (callback) {
                			callback(response);
                		}
                    }, {scope: data.facebookPermissions});
                });
            },

        	/**
			 * Executes a Facebook Graph API call.
			 * Calls a passed-in callback function when the FB API call returns, passing it the response.
			 */
            get: function (query, callback) {
            	FB.api(query, function (response) {
            		callback(response);
            	});
            },

        	/**
			 * Sets the height of the canvas.
			 */
            setHeight: function (height) {
            	FB.Canvas.setSize({ height: height });
            },

        	/**
			 * Scrolls the user to wahtever x,y on the canvas.
			 */
            scrollTo: function (x, y) {
            	FB.Canvas.scrollTo(x, y);
            },

        	/**
			 * Scrolls the user to the top of the canvas.
			 * You will probably need to call this method in your controllers, especially after coming
			 * from a long page (such as a form) to a shorter page (confirmation).
			 */
            scrollToTop: function () {
            	FB.Canvas.scrollTo(0, 0);
            },
        }
    });
});
