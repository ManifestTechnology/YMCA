'use strict';

/* Filters */

angular.module('sweepstakes.filters', []).
  filter('interpolate', ['version', function(version) {
    return function(text) {
      return String(text).replace(/\%VERSION\%/mg, version);
    }
  }]);
  
angular.module('sweepstakes.filters').
  filter('startFrom', function() {
    return function(input, start) {
    	if(angular.isDefined(input)){
    		start = +start; //parse to int
    		return input.slice(start);
    	}
    };
});
