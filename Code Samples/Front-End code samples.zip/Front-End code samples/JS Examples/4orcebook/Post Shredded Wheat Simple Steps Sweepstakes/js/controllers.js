'use strict';

/* Controllers */

function LoadingController($scope, $window, facebook, $http) {
	$http.get("/api/application/" + facebook.appID).success(function (applicationData, status, headers, config) {
		facebook.checkLoginStatus(function(loginData) {
    		if (loginData.status !== "connected") {
				// needs to authorize app
				facebook.authorize(function (response) {
    				top.location.href = "https://www.facebook.com/" + applicationData.pageTabName + "/app_" + facebook.appID;
    			});
			} else {
				// connected. Get the app's facebook tab page (for fangate)
    			facebook.get("/me/likes/" + applicationData.pageTabId, function (apiResponse) {
    				if (apiResponse.data.length == 0) {
    					// no likey. Show fangate
    					$window.location.href = "#/fangate";
    				} else {
    					// show form
    					$window.location.href = "#/entryForm";
    				}
				});
    		}
		});
    });
}

function FormController($scope, facebook, $location, $http, $window, $timeout) {
    
    //Uniform form validation across browsers
    $(function(){
    	$('form').h5Validate();
    });
    
    //Number of entries in the DB.
    var sweepstakers;
    //Auth Token for Photo Upload.
    var authToken;
    
    facebook.checkLoginStatus(function (loginData) {
		$http.get("/api/entry/" + loginData.authResponse.accessToken).success(function (entryData, status, headers, config) {
			if (entryData.length > 0) {
				// the user has an entry. Show the thankyou slider.
				$('.form-slider').addClass('vanish');
				$('.ty-slider').removeClass('vanish').addClass('hide');
				$('.toggle-btn').removeClass('hide');
				
				//IE ANIMATION
				if( $('html').hasClass('ie') ){
					
					$('.ty-slider').css("right", '-590px').animate({right: '-278px'}, 200);
					$('.grand-prize-btn').css("right", '-300px').animate({right: '0px'}, 200);
					$('.whiteout').fadeOut(0);
					$('.ty-slider, .whiteout').addClass('prep');
					
				}
				//IE ANIMATION
			} else {
				// the user does NOT have an entry. Show the form slider.
				$('.form-slider').removeClass('vanish');
				$('.ty-slider').addClass('vanish');
				$('.toggle-btn').addClass('hide');
				$scope.authToken = authToken = loginData.authResponse.accessToken;
				
				//IE ANIMATION
				if( $('html').hasClass('ie') ){
					
					$('.form-slider').css("right", '-300px');
					$('.form-slider').animate({right: '0px'}, 200);
					
				}
				//IE ANIMATION
			}
			
			//Change Grand Prize images after reaching threshold.
			$http.get("/api/application/" + facebook.appID).success(function (applicationData, status, headers, config) {
				$scope.sweepstakers = applicationData.entries;
				if($scope.sweepstakers > 3500){
		        	$('.grand-prize-locked').addClass('grand-prize-unlocked').removeClass('grand-prize-locked');
		        	$('.padlock').hide(0);
		        }
		    });
		});
	});
	
    $scope.save = function (user) {
    	facebook.checkLoginStatus(function (response) {

	    	$http.get("/api/entry/" + response.authResponse.accessToken).success(function (entryData, status, headers, config) {
				if (entryData.length > 0) {
					// prevents multiple entries via tabs or other browsers loaded with form.
					alert("Don't worry, you've already entered the sweepstakes! You only need to enter once.");
				} else {
					$scope.user.authToken = response.authResponse.accessToken;
					
					var mailChimp = {
					
						accessToken: response.authResponse.accessToken,
						listID: "7128723dd4",
						emailAddress: $scope.user.field.emailAddress,
						fields: {
							FNAME: $scope.user.field.firstName,
							LNAME: $scope.user.field.lastName,
							CAMPAIGN: "Simple Steps Sweepstakes"
						}
					}
					
					if( $scope.user.field.specialOffer ){
						$http.post("/api/mailchimp", mailChimp);
					}
					
					$http.post("/api/entry", $scope.user).success(function (data, status, headers, config) {
						$('.form-slider').addClass('vanish');
		    			$('.ty-slider').removeClass('vanish');
		    			$('.whiteout, .close-btn').removeClass('hide');
		    			$('.toggle-btn').removeClass('hide').removeClass('grand-prize-btn').addClass('prizes-btn');
		    			
		    			//IE ANIMATION
						if( $('html').hasClass('ie') ){
							
							$('.ty-slider').css("right", '-590px');
							$('.prizes-btn').css({"right": '-300px', "width":'245px'});
							$('.whiteout').fadeOut(0);
							$('.ty-slider, .whiteout').addClass('prep');
							$('.form-slider').animate({right: '-300px'}, 200);
							$('.ty-slider, .prizes-btn').animate({right: '0px'}, 200);
							$('.whiteout').fadeIn(250);
							
						}
						//IE ANIMATION
		    			
		    			facebook.scrollToTop();
		    			
		    			//ENTRY STATISTIC & ANIMATION
	    			 	$scope.meterAnimation( $scope.sweepstakers, 1 );
					});
				}
			});
		});
    }
    
    //Animation Event Broadcasting
    $scope.toggle = function() {
    	$scope.$broadcast('event:toggle');
    }
    
    //File Uploading
    var fileInput;  //remembers element to clear
    $scope.fileBrowser = function() {
    	$scope.$broadcast('event:fileBrowser');
    }
    
    $scope.clearFile = function(){
    	fileInput.val(null);
    	$scope.fileName = fileInput.val();
    }
    
    $scope.uploadImage = function(element){
    	$timeout( function(){ 
	    	$scope.$apply(function(){
		    	fileInput = $(element);
		    	var cleanName = fileInput.val().substring(fileInput.val().lastIndexOf('\\')+1);
		    	var ext = cleanName.substring(cleanName.lastIndexOf('.')+1);
		    	if( (ext == 'jpg') || (ext == 'jpeg') || (ext == 'png') || (ext == 'gif') ){
		    		$scope.fileName = cleanName;
			    	$scope.$broadcast('event:photo');
		    	} else {
			    	alert('Oops!  You forgot to choose an image.\n\nPlease use .jpg, .jpeg, .png, or .gif files.');	
			    }
		    });
	    });
    }
    $scope.uploadImageComplete = function() {
	    try{
			var c=$.parseJSON($("#UploadTarget").contents().find("#jsonResult")[0].innerHTML);
			
			if(!c.IsValid){
				alert(c.Message);
			}
		
		} catch(b) {}
    }
    $scope.formSubmit = function(){
    	$scope.$broadcast('event:form');
    }
    
    //IE specific hover animation
    $scope.ieMouseEnter = function() {
    	if( $('html').hasClass('ie') ){
			$('.prizes-btn').stop().animate({width:'255px'}, 200);
			$('.grand-prize-btn').stop().animate({width:'295px'}, 200);
    	}
    }
    $scope.ieMouseLeave = function() {
    	if( $('html').hasClass('ie') ){
			$('.prizes-btn').stop().animate({width:'245px'}, 200);
			$('.grand-prize-btn').stop().animate({width:'285px'}, 200);
    	}
    }
    
    //Share with friends
    $scope.shareClick = function(){
    	if( sweepstakers > 3500 ){
	    	facebook.share('You could win the Ultimate Walking Package!','I just entered the Post Shredded Wheat Simple Steps Sweepstakes for a chance to win The Ultimate Walking Package –a trip for two to the US National Park of your choice, a NordicTrack Incline Trainer X7i, and more. Now it’s your turn!');
	    } else {
	    	facebook.share('You could win the Ultimate Walking Package!','I just entered the Post Shredded Wheat Simple Steps Sweepstakes for a chance to win The Ultimate Walking Package –a NordicTrack Incline Trainer X7i, an iPod Touch with $50 iTunes gift card, and more. Now it’s your turn!');
	    }
    }
    
    //Link to external page in same window
    $scope.exit = function(url) {
    	top.location.href = url;
    }
    
    //Entry Meter Animation
    $scope.meterAnimation = function( entries, increment ){
			entries += increment;  //increment accounts for user's submission.
		var barNum = entries > 3500 ? 3500 : entries;
		var barHeight = Math.ceil(400 * (barNum/3500)) + 'px';
		$('.meter .bar').animate({height:barHeight}, 2000).css("overflow","visible");
		$({someValue: 0}).animate({someValue: entries}, {
		    duration: 2000,
		    step: function() { // called on every step
		        // Update the element's text with value:
		        $('#counter').text(Math.floor(this.someValue+1));
		    },
		    complete : function(){
		        $('#counter').text(entries);
		    }
		});
	}
}

function RulesController($scope, facebook, $http) {
	var markdown = new MarkdownDeep.Markdown();

	$http.get("/api/variable/" + facebook.appID).success(function (data, status, headers, config) {
		for (var i = 0; i < data.length; i++) {
			if (data[i].name == "AppRules") {
				$scope.rules = markdown.Transform(data[i].value);
				break;
			}
		}
	});
}

function FanGateController($scope) {}

function ThankYouController($scope) {}

function TimeOutController($scope) {}