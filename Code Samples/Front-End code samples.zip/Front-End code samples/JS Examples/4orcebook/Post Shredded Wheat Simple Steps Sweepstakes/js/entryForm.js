$(function(){
		
	$('form').h5Validate();

	//Regulate slider animations
	$('.ty-slider .close-btn').click(function(){
		$('.ty-slider').addClass('hide');
		$('.prizes-btn').addClass('grand-prize-btn').removeClass('prizes-btn');
		$('.ty-slider .close-btn').addClass('hide');
		$('.whiteout').removeClass('show');
	});
	$('.slider-ctrl').click(function(){
		$(this).toggleClass('prizes-btn')
			   .toggleClass('grand-prize-btn');
		$('.ty-slider, .ty-slider .close-btn').toggleClass('hide');
		$('.whiteout').toggleClass('show');
		//one-time animation for grand prize meter.
		if( $('.meter .bar').height() == '1' ){
			$('.meter .bar').animate({height:barHeight}, 1000).css("overflow","visible");
			$({someValue: 0}).animate({someValue: entryNum}, {
			    duration: 1000,
			    step: function() { // called on every step
			        // Update the element's text with value:
			        $('#counter').text(Math.floor(this.someValue+1));
			    },
			    complete : function(){
			        $('#counter').text(entryNum);
			    }
			});
		}
	});//
	
}); //document.ready