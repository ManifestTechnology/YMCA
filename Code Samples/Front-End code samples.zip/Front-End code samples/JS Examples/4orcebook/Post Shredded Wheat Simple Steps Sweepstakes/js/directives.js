'use strict';

/* Directives */


angular.module('sweepstakes.directives', []).
  directive('appVersion', ['version', function(version) {
    return function(scope, elm, attrs) {
      elm.text(version);
    };
  }]);
  
var app = angular.module('sweepstakes.directives', []);

//Toggle 'Thank You Slider' Open/Close
app.directive('toggle', function(facebook, $http){
	return function( scope, elem, attrs ){
		scope.$on('event:toggle', function(){
			$('.toggle-btn').toggleClass('prizes-btn')
				   			.toggleClass('grand-prize-btn');
			$('.ty-slider, .ty-slider .close-btn').toggleClass('hide');
			$('.whiteout').toggleClass('hide');;
			
			//IE ANIMATION
			if( $('html').hasClass('ie') ){
				
				if( $('.ty-slider, .whiteout').hasClass('prep') ){
				
					if( $('.ty-slider, .whiteout').hasClass('hide') ){
						$('.ty-slider').animate({right: '-278px'}, 200);
						$('.whiteout').fadeOut(250);
						$('.grand-prize-btn').stop().animate({width:'285px'}, 200);
					} else {
						$('.ty-slider').animate({right: '0px'}, 200);
						$('.whiteout').fadeIn(250);
					}
				} else {
					$('.ty-slider').css("right", '-278px');
					$('.whiteout').fadeOut(0);
					$('.ty-slider, .whiteout').addClass('prep');
					$('.ty-slider').animate({right: '0px'}, 200);
					$('.whiteout').fadeIn(250);
				}
				
			}
			//IE ANIMATION
			
			//one-time animation for grand prize meter.
			if( ($('.meter .bar').height() == 1) && ($('#counter').text() == '0') ){
				scope.meterAnimation( scope.sweepstakers, 0 );
			}
		});
	}
});

//Launch File Upload Input
app.directive('upload', function(){
	return function( scope, elem, attrs ){
		scope.$on('event:fileBrowser', function(){
			$('.upload input[type="file"]').click();
		});
	}
});

//Trigger Photo Form upload
app.directive('submitOn', function($timeout) {
    return {
        link: function(scope, elm, attrs) {
            scope.$on(attrs.submitOn, function() {
                //We can't trigger submit immediately, or we get $digest already in progress error :-[ (because ng-submit does an $apply of its own)
                $timeout(function() {
                	elm.trigger('submit');
                });
            });
        }
    };
});