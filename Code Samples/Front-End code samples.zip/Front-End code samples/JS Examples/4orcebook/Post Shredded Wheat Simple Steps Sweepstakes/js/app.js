'use strict';

// Declare app level module which depends on filters, and services
angular.module('sweepstakes', ['sweepstakes.filters', 'sweepstakes.services', 'sweepstakes.directives']).
  config(['$routeProvider', function ($routeProvider) {
  	  $routeProvider.when('/loading', 	{ templateUrl: 'partials/loading.html', controller: LoadingController });
      $routeProvider.when('/fangate', 	{ templateUrl: 'partials/fangate.html', controller: FanGateController });
      $routeProvider.when('/entryForm', { templateUrl: 'partials/entryForm.html', controller: FormController });

      $routeProvider.otherwise({ redirectTo: '/loading' });
  }]);