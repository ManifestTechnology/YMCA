// Globals
var didScroll = false;
var $scrollTrigger;
var $bodyPadding = 0;
var didYouKnowChartResized = false; // did-you-know chart resized

// Functions
function calculateScrollTrigger() {
	var $chapterPaging = $('.bottom-chapter-paging');
	$scrollTrigger = ( parseInt($chapterPaging.offset().top) + parseInt($chapterPaging.height()) - $(window).height() );
}

function hideFixedChapterNavigation() {
	var $scrollTop = $(document).scrollTop();
	var $fixedNavigation = $('.fixed-navigation');

	if ( $scrollTop >= $scrollTrigger ) {
		$fixedNavigation.addClass('is-hidden');
	}
	else {
		if ( $fixedNavigation.hasClass('is-hidden') ) {
			$fixedNavigation.removeClass('is-hidden');
		}
	}
}

function positionBackToTop() {
	var $backToTop = $('.back-to-top');

	if ( $backToTop.is(':visible') ) {
		var $containerOffset = Math.floor($('.container').offset().left);
		var $width = $backToTop.width();

		if ( $containerOffset > $width ) {
			$backToTop.css('right', ($containerOffset - $width));
		}
	}
}

function fixChapterBackground() {
	if ( !($('.js-bg-fix').length) ) {
		var $bgFixContainer = '<div class="js-bg-fix"></div>';
		var $documentWidth = $(document).width();
		var $containerWidth = $('main > .container').outerWidth();

		var $bgFixWidth = (($documentWidth - $containerWidth) / 2);
		$bgFixWidth += parseInt($('.main-content').outerWidth());
		$bgFixWidth += parseInt($('main > .container').css('padding-right'));

		$('main').append($bgFixContainer);
		$('.js-bg-fix').css({
			'height': $bodyPadding,
			'width': $bgFixWidth
		});
	}
}

function fixedHeader() {
	var $header = $('.nav-bar').parent('header');
	$bodyPadding = $header.height();
	$('main').css('padding-top', $bodyPadding);
	$header.addClass('fixed-header');

	if ( $('.chapter').length ) {
		fixChapterBackground();
	}
}

function reducedFixedHeader() {
	$('.nav-bar').animate({
		'padding-top': '14',
		'padding-bottom': '14'
	}, 150, function() {
		// Animation complete
	});
}

function fullFixedHeader() {
	$('.nav-bar').animate({
		'padding-top': '36',
		'padding-bottom': '36'
	}, 150, function() {
		// Animation complete
	});
}

function setVideoContainerWidths() {
	$('.video-container').each(function() {
		var $this = $(this);
		var $textHeight;

		// Text height
		setTimeout(function(){
			$textHeight = $this.find('p').outerHeight(true);
		}, 1);

		// Video Height
		var $video = $this.find('video');
		var $videoWidth = parseInt( $this.width() );
		var $videoHeight = Math.round(( ( 720 * $videoWidth ) / 1280 )); // Video is 1280x720
		$video.width( $videoWidth );
		$video.height( $videoHeight );

		var $height = $textHeight + $videoHeight;
		$this.css('height', $height);

		if ( !($this.hasClass('is-open')) ) {
			$(this).hide();
		}
	});
}

function displayPieChartLegend(fileName, chartID) {

	$.getJSON( fileName, function( data ) {
		var listItems = [];
		$.each( data, function( key, val ) {			
			if ( val[1] !== 0 ) {
				var className = val[0].split(" ").join('-');
				listItems.push('<li class="' + className.toLowerCase() + '">' + val[0] + ': <b>' + val[1] + '%</b></li>');
			}
		});

		var chartContainer = '#' + chartID;
		var pieLegend = $(chartContainer).parents('.pie-charts-pod').find('.pie-chart-key ul');

		if ( !($(pieLegend).hasClass('js-appended')) ) {
			$(pieLegend).addClass('js-appended').append(listItems);
		}
	});
	
	calculateScrollTrigger();
}

function cleanChartLabels(label) {
	var cleanText = label.replace(/_/g, ' ');
	cleanText = cleanText.replace(/-/g, ' ');
	var stringArr = cleanText.split(' ');

	for (var i = 0, len = stringArr.length; i < len; i++) {
		if ( stringArr[i].length > 2 ) {
			var text = stringArr[i];
			text = text.toLowerCase();
			text = text.charAt(0).toUpperCase() + text.substring(1);
			stringArr[i] = text;
		}
	}

	cleanText = stringArr.join(' ');
	return cleanText;
}

function cleanREITLabels(label) {
	var cleanText = label.replace(/_/g, ' ');
	cleanText = cleanText.replace(/-/g, ' ');
	var stringArr = cleanText.split(' ');

	for (var i = 0, len = stringArr.length; i < len; i++) {
		if ( stringArr[i].length > 2 ) {
			var text = stringArr[i];
			text = text.toLowerCase();
			text = text.charAt(0).toUpperCase() + text.substring(1);
			stringArr[i] = text;
		}
	}

	cleanText = stringArr + ' REIT';
	return cleanText;
}


// http://jsfiddle.net/karlgroves/XR8Su/6/
// Determines if document is in High Contrast Mode or not
// Returns boolean - true if high contrast, false otherwise
function HCTest(/*idval*/) {
	var objDiv, /*objImage,*/ strColor/*, strWidth, strReady*/;
	//var strImageID = idval; // ID of image on the page

	// Create a test div
	objDiv = document.createElement('div');

	//Set its color style to something unusual
	objDiv.style.color = 'rgb(31, 41, 59)';

	// Attach to body so we can inspect it
	document.body.appendChild(objDiv);

	// Read computed color value
	strColor = document.defaultView ? document.defaultView.getComputedStyle(objDiv, null).color : objDiv.currentStyle.color;
	strColor = strColor.replace(/ /g, '');

	// Delete the test DIV
	document.body.removeChild(objDiv);

	// Check if we get the color back that we set. If not, we're in 
	// high contrast mode. 
	if ( strColor !== 'rgb(31,41,59)' ) {
		return true;
	} else {
		return false;
	}
}        


function addSPReturnsData(timeframe) {
	var chart;
	var loopStart;
	var loopStop;

	if ( timeframe === 2005 ) {
		chart = $("#sp-return-chart-2005").highcharts();
		loopStart = 10;
		loopStop = 13;
	}
	if ( timeframe === 1995 ) {
		chart = $("#sp-return-chart-1995").highcharts();
		loopStart = 7;
		loopStop = 10;
	}
	if ( timeframe === 1985 ) {
		chart = $("#sp-return-chart-1985").highcharts();
		loopStart = 4;
		loopStop = 7;
	}
	if ( timeframe === 1975 ) {
		chart = $("#sp-return-chart-1975").highcharts();
		loopStart = 0;
		loopStop = 4;
	}
	
	var xAxis = chart.xAxis[0];
	var yAxis = chart.yAxis[0];
	
	if ( didYouKnowChartResized ) {
		for (var p = 1; p < 19; p++) {
			var text_id = '#t_marker' + p;
			$(text_id).remove();
			
			var circle_id = '#c_marker' + p;
			$(circle_id).remove();
		}
		
		didYouKnowChartResized = false;
	}
	
	var dataPoints = [
		//{'id': '1', 'x': -384051600000, 'y': 3.99, 'returns': '+45.15'}, //10/31/57
		//{'id': '2', 'x': -323658000000, 'y': 4.80, 'returns': '+30.94'}, //9/30/59
		//{'id': '3', 'x': -105498000000, 'y': 5.51, 'returns': '+11.97'}, //8/29/66
		//{'id': '4', 'x': 12524400000, 'y': 8.22, 'returns': '-22.46'}, //5/26/70
		{'id': '5', 'x': 180054000000, 'y': 8.4, 'returns': '-18.14'}, //9/16/75
		{'id': '6', 'x': 320367600000, 'y': 12.7, 'returns': '+6.64'}, //2/26/80
		{'id': '7', 'x': 370652400000, 'y': 15.3, 'returns': '+3.19'}, //9/30/81
		{'id': '8', 'x': 454716000000, 'y': 13.6, 'returns': '-7.94'}, //5/30/84
		
		{'id': '9', 'x': 561250800000, 'y': 9.5, 'returns': '+17.85'}, //10/15/87
		{'id': '10', 'x': 641599200000, 'y': 8.7, 'returns': '-2.44'}, //5/2/90
		{'id': '11', 'x': 785026800000, 'y': 8.03, 'returns': '-1.27'}, //11/17/94
		
		{'id': '12', 'x': 836517600000, 'y': 7.06, 'returns': '-0.61'}, //7/5/96
		{'id': '13', 'x': 948409200000, 'y': 6.79, 'returns': '+45.80'}, //1/21/00
		{'id': '14', 'x': 1017612000000, 'y': 5.42, 'returns': '+2.76'}, //4/1/02
		
		{'id': '15', 'x': 1181599200000, 'y': 5.30, 'returns': '+51.02'}, //6/12/07
		{'id': '16', 'x': 1270418400000, 'y': 3.99, 'returns': '+31.46'}, //4/5/10
		{'id': '17', 'x': 1297292400000, 'y': 3.72, 'returns': '+13.45'}, //2/10/11
		{'id': '18', 'x': 1388444400000, 'y': 3.0282, 'returns': '+38.11'} //12/31/13
	];

	for (var k = loopStart; k < loopStop; k++) {
		var xPos = Math.floor( xAxis.toPixels(dataPoints[k].x) );
		var yPos = Math.floor( yAxis.toPixels(dataPoints[k].y) );
		var text = dataPoints[k].returns + '%';
		
		var textAdjustmentX = 18;
		var textAdjustmentY = 15;

		//if (dataPoints[k].returns === '+31.46') {
			//textAdjustmentY = 25;
		//}
		
		chart.renderer.text(text, (xPos-textAdjustmentX), (yPos-textAdjustmentY)).css({backgroundColor: '#e4e2da', color: '#44464a', fontWeight: '700', fontFamily: 'Source Sans Pro', fontSize: '11px'}).attr({zIndex: 5, id:"t_marker" + dataPoints[k].id}).add();    
		chart.renderer.circle(xPos, yPos, 4).attr({fill: '#6c2b46', zIndex: 5, id:"c_marker" + dataPoints[k].x}).add();				
	}
}



/*
 * This is placed outside of document load to prevent script errors in IE8 
 */
function loadEAFEdata() {	
	$.getJSON('../data/q2-2015/global-equities/eafe-em/eafe-index.js', function(data) {
		var chart = $('#eafe-em-chart').highcharts();
		
		if (chart.series.length === 1) {
			chart.addAxis({
        		id: 'eafe-axis',
        		title: {
					text: 'MSCI EAFE Index'
				},
        		min: 1400,
        		opposite: false
    		});
			
			if ($('.lt-ie9').length) {
				chart.addSeries({
					data: data,
					yAxis: 1,
					color: '#4d3b65',
					name: cleanChartLabels('EAFE-INDEX'),
					dataGrouping: {
						enabled: true,
						groupPixelWidth: 19
					}
				});	
			}
			else {
				chart.addSeries({
					data: data,
					yAxis: 1,
					color: '#4d3b65',
					name: cleanChartLabels('EAFE-INDEX')
				});	
			}	
		}
	});
}

$(document).keyup(function(e) {

	// Escape for Main Nav
	if  ( ( e.keyCode === 27 ) && ( ( $('body').hasClass('nav-lock') ) && ( $('nav').hasClass('open') ) ) ) {
		$('.close-menu').trigger('click');
	}

	// Tab for maintaining focus on main nav if open
	if  ( ( e.keyCode === 9 ) && ( ( $('body').hasClass('nav-lock') ) && ( $('nav').hasClass('open') ) ) ) {

		var $focused = $(document.activeElement);

		if ( !( $focused.parents('nav').length ) ) {
			e.stopPropagation();

			if ( e.shiftKey ) { // Shift Key - traversing backwards
				$('.appendix-navigation li:last-child a').focus();
			}
			else { // Tab key - traversing forward
				$('.close-menu').focus();
			}
		}
	}
});


$(document).ready(function() {

	// Detect High Contrast Mode
	var $highContrastMode = HCTest();

	if ( $highContrastMode === true ) {
		$('html').addClass('highcontrastmode-on');
	} else {
		$('html').addClass('highcontrastmode-off');
	}

	// Fixed header
	if ( ( Modernizr.mq('only screen and (min-width: 50.625em)') ) || ( $('.lt-ie9').length ) ) {
		fixedHeader();
	}

	// Hide video containers
	if (( $('.video-container').length ) && ( !($('.lt-ie9').length) )) {
		setVideoContainerWidths();
	}

	if (( $('.chapter').length ) || ( $('.appendix').length )) {
		// Position Fixed Chapter Navigation
		calculateScrollTrigger();
		hideFixedChapterNavigation();
	}

	if ( $('.chapter').length || $('.appendix').length) {
		// Position Back-To-Top
		positionBackToTop();
	}

	// Open Nav Dropdown
	$('.hamburger-menu').on('click', function(){
		$('body').addClass('nav-lock');

		$('nav').slideDown( 400, function(){
			$('nav').addClass('open');
			$('nav').removeAttr('style');
		});

		// Set appropriate focus
		$('main, footer, .nav-bar').attr('aria-hidden', 'true');
		$('.close-menu').focus();

		return false;
	});

	// Close Nav Dropdown
	$('.close-menu').on('click', function(){
		$('nav').css('display', 'block');
		$('nav').removeClass('open');

		$('nav').slideUp(400, function(){
			$('body').removeClass('nav-lock');
			$('nav').removeAttr('style');
		});

		$('main, footer, .nav-bar').removeAttr('aria-hidden', 'true');
		$('.hamburger-menu').focus();

		return false;
	});


	// Fixed Navigation
	$('.fixed-chapter-navigation a').hover(
		function(){
			if ( !($(this).hasClass('inactive')) ) {
				var $navText = '<span>' + $(this).attr('data-paginate') + '</span> ';
				$('.fixed-chapter-navigation p').prepend( $navText ).addClass('is-visible');
			}
		},
		function(){
			if ( !($(this).hasClass('inactive')) ) {
				$('.fixed-chapter-navigation p').removeClass('is-visible');
				$('.fixed-chapter-navigation p span').remove();
			}
		}
	);

	$('.fixed-chapter-navigation a, .chapter-paging a').on('click', function(){
		if ( $(this).hasClass('inactive') ) {
			return false;
		}
	});

	// Video Interactions
	/*
	$('.open-video').on('click', function(){
		var $this = $(this);

		if ( !($this.hasClass('is-open')) ) {
			$this.addClass('is-open');
			var $videoID = $this.attr('data-video-container');

			$('.video-container[data-video="' + $videoID + '"]').addClass('is-open').slideDown(400, function(){
				calculateScrollTrigger();
			});
		}

		return false;
	});

	$('.close-video').on('click', function(){		
		var $this = $(this);
		var $thisParent = $this.parents('.video-container');		
		var $videoID = $thisParent.attr('data-video');

		// Stop HTML5 video
		if ( $('.video').length ) {
			var $media = $thisParent.find('video');
			$media[0].pause();
		}

		// IE8 Fallback
		if ( $('.lt-ie9').length ) {
			var $media = videojs($videoID);
			$media.pause();
		}

		// Close containers
		var $openButton = $('.open-video[data-video-container="' + $videoID + '"]');
		//$('.open-video[data-video-container="' + $videoID + '"]').removeClass('is-open');
		$openButton.removeClass('is-open');

		$thisParent.removeClass('is-open').slideUp(400, function(){
			calculateScrollTrigger();
		});

		$openButton.focus();

		return false;
	});
	*/

	// Charts Overview
	$('.charts-overview a').on('click', function(){
		if (location.pathname.replace(/^\//,'') === this.pathname.replace(/^\//,'') && location.hostname === this.hostname) {
			var $target = $(this.hash);
			$target = $target.length ? $target : $('[name=' + this.hash.slice(1) +']');

			if ( $target.length ) {
				var targetParent = $target.parent('.chapter-material');
				var headerHeight = $('header').height();
				var scrollTo = parseInt(targetParent.offset().top) - parseInt(headerHeight);

				//var targetTitle = $target.siblings('.chart-title');
				//var headerHeight = $('header').height();
				//var scrollTo = parseInt(targetTitle.offset().top) - parseInt(headerHeight);
				scrollTo = scrollTo + 'px';

				$('html,body').animate({
					scrollTop: scrollTo
				}, 1000);
			}
		}
	});

	// IE8 Charts Overview Last-Child Support
	if ( ( $('.lt-ie9').length ) && ( $('.charts-overview').length ) ){
		$('.charts-overview > li:nth-child(2n+1)').each(function(index) {
			$(this).addClass('alternate');
		});

		$('.charts-overview > li:nth-last-child(2)').each(function(index) {
			$(this).addClass('second-last-child');
		});

		$('.charts-overview > li:last-child').each(function(index) {
			$(this).addClass('last-child');
		});
	}

	// Back to top
	$('.js-back-to-top').on('click', function(){
		$('html,body').animate({
			scrollTop: '0px'
		}, 1000);

		$('#header-branding').focus();

		return false;
	});

	// Quilt Chart
	$('.chart-filters a').on('click', function(){

		if ( !($('.highcontrastmode-on').length ) ) { // Add Quilt Chart functionality only when High Contrast Mode is Off

			var target = $(this).attr('data-container');

			if ( $(this).hasClass('active') ) {
				$(this).removeClass('active');
			}
			else {
				$(this).addClass('active');
			}

			$('#' + target).toggle();

			return false;
		}
	});

	if ( ( $('html').hasClass('highcontrastmode-on') ) && ( $('.additional-resources-appendix').length ) ) {

		if ( Modernizr.mq('only screen and (min-width: 62.250em)') ) {
			var $fullChartImage = $('.hcm-chart');
			var $imageReplacement = $fullChartImage.attr('data-image');
			$fullChartImage.attr('src', $imageReplacement);
		}
	}
	
	// Fix IE8 Chart Overview buttons
	if (( $('.lt-ie9').length ) && ( $('.charts-overview').length )) {
		$('.charts-overview li:nth-child(2n+1)').addClass('ie-left-item');
		$('.charts-overview li:nth-last-child(2)').addClass('ie-second-to-last-item');
		$('.charts-overview li:last-child').addClass('ie-last-item');
	}

	// Charts ----------------------------------------------------------------------------------
	
	/*
	THIS FEATURE NOT CURRENTLY IN USE BUT COULD BE RE-INTRODUCED
	
	$('.js-print-chart').on('click', function() {
		var $this = $(this);
		var chartSource = '#' + $this.attr('data-chart');
		var chartTitle = $this.attr('data-chart-title');
		var chart = $(chartSource).highcharts();

		chart.setTitle({text: chartTitle}, {text: ' '});
		chart.print();
		chart.setTitle({text: ''}, {text: ''});

		return false;
	});

	$('.js-export-chart').on('click', function() {
		var $this = $(this);
		var $dataChart = $this.attr('data-chart');
		var chartSource = '#' + $dataChart;
		var fileName = $dataChart;
		var chart = $(chartSource).highcharts();

		chart.exportChart({type: 'application/pdf', filename: fileName});

		return false;
	});
	*/

	// Chapter 1: Spotlight
	if ( $('.spotlight-chapter').length ) {
		// Global Chart Options for Spotlight Chapter
		Highcharts.setOptions({
			chart: {
				backgroundColor: '#f3f1e9',
				events: {
					load: function () {
						calculateScrollTrigger();
					}
				}
			},
			xAxis: {
				gridLineColor: '#e4e2da',
				lineColor: '#e4e2da',
				tickColor: '#e4e2da',
				title: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				}
			},
			yAxis: {
				title: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				gridLineColor: '#e4e2da'
			},
			plotOptions: {
				series: {
					// Settings here if necessary
				},
				column: {
					// Settings here if necessary
				}
			},
			legend: {
				enabled: false
			},
			credits: {
				enabled: false
			},
			title: {
				text: null
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			}
		});

		// Spotlight Chart
		var spotlight_seriesOptions = [];
		var spotlight_seriesCounter = 0;
		var spotlight_names = ['12-Month-Avg', '24-Month-Avg'];
		var spotlight_legend_titles = {
			'12-month-avg': '12-Month Average',
			'24-month-avg': '24-Month Average'
		};
		var spotlight_colors = {
			'12-month-avg': '#89556B',
			'24-month-avg': '#A39B94'
		};
		
		var createSpotlightChart = function () {
			$('#spotlight-chart').highcharts({
				chart: {
					type: 'column'
				},
				yAxis: {
					title: {
						text: ""
					},
					labels: {
						formatter:function() {
							return this.value + '%';
						}
					}
				},
				xAxis: {
					title: {
						enabled: true,
						text: ""
					},
					type: 'category',
					labels: {
						rotation: -60 // Otherwise labels are zig-zagged because of length
					},
					categories: ['Barclays US Aggregate',
								 'Barclays High Yield',
								 'Russell 2000',
								 'HFRI Composite',
								 'S&P 500',
								 'MSCI EAFE',
								 'Bloomberg Commodites',
								 'FTSE/EPRA Developed',
								 'Russell Mid Cap',
								 'MSCI EM']
				},
				tooltip: {
					headerFormat: 'Forward Average 12 & 24 Month Annualized Returns<br />',
					pointFormat: '<span style="color: {series.color};">{series.name}: <b>{point.y}%</b></span><br />',
					valueDecimals: 0,
					shared: true,
					useHTML: true,
					crosshairs: {
        				color: '#dfdcd1'
    				}
				},
				plotOptions: {
					series: {
                		shadow: false
					},
					column: {
						borderWidth: 0,
                		pointPadding: 0,
                		shadow: false
            		}
				},
				series: spotlight_seriesOptions
			});
		};
		
		$.each(spotlight_names, function (i, name) {
			$.getJSON('../data/q2-2015/spotlight/' + name.toLowerCase() + '.js', function (data) {
				spotlight_seriesOptions[i] = {
					data: data,
					name: spotlight_legend_titles[name.toLowerCase()],
					color: spotlight_colors[name.toLowerCase()]
				};

				spotlight_seriesCounter += 1;

				if (spotlight_seriesCounter === spotlight_names.length) {
					createSpotlightChart();
				}

			});
		});
	}

	// Chapter 2: Economy
	if ( $('.economy-chapter').length ) {
		// Global Chart Options for Economy Chapter
		Highcharts.setOptions({
			chart: {
				backgroundColor: '#f3f1e9',
				events: {
					load: function () {
						calculateScrollTrigger();
					}
				}
			},
			xAxis: {
				type: 'datetime',
				gridLineColor: '#e4e2da',
				lineColor: '#e4e2da',
				tickColor: '#e4e2da',
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				}
			},
			yAxis: {
				title: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				gridLineColor: '#e4e2da'
			},
			plotOptions: {
				series: {
					borderWidth: 0,
					color: '#326295',
					states: {
						hover: {
							lineWidth: 3
						}
					}
				}
			},
			legend: {
				enabled: false
			},
			credits: {
				enabled: false
			},
			title: {
				text: null
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			}
		});

		// Consumer Confidence Chart
		var consumer_confidence_seriesOptions = [];
		var consumer_confidence_seriesCounter = 0;
		var consumer_confidence_names = ['Small-Business-Optimism', 'Consumer-Confidence-Index'];

		var consumer_confidence_colors = {
			'small-business-optimism': '#84A1BF',
			'consumer-confidence-index': '#326295'
		};
		
		var createConsumerConfidenceChart = function () {
			$('#cons-conf-chart').highcharts('StockChart', {
				rangeSelector: {
					enabled: false
				},
				navigator: {
					enabled: false
				},
				scrollbar: {
					enabled: false
				},
				yAxis: [{
					title: {
						text: 'Small Business Optimism Index Level'
					},
					min: 80
				}, {
					title: {
						text: 'Consumer Confidence Index Level'
					},
					min: 0,
					opposite: false
				}],
				xAxis : {
					tickInterval : 1000*3600,
					dateTimeLabelFormats : {
						month : "%Y",
						day : "%Y"
					}
				},
				tooltip: {
					valueDecimals: 2
				},
				series: consumer_confidence_seriesOptions
			});
		};
		$.each(consumer_confidence_names, function (i, name) {
			$.getJSON('../data/q2-2015/economy/consumer-confidence/' + name.toLowerCase() + '.js', function (data) {
				consumer_confidence_seriesOptions[i] = {
					name: cleanChartLabels(name),
					data: data,
					yAxis: i,
					color: consumer_confidence_colors[name.toLowerCase()]
				};

				consumer_confidence_seriesCounter += 1;

				if (consumer_confidence_seriesCounter === consumer_confidence_names.length) {
					createConsumerConfidenceChart();
				}
			});
		});

		// Euro Spot Price
		var euroSpotPriceOptions = {
			rangeSelector: {
				enabled: false
			},
			navigator: {
				enabled: false
			},
			scrollbar: {
				enabled: false
			},
			yAxis: {
				title: {
					text: 'US Dollar per Euro'
				},
				opposite: false,
				labels: {
            		format: '{value:.4f}'
        		}
			},
			xAxis: {
				dateTimeLabelFormats : {
					month: '%m/%Y',
					year : "%Y"
				}
			},
			series: [{
				name : 'Euro Spot Price',
				tooltip: {
					valueDecimals: 4
				}
			}]
		};

		$.getJSON('../data/q2-2015/economy/euro-spot-price.js', function (data) {
			euroSpotPriceOptions.series[0].data = data;
			if ($('.lt-ie9').length) {
				euroSpotPriceOptions.series[0].dataGrouping = {
					enabled: true, 
					groupPixelWidth: 21
				};
			}
			$("#euro-chart").highcharts("StockChart", euroSpotPriceOptions);			
		});

		// GDP chart
		var gdpOptions = {
			chart: {
				renderTo: 'gdp-chart',
				type: 'column'
			},
			xAxis: {
				plotBands: [{ // Recession: Jul 1990 - Mar 1991
					from: 646783200000,
					to: 667782000000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}, { // Recession: Mar 2001 - Nov 2001
					from: 983401200000,
					to: 1004569200000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}, { // Recession: Dec 2007 - Jun 2009
					from: 1196463600000,
					to: 1243807200000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}]
			},
			yAxis: {
				title: {
					text: '% Change'
				}
			},
			tooltip: {
				xDateFormat: '%b %e, %Y'
			},
			series: [{}]
		};

		$.getJSON('../data/q2-2015/economy/gdp.js', function(data) {
			gdpOptions.series[0].data = data;
			gdpOptions.series[0].name = "GDP";
			var chart = new Highcharts.Chart(gdpOptions);
		});


		// Unemployment Chart
		var unemploymentOptions = {
			chart: {
				renderTo: 'unemployment-chart',
				type: 'line'
			},
			xAxis: {
				plotBands: [{ // Recession: Jul 1990 - Mar 1991
					from: 646783200000,
					to: 667782000000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}, { // Recession: Mar 2001 - Nov 2001
					from: 983401200000,
					to: 1004569200000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}, { // Recession: Dec 2007 - Jun 2009
					from: 1196463600000,
					to: 1243807200000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}]
			},
			yAxis: {
				title: {
					text: 'Percent'
				}
			},
			tooltip: {
				xDateFormat: '%b %e, %Y'
			},
			series: [{}]
		};

		$.getJSON('../data/q2-2015/economy/unemployment.js', function(data) {
			unemploymentOptions.series[0].data = data;
			unemploymentOptions.series[0].name = "Unemployment";
			var chart = new Highcharts.Chart(unemploymentOptions);
		});

		// CPI Chart
		var cpiOptions = {
			chart: {
				renderTo: 'cpi-chart',
				type: 'line'
			},
			xAxis: {
				plotBands: [{ // Recession: Jul 1990 - Mar 1991
					from: 646783200000,
					to: 667782000000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}, { // Recession: Mar 2001 - Nov 2001
					from: 983401200000,
					to: 1004569200000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}, { // Recession: Dec 2007 - Jun 2009
					from: 1196463600000,
					to: 1243807200000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}],
				tickPositions : [-157744800000, 157788000000, 473407200000, 788940000000, 1104559200000, 1420092000000],
				labels : {
					format : '{value:%Y}'
				},
				//max : 1420092000000
			},
			yAxis: {
				title: {
					text: 'Year Over Year % Change'
				}
			},
			series: [{}]
		};

		$.getJSON('../data/q2-2015/economy/cpi.js', function(data) {
			cpiOptions.series[0].data = data;
			cpiOptions.series[0].name = "CPI";
			var chart = new Highcharts.Chart(cpiOptions);
		});
	}

	// Chapter 3: Global Equities
	if ( $('.equities-chapter').length ) {
		// Global Chart Options for Global Equities Chapter
		Highcharts.setOptions({
			chart: {
				backgroundColor: '#f3f1e9',
				events: {
					load: function () {
						calculateScrollTrigger();
					}
				}
			},
			xAxis: {
				type: 'datetime',
				gridLineColor: '#e4e2da',
				lineColor: '#e4e2da',
				tickColor: '#e4e2da',
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				}
			},
			yAxis: {
				title: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				gridLineColor: '#e4e2da'
			},
			plotOptions: {
				series: {
					borderWidth: 0,
					color: '#4d3b65',
					states: {
						hover: {
							lineWidth: 3
						}
					}
				}
			},
			legend: {
				enabled: false
			},
			credits: {
				enabled: false
			},
			title: {
				text: null
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			}
		});

		// PE S&P Chart
		var pesp_seriesOptions = [];
		var pesp_seriesCounter = 0;
		var pesp_names = ['MEDIAN_PE', 'PE_RATIO'];

		var pesp_colors = {
			'median_pe': '#9489a3',
			'pe_ratio': '#4d3b65'
		};

		var createPesp500Chart = function () {
			$('#pe-sp500-chart').highcharts({
				rangeSelector: {
					enabled: false
				},
				navigator: {
					enabled: false
				},
				scrollbar: {
					enabled: false
				},
				yAxis: {
					title: {
						text: 'P/E Ratio'
					},
					opposite: false
				},
				xAxis : {
					type: 'category',
					tickmarkPlacement: 'on',
					tickPositions: [0, 39, 77, 115]
				},
				tooltip: {
					valueDecimals: 2
				},
				series: pesp_seriesOptions
			});
		};

		$.each(pesp_names, function (i, name) {
			$.getJSON('../data/q2-2015/global-equities/pe-sp500/' + name.toLowerCase() + '.js', function (data) {
				pesp_seriesOptions[i] = {
					name: cleanChartLabels(name),
					data: data,
					color: pesp_colors[name.toLowerCase()]
				};

				pesp_seriesCounter += 1;

				if (pesp_seriesCounter === pesp_names.length) {
					createPesp500Chart();
				}
			});
		});

		// Dividend
		var dividendOptions = {
			chart: {
				renderTo: 'dividend-chart',
				type: 'line'
			},
			xAxis: {
				type: 'category',
				categories: [],
				tickmarkPlacement: 'on',
				tickPositions: [0, 28, 56, 84, 111]
			},
			yAxis: {
				title: {
					text: 'Per Share Dividend'
				}
			},
			series: [{}]
		};

		$.getJSON('../data/q2-2015/global-equities/dividend.js', function(data) {
			dividendOptions.xAxis.categories = data[0];
			dividendOptions.series[0].data = data[1];
			dividendOptions.series[0].name = 'Quarterly Dividends';
			var chart = new Highcharts.Chart(dividendOptions);
		});

		// S&P500 Chart
		$.getJSON('../data/q2-2015/global-equities/sandp500.js', function (data) {
			$('#sp-500-chart').highcharts('StockChart', {
				rangeSelector : {
					enabled: false
				},
				navigator: {
					enabled: false
				},
				scrollbar: {
					enabled: false
				},
				yAxis: {
					title: {
						/*text: 'Closing Price'*/
					},
					opposite: false
				},
				tooltip: {
					formatter: function() {
						var s = '<small style="font-size: 10px;">' + Highcharts.dateFormat('%b %e, %Y', this.x) + '</small><br />';
						$.each(this.points, function(i, point) {
                        	s += '<span style="color: ' + point.series.color + ';">•</span> ' + point.series.name + ' ' + ': <b>' + parseFloat(point.y).toFixed(2) + '</b><br />';
                    	});
						return s;
					}
				},
				series : [{
					name : 'Closing Price',
					data : data,
					tooltip: {
						valueDecimals: 2
					},
					dataGrouping: {
						approximation: 'open'
					}
				}]
			});
		});

		// VIX Volatility
		var vixOptions = {
			chart: {
				renderTo: 'vix-volatility-chart',
				type: 'line'
			},
			yAxis: {
				title: {
					text: null
				}
			},
			series: [{}]
		};

		$.getJSON('../data/q2-2015/global-equities/volatility-index.js', function(data) {
			vixOptions.series[0].data = data;
			vixOptions.series[0].name = 'Vix Volatility';
			var chart = new Highcharts.Chart(vixOptions);
		});

		// After Tax Corp Profits
		var profitsOptions = {
			chart: {
				renderTo: 'after-tax-corp-profits-chart',
				type: 'line'
			},
			xAxis: {
				plotBands: [{ // Recession: Jul 1990 - Mar 1991
					from: 646783200000,
					to: 667782000000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}, { // Recession: Mar 2001 - Nov 2001
					from: 983401200000,
					to: 1004569200000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}, { // Recession: Dec 2007 - Jun 2009
					from: 1196463600000,
					to: 1243807200000,
					color: '#dfdcd1',
					borderWidth:1,
					borderColor: '#666666'
				}],
				//max : 1420092000000
			},
			yAxis: {
				title: {
					text: 'Billions $'
				}
			},
			series: [{}]
		};

		$.getJSON('../data/q2-2015/global-equities/after-tax-corp-profits.js', function(data) {
			profitsOptions.series[0].data = data;
			profitsOptions.series[0].name = 'Corp. Profits after Tax';
			var chart = new Highcharts.Chart(profitsOptions);
		});


		// EAFE-EM CHART
		var isIE8 = $('.lt-ie9').length;
		
		var emOptions = {
			chart: {
				renderTo: 'eafe-em-chart',
				type: 'line'
			},
			rangeSelector: {
				enabled: false
			},
			navigator: {
				enabled: false
			},
			scrollbar: {
				enabled: false
			},
			yAxis: {
				title: {
					text: 'MSCI Emerging Market Index'
				},
				min: 800,
				offset: 30,
				opposite: true
			},
			xAxis: {
				//tickInterval : 1000*3600,
				dateTimeLabelFormats : {
					month : "%m/%Y",
					day : "%m/%Y"
				}
			},
			tooltip: {
				valueDecimals: 2
			},
			series: [{}]
		};

		$.getJSON('../data/q2-2015/global-equities/eafe-em/em-index.js', function(data) {
			emOptions.series[0].data = data;
			emOptions.series[0].color = '#9489a3';
			emOptions.series[0].name = cleanChartLabels('EM-INDEX');
			
			if (isIE8) {
				emOptions.series[0].dataGrouping = {
					enabled: true,
					groupPixelWidth: 19
				};
			}
								
			var chart = new Highcharts.Chart(emOptions, function(){
				loadEAFEdata();
			});
		});
	}

	// Chapter 4: Global Fixed Income
	if ( $('.fixed-income-chapter').length ) {
		// Global Chart Options for Global Fixed Income Chapter
		Highcharts.setOptions({
			chart: {
				backgroundColor: '#f3f1e9',
				events: {
					load: function () {
						calculateScrollTrigger();
					}
				}
			},
			xAxis: {
				type: 'datetime',
				gridLineColor: '#e4e2da',
				lineColor: '#e4e2da',
				tickColor: '#e4e2da',
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				}
			},
			yAxis: {
				title: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				gridLineColor: '#e4e2da'
			},
			plotOptions: {
				series: {
					borderWidth: 0,
					color: '#497366',
					states: {
						hover: {
							lineWidth: 3
						}
					}
				}
			},
			legend: {
				enabled: false
			},
			credits: {
				enabled: false
			},
			title: {
				text: null
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			}
		});

		// Fed Funds Futures Chart
		$('#fed-funds-futures-chart').highcharts({
			chart: {
				type: 'line'
			},
			xAxis: {
				categories: ['2015', '2016', '2017', 'Longer Run']
			},
			yAxis: {
				title: {
					text: 'Yield %'
				},
				opposite: false
			},
			series: [{
				name: 'Target Fed Funds Rate',
				data: [0.772058824, 2.022058824, 3.183823529, 3.661764706],
				color: '#497366',
				tooltip: {
					valueDecimals: 2
				}
			}, {
				name: 'Fed Fund as Priced by the Market',
				data: [0.315, 1.09, 1.8],
				color: '#96b2a9',
				tooltip: {
					valueDecimals: 2
				}
			}]
		});
					
		// International Govt Bonds
		var bondOptions = {
			chart: {
				renderTo: 'intl-govt-bonds-chart',
				type: 'column'
			},
			xAxis: {
				type: 'category'
			},
			yAxis: {
				title: {
					text: '% Bond Yields'
				}
			},
			
			plotOptions: {
        		column: {
            		colorByPoint: true
        		}
    		},
    		colors: [
        		'#96b2a9', '#507F70', '#96b2a9', '#96b2a9', '#96b2a9', '#96b2a9'
    		],
			tooltip: {
				enabled: false
			},
			series: [{}]
		};

		$.getJSON('../data/q2-2015/global-fixed-income/intl-govt-bonds.js', function(data) {
			bondOptions.series[0].data = data;
			var chart = new Highcharts.Chart(bondOptions);
		});


		// Yield Curve Chart
		$('#yield-curve-chart').highcharts({
			chart: {
				type: 'line'
			},
			plotOptions: {
				series: {
					connectNulls: true
				}
			},
			xAxis: {
				categories: ['1Y', '2Y', '3Y', '4Y', '5Y', '6Y', '7Y', '8Y', '9Y', '10Y', '11Y', '12Y', '13Y', '14Y', '15Y', '16Y', '17Y', '18Y', '19Y', '20Y', '21Y', '22Y', '23Y', '24Y', '25Y', '26Y', '27Y', '28Y', '29Y', '30Y'],
				tickPositions: [0, 1, 2, 4, 6, 9, 29]
			},
			yAxis: {
				title: {
					text: 'Yield %'
				},
				opposite: false
			},
			series: [{
				name: '30 June 2015',
				data: [0.27, 0.64, 1, null, 1.65, null, 2.08, null, null, 2.35, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 3.12],
				color: '#497366',
				tooltip: {
					valueDecimals: 2
				}
			}, {
				name: 'One Month Ago',
				data: [0.25, 0.61, 0.92, null, 1.49, null, 1.87, null, null, 2.13, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 2.88],
				color: '#96b2a9',
				tooltip: {
					valueDecimals: 2
				}
			}, {
				name: 'One Year Ago',
				data: [0.1, 0.46, 0.87, null, 1.63, null, 2.14, null, null, 2.53, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 3.36],
				color: '#66AB87',
				tooltip: {
					valueDecimals: 2
				}
			}]
		});
		

		// 10 Year Treasury Yield Chart
		var tsyGroupPixelWidth;
		
		if ($('.lt-ie9').length) {
			tsyGroupPixelWidth = 10;
		}
		else {
			tsyGroupPixelWidth = 2;
		}
		
		$.getJSON('../data/q2-2015/global-fixed-income/10-year-tsy.js', function (data) {
			$('#tsy-chart').highcharts('StockChart', {
				rangeSelector : {
					enabled: false
				},
				navigator: {
					enabled: false
				},
				scrollbar: {
					enabled: false
				},
				yAxis: {
					title: {
						text: 'Percent'
					},
					opposite: false
				},
				xAxis : {
					tickPositions : [-157744800000, 157788000000, 473407200000, 788940000000, 1104559200000,  1420092000000],
					labels : {
						format : '{value:%Y}'
					},
					//max : 1420092000000
				},
				series : [{
					name : '10 Year Treasury Yield',
					data : data,
					tooltip: {
						valueDecimals: 2
					},
					dataGrouping: {
						enabled: true,
						groupPixelWidth: tsyGroupPixelWidth
					}
				}]
			});
		});

		// Corporate Spreads
		var corp_spreads_seriesOptions = [];
		var corp_spreads_seriesCounter = 0;
		var corp_spreads_names = ['High-Yield-Spread', 'Investment-Grade-Spread', 'Emerging-Markets-Spread'];

		var corp_spreads_colors = {
			'high-yield-spread': '#497366',
			'investment-grade-spread': '#96b2a9',
			'emerging-markets-spread': '#66AB87'
		};

		var createCorpSpreadsChart = function () {
			$('#corp-spreads-chart').highcharts('StockChart', {
				rangeSelector: {
					enabled: false
				},
				navigator: {
					enabled: false
				},
				scrollbar: {
					enabled: false
				},
				yAxis: {
					title: {
						text: 'Yield Spreads'
					},
					opposite: false
				},
				xAxis : {
					//max : 1420092000000
				},
				tooltip: {
					valueDecimals: 2
				},
				series: corp_spreads_seriesOptions,
			});
		};

		$.each(corp_spreads_names, function (i, name) {
			$.getJSON('../data/q2-2015/global-fixed-income/corp-spreads/' + name.toLowerCase() + '.js', function (data) {
				corp_spreads_seriesOptions[i] = {
					name: cleanChartLabels(name),
					data: data,
					color: corp_spreads_colors[name.toLowerCase()]
				};

				corp_spreads_seriesCounter += 1;

				if (corp_spreads_seriesCounter === corp_spreads_names.length) {
					createCorpSpreadsChart();
				}
			});
		});
	}	

	// Chapter 5: Global Real Assets
	if ( $('.international-chapter').length ) {
		// Global Chart Options for Global Real Assets Chapter
		Highcharts.setOptions({
			chart: {
				backgroundColor: '#f3f1e9',
				events: {
					load: function () {
						calculateScrollTrigger();
					}
				}
			},
			xAxis: {
				type: 'datetime',
				gridLineColor: '#e4e2da',
				lineColor: '#e4e2da',
				tickColor: '#e4e2da',
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				}
			},
			yAxis: {
				title: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				gridLineColor: '#e4e2da'
			},
			plotOptions: {
				series: {
					borderWidth: 0,
					color: '#a9431e',
					states: {
						hover: {
							lineWidth: 3
						}
					}
				}
			},
			legend: {
				enabled: false
			},
			credits: {
				enabled: false
			},
			title: {
				text: null
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			}
		});

		// Gold Spot Price
		$.getJSON('../data/q2-2015/global-real-assets/gold-spot-price.js', function (data) {
			$('#gold-chart').highcharts('StockChart', {
				rangeSelector : {
					enabled: false
				},
				navigator: {
					enabled: false
				},
				scrollbar: {
					enabled: false
				},
				yAxis: {
					title: {
						text: 'US Dollars'
					},
					opposite: false
				},
				xAxis : {
					//max : 1420092000000
				},
				tooltip: {
					formatter: function() {
						var s = '<small style="font-size: 10px;">' + Highcharts.dateFormat('%b %e, %Y', this.x) + '</small><br />';
						$.each(this.points, function(i, point) {
                        	s += '<span style="color: ' + point.series.color + ';">•</span> ' + point.series.name + ' ' + ': <b>' + parseFloat(point.y).toFixed(2) + '</b><br />';
                    	});
						return s;
					}
				},
				series : [{
					name : 'Gold Spot Price',
					data : data,
					tooltip: {
						valueDecimals: 2
					},
					dataGrouping: {
						approximation: 'open'
					}
				}]
			});
		});

		// REITs
		$(function() {
			var reit_seriesOptions = [];
			var reit_seriesCounter = 0;
			var reit_names = ['GLOBAL', 'US', 'INTL'];

			var reit_colors = {
				'global': '#a9431e',
				'us': '#734626',
				'intl': '#b06224',
			};

			var createChart = function () {
				$('#reit-chart').highcharts('StockChart', {
					rangeSelector: {
						enabled: false
					},
					navigator: {
						enabled: false
					},
					scrollbar: {
						enabled: false
					},
					yAxis: {
						title: {
							text: 'Indices'
						},
						opposite: false
					},
					xAxis : {
						labels : {
							format : '{value:%Y}'
						}
					},
					tooltip: {
						valueDecimals: 2
					},
					series: reit_seriesOptions
				});
			};

			$.each(reit_names, function (i, name) {
				$.getJSON('../data/q2-2015/global-real-assets/reit/' + name.toLowerCase() + '.js', function (data) {
					reit_seriesOptions[i] = {
						name: cleanREITLabels(name),
						data: data,
						color: reit_colors[name.toLowerCase()]
					};

					reit_seriesCounter += 1;

					if (reit_seriesCounter === reit_names.length) {
						createChart();
					}
				});
			});
		});

		// Oil Price
		$.getJSON('../data/q2-2015/global-real-assets/us-west-texas-crude-oil.js', function (data) {
			$('#oil-chart').highcharts('StockChart', {
				rangeSelector : {
					enabled: false
				},
				navigator: {
					enabled: false
				},
				scrollbar: {
					enabled: false
				},
				yAxis: {
					title: {
						text: 'WTI Crude'
					},
					opposite: false
				},
				xAxis : {
					labels : {
						format: '{value:%Y}'
					}
				},
				series : [{
					name : 'Price per barrel',
					data : data,
					tooltip: {
						valueDecimals: 2
					}
				}]
			});
		});
	}

	// Chapter 6: Did You Know
	if ( $('.did-you-know-chapter').length ) {
		// Global Chart Options for Did You Know Chapter
		Highcharts.setOptions({
			chart: {
				backgroundColor: '#f3f1e9',
				events: {
					load: function () {
						calculateScrollTrigger();
					}
				}
			},
			xAxis: {
				type: 'datetime',
				gridLineColor: '#e4e2da',
				lineColor: '#e4e2da',
				tickColor: '#e4e2da',
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				}
			},
			yAxis: {
				title: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				labels: {
					style: {
						color: '#44464a',
						fontWeight: '700',
						fontFamily: 'Source Sans Pro',
						fontSize: '12px'
					}
				},
				gridLineColor: '#e4e2da'
			},
			plotOptions: {
				series: {
					animation: false,
					borderWidth: 0,
					color: '#675b53',
					states: {
						hover: {
							//lineWidth: 3
						}
					}
				}
			},
			legend: {
				enabled: false
			},
			credits: {
				enabled: false
			},
			title: {
				text: null
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			}
		});
		
		// S&P Return During Trough/Peak Cycle
		var spReturnOptions2005 = {
			//chart: {
				//renderTo: 'sp-return-chart',
				//type: 'line'
			//},
			chart: {
            	events: {
                	load: function () {
                		addSPReturnsData(2005);
                		calculateScrollTrigger();
                	}
                }
            },
			rangeSelector: {
				enabled: false
			},
			navigator: {
				enabled: false
			},
			scrollbar: {
				enabled: false
			},
			yAxis: {
				title: {
					text: '10 Year Treasury Yield'
				},
				opposite: false,
				labels : {
					format : '{value}%'
				}
			},
			xAxis : {
				type: 'datetime',
				//tickPositions : [157788000000, 473407200000, 788940000000, 1104559200000,  1420092000000],
				labels : {
					format : '{value:%Y}'
				},
			},	
			plotOptions: {
				series: {
					animation: false
				}
			},
			tooltip: {
				formatter: function() {
					var s = '<small style="font-size: 10px;">' + Highcharts.dateFormat('%b %e, %Y', this.x) + '</small><br />';
					$.each(this.points, function(i, point) {
						s += '<span style="color: ' + point.series.color + ';">•</span> ' + point.series.name + ' ' + ': <b>' + parseFloat(point.y).toFixed(2) + '</b><br />';
					});
					return s;
				}
			},
			series: [{
				name : '10 Year Treasury Yield',
				tooltip: {
					valueDecimals: 1
				}
			}]
		};
		
		// 2005-2015
		$.getJSON('../data/q2-2015/did-you-know/10-year-tsy-2005.js', function (data) {
			spReturnOptions2005.series[0].data = data;
			$("#sp-return-chart-2005").highcharts("StockChart", spReturnOptions2005);			
		});
		
		var spReturnOptions1995 = {
			//chart: {
				//renderTo: 'sp-return-chart',
				//type: 'line'
			//},
			chart: {
            	events: {
                	load: function () {
                		addSPReturnsData(1995);
                		calculateScrollTrigger();
                	}
                }
            },
			rangeSelector: {
				enabled: false
			},
			navigator: {
				enabled: false
			},
			scrollbar: {
				enabled: false
			},
			yAxis: {
				title: {
					text: '10 Year Treasury Yield'
				},
				opposite: false,
				labels : {
					format : '{value}%'
				}
			},
			xAxis : {
				type: 'datetime',
				//tickPositions : [157788000000, 473407200000, 788940000000, 1104559200000,  1420092000000],
				labels : {
					format : '{value:%Y}'
				},
			},	
			plotOptions: {
				series: {
					animation: false
				}
			},
			tooltip: {
				formatter: function() {
					var s = '<small style="font-size: 10px;">' + Highcharts.dateFormat('%b %e, %Y', this.x) + '</small><br />';
					$.each(this.points, function(i, point) {
						s += '<span style="color: ' + point.series.color + ';">•</span> ' + point.series.name + ' ' + ': <b>' + parseFloat(point.y).toFixed(2) + '</b><br />';
					});
					return s;
				}
			},
			series: [{
				name : '10 Year Treasury Yield',
				tooltip: {
					valueDecimals: 1
				}
			}]
		};
		
		// 1995-2005
		$.getJSON('../data/q2-2015/did-you-know/10-year-tsy-1995.js', function (data) {
			spReturnOptions1995.series[0].data = data;
			$("#sp-return-chart-1995").highcharts("StockChart", spReturnOptions1995);			
		});
		
		var spReturnOptions1985 = {
			//chart: {
				//renderTo: 'sp-return-chart',
				//type: 'line'
			//},
			chart: {
            	events: {
                	load: function () {
                		addSPReturnsData(1985);
                		calculateScrollTrigger();
                	}
                }
            },
			rangeSelector: {
				enabled: false
			},
			navigator: {
				enabled: false
			},
			scrollbar: {
				enabled: false
			},
			yAxis: {
				title: {
					text: '10 Year Treasury Yield'
				},
				opposite: false,
				labels : {
					format : '{value}%'
				}
			},
			xAxis : {
				type: 'datetime',
				//tickPositions : [157788000000, 473407200000, 788940000000, 1104559200000,  1420092000000],
				labels : {
					format : '{value:%Y}'
				},
			},	
			plotOptions: {
				series: {
					animation: false
				}
			},
			tooltip: {
				formatter: function() {
					var s = '<small style="font-size: 10px;">' + Highcharts.dateFormat('%b %e, %Y', this.x) + '</small><br />';
					$.each(this.points, function(i, point) {
						s += '<span style="color: ' + point.series.color + ';">•</span> ' + point.series.name + ' ' + ': <b>' + parseFloat(point.y).toFixed(2) + '</b><br />';
					});
					return s;
				}
			},
			series: [{
				name : '10 Year Treasury Yield',
				tooltip: {
					valueDecimals: 1
				}
			}]
		};
		
		// 1985-1995
		$.getJSON('../data/q2-2015/did-you-know/10-year-tsy-1985.js', function (data) {
			spReturnOptions1985.series[0].data = data;
			$("#sp-return-chart-1985").highcharts("StockChart", spReturnOptions1985);			
		});
		
		var spReturnOptions1975 = {
			//chart: {
				//renderTo: 'sp-return-chart',
				//type: 'line'
			//},
			chart: {
            	events: {
                	load: function () {
                		addSPReturnsData(1975);
                		calculateScrollTrigger();
                	}
                }
            },
			rangeSelector: {
				enabled: false
			},
			navigator: {
				enabled: false
			},
			scrollbar: {
				enabled: false
			},
			yAxis: {
				title: {
					text: '10 Year Treasury Yield'
				},
				opposite: false,
				labels : {
					format : '{value}%'
				}
			},
			xAxis : {
				type: 'datetime',
				//tickPositions : [157788000000, 473407200000, 788940000000, 1104559200000,  1420092000000],
				labels : {
					format : '{value:%Y}'
				},
			},	
			plotOptions: {
				series: {
					animation: false
				}
			},
			tooltip: {
				formatter: function() {
					var s = '<small style="font-size: 10px;">' + Highcharts.dateFormat('%b %e, %Y', this.x) + '</small><br />';
					$.each(this.points, function(i, point) {
						s += '<span style="color: ' + point.series.color + ';">•</span> ' + point.series.name + ' ' + ': <b>' + parseFloat(point.y).toFixed(2) + '</b><br />';
					});
					return s;
				}
			},
			series: [{
				name : '10 Year Treasury Yield',
				tooltip: {
					valueDecimals: 1
				}
			}]
		};
		
		// 1975-1985
		$.getJSON('../data/q2-2015/did-you-know/10-year-tsy-1975.js', function (data) {
			spReturnOptions1975.series[0].data = data;
			$("#sp-return-chart-1975").highcharts("StockChart", spReturnOptions1975);			
		});
	}

	// Chapter 7: Asset Class Performance and Strategic Models
	if ( $('.additional-resources-appendix').length ) {

		// Global Chart Options for Pie Charts
		Highcharts.setOptions({
			chart: {
				backgroundColor: '#f3f1e9',
				type: 'pie',
				plotBackgroundColor: null,
				plotBorderWidth: null,
				plotShadow: false
			},
			plotOptions: {
				pie: {
					allowPointSelect: true,
					cursor: 'pointer',
					dataLabels: {
						enabled: false
					},
					showInLegend: true,
					colors: ["#d9c681", "#9bcade", "#5599ca", "#1b5b89", "#811338", "#a86caa", "#ad90af", "#12643c", "#b0bc40", "#efae6e", "#fadf9a", "#7ea13d", "#c1d58d", "#fad642"]
				}
			},
			tooltip: {
				pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
			},
			legend: {
				enabled: false
			},
			credits: {
				enabled: false
			},
			title: {
				text: null
			},
			navigation: {
				buttonOptions: {
					enabled: false
				}
			}
		});


		// Conservative Income
		var conservativeIncomeJson = '../data/q2-2015/additional-resources/conservative-income.js';
		var conservativeIncomeOptions = {
			chart: {
				renderTo: 'conservative-income-pie-chart',
				events: {
					load: function () {
						displayPieChartLegend(conservativeIncomeJson, 'conservative-income-pie-chart');
					}
				}
			},
			series: [{}]
		};

		$.getJSON(conservativeIncomeJson, function(data) {
			conservativeIncomeOptions.series[0].name = 'Conservative Income';
			conservativeIncomeOptions.series[0].data = data;

			var chart = new Highcharts.Chart(conservativeIncomeOptions);
		});

		// Moderate Income
		var moderateIncomeJson = '../data/q2-2015/additional-resources/moderate-income.js';
		var moderateIncomeOptions = {
			chart: {
				renderTo: 'moderate-income-pie-chart',
				events: {
					load: function () {
						displayPieChartLegend(moderateIncomeJson, 'moderate-income-pie-chart');
					}
				}
			},
			series: [{}]
		};

		$.getJSON(moderateIncomeJson, function(data) {
			moderateIncomeOptions.series[0].name = 'Moderate Income';
			moderateIncomeOptions.series[0].data = data;

			var chart = new Highcharts.Chart(moderateIncomeOptions);
		});

		// Long-term Income
		var longtermIncomeJson = '../data/q2-2015/additional-resources/long-term-income.js';
		var longtermIncomeOptions = {
			chart: {
				renderTo: 'long-term-income-pie-chart',
				events: {
					load: function () {
						displayPieChartLegend(longtermIncomeJson, 'long-term-income-pie-chart');
					}
				}
			},
			series: [{}]
		};

		$.getJSON(longtermIncomeJson, function(data) {
			longtermIncomeOptions.series[0].name = 'Long-Term Income';
			longtermIncomeOptions.series[0].data = data;

			var chart = new Highcharts.Chart(longtermIncomeOptions);
		});

		// Conservative Growth and Income
		var conservativeGrowthAndIncomeJson = '../data/q2-2015/additional-resources/conservative-growth-and-income.js';
		var conservativeGrowthAndIncomeOptions = {
			chart: {
				renderTo: 'conservative-growth-and-income-pie-chart',
				events: {
					load: function () {
						displayPieChartLegend(conservativeGrowthAndIncomeJson, 'conservative-growth-and-income-pie-chart');
					}
				}
			},
			series: [{}]
		};

		$.getJSON(conservativeGrowthAndIncomeJson, function(data) {
			conservativeGrowthAndIncomeOptions.series[0].name = 'Conservative Growth and Income';
			conservativeGrowthAndIncomeOptions.series[0].data = data;

			var chart = new Highcharts.Chart(conservativeGrowthAndIncomeOptions);
		});

		// Moderate Growth and Income
		var moderateGrowthAndIncomeJson = '../data/q2-2015/additional-resources/moderate-growth-and-income.js';
		var moderateGrowthAndIncomeOptions = {
			chart: {
				renderTo: 'moderate-growth-and-income-pie-chart',
				events: {
					load: function () {
						displayPieChartLegend(moderateGrowthAndIncomeJson, 'moderate-growth-and-income-pie-chart');
					}
				}
			},
			series: [{}]
		};

		$.getJSON(moderateGrowthAndIncomeJson, function(data) {
			moderateGrowthAndIncomeOptions.series[0].name = 'Moderate Growth and Income';
			moderateGrowthAndIncomeOptions.series[0].data = data;

			var chart = new Highcharts.Chart(moderateGrowthAndIncomeOptions);
		});

		// Long-term Growth and Income
		var longtermGrowthAndIncomeJson = '../data/q2-2015/additional-resources/long-term-growth-and-income.js';
		var longtermGrowthAndIncomeOptions = {
			chart: {
				renderTo: 'long-term-growth-and-income-pie-chart',
				events: {
					load: function () {
						displayPieChartLegend(longtermGrowthAndIncomeJson, 'long-term-growth-and-income-pie-chart');
					}
				}
			},
			series: [{}]
		};

		$.getJSON(longtermGrowthAndIncomeJson, function(data) {
			longtermGrowthAndIncomeOptions.series[0].name = 'Long-Term Growth and Income';
			longtermGrowthAndIncomeOptions.series[0].data = data;

			var chart = new Highcharts.Chart(longtermGrowthAndIncomeOptions);
		});

		// Conservative Growth
		var conservativeGrowthJson = '../data/q2-2015/additional-resources/conservative-growth.js';
		var conservativeGrowthOptions = {
			chart: {
				renderTo: 'conservative-growth-pie-chart',
				events: {
					load: function () {
						displayPieChartLegend(conservativeGrowthJson, 'conservative-growth-pie-chart');
					}
				}
			},
			series: [{}]
		};

		$.getJSON(conservativeGrowthJson, function(data) {
			conservativeGrowthOptions.series[0].name = 'Conservative Growth';
			conservativeGrowthOptions.series[0].data = data;

			var chart = new Highcharts.Chart(conservativeGrowthOptions);
		});

		// Moderate Growth
		var moderateGrowthJson = '../data/q2-2015/additional-resources/moderate-growth.js';
		var moderateGrowthOptions = {
			chart: {
				renderTo: 'moderate-growth-pie-chart',
				events: {
					load: function () {
						displayPieChartLegend(moderateGrowthJson, 'moderate-growth-pie-chart');
					}
				}
			},
			series: [{}]
		};

		$.getJSON(moderateGrowthJson, function(data) {
			moderateGrowthOptions.series[0].name = 'Moderate Growth';
			moderateGrowthOptions.series[0].data = data;

			var chart = new Highcharts.Chart(moderateGrowthOptions);
		});

		// Long-term Growth
		var longtermGrowthJson = '../data/q2-2015/additional-resources/long-term-growth.js';
		var longtermGrowthOptions = {
			chart: {
				renderTo: 'long-term-growth-pie-chart',
				events: {
					load: function () {
						displayPieChartLegend(longtermGrowthJson, 'long-term-growth-pie-chart');
					}
				}
			},
			series: [{}]
		};

		$.getJSON(longtermGrowthJson, function(data) {
			longtermGrowthOptions.series[0].name = 'Long-Term Growth';
			longtermGrowthOptions.series[0].data = data;

			var chart = new Highcharts.Chart(longtermGrowthOptions);
		});
	}
}); // document ready


$(window).bind('resize', function () {

	if (( $('.chapter').length ) || ( $('.appendix').length )) {
		// Position Fixed Chapter Navigation
		calculateScrollTrigger();
		hideFixedChapterNavigation();
	}

	if ( $('.chapter').length ) {	
		// Fix Chapter Background
		if ( Modernizr.mq('only screen and (min-width: 50.625em)') ) {
			if ( !($('header').hasClass('fixed-header')) ) {
				fixedHeader();
			}

			$('.js-bg-fix').remove();
			fixChapterBackground();
		}
		else {
			$('header').removeClass('fixed-header');
			$('main').removeAttr('style');
			$('.js-bg-fix').remove();
		}
	}

	if ( $('.chapter').length || $('.appendix').length) {
		positionBackToTop();
	}

	// Video Container Widths
	if (( $('.video-container').length ) && ( !($('.lt-ie9').length) )) {
		setVideoContainerWidths();
	}
	
	if ( $('.did-you-know-chapter').length ) {
		setTimeout(function(){
			didYouKnowChartResized = true;
			addSPReturnsData();
		}, 500);
	}
	
});

// Force page to scroll to top if not doing so already on load
$(window).load(function() {
    $(window).scrollTop(0);
});

$(window).bind('scroll', function () {
	didScroll = true;
});

setInterval(function() {
	if ( didScroll ) {
		didScroll = false;

		if (( $('.chapter').length ) || ( $('.appendix').length )) {
			hideFixedChapterNavigation();
		}

		if ( ( Modernizr.mq('only screen and (min-width: 50.625em)') ) || ( $('.lt-ie9').length ) ) {
			if ( ($(document).scrollTop()) > 0 ) {
				reducedFixedHeader();
			}
			else {
				fullFixedHeader();
			}
		}
	}
}, 150);