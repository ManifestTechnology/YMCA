window.console = window.console || {log: function() {}, warn: function() {}};

/**
* jQuery Plugin to obtain touch gestures from iPhone, iPod Touch and iPad, should also work with Android mobile phones (not tested yet!)
* Common usage: wipe images (left and right to show the previous or next image)
* 
* @author Andreas Waltl, netCU Internetagentur (http://www.netcu.de)
* @version 1.1.1 (9th December 2010) - fix bug (older IE's had problems)
* @version 1.1 (1st September 2010) - support wipe up and wipe down
* @version 1.0 (15th July 2010)
*/
(function ($) { $.fn.touchwipe = function (settings) { var config = { min_move_x: 20, min_move_y: 20, wipeLeft: function () { }, wipeRight: function () { }, wipeUp: function () { }, wipeDown: function () { }, preventDefaultEvents: true }; if (settings) $.extend(config, settings); this.each(function () { var startX; var startY; var isMoving = false; function cancelTouch() { this.removeEventListener('touchmove', onTouchMove); startX = null; isMoving = false } function onTouchMove(e) { if (config.preventDefaultEvents) { e.preventDefault() } if (isMoving) { var x = e.touches[0].pageX; var y = e.touches[0].pageY; var dx = startX - x; var dy = startY - y; if (Math.abs(dx) >= config.min_move_x) { cancelTouch(); if (dx > 0) { config.wipeLeft() } else { config.wipeRight() } } else if (Math.abs(dy) >= config.min_move_y) { cancelTouch(); if (dy > 0) { config.wipeDown() } else { config.wipeUp() } } } } function onTouchStart(e) { if (e.touches.length == 1) { startX = e.touches[0].pageX; startY = e.touches[0].pageY; isMoving = true; this.addEventListener('touchmove', onTouchMove, false) } } if ('ontouchstart' in document.documentElement) { this.addEventListener('touchstart', onTouchStart, false) } }); return this } })(jQuery);

var app = app || {};
app.tabs = {
    sampleConfigObject: {
        selectorForTabListOrTableOfContents: "ul.tabs",
        selectorForElementsToShowAndHide: "div#main div.tabContent",
        selectorForLinksToElementsToShowAndHide: "a.tabLink",
        //if this is false, the first item will not be selected & shown by default, and clicking an item a second time will hide it
        oneItemAlwaysSelected: true, 
        initializeImmediately: false
    },
    register: function (configObj) {
    	if (configObj.initializeImmediately) {
			this.init(configObj);
        }
        else {
        	var that = this;
			$(document).ready(function () {
				that.init(configObj);
			});
        }
    },
    init: function (configObj) {
        var $anchorContentElements = $(configObj.selectorForElementsToShowAndHide).hide();
        var tocLinksSelector = configObj.selectorForTabListOrTableOfContents;
        var $toc = $(tocLinksSelector); //toc = table of contents (or tabs) 
        var $tocLinks = $toc.find('a');
        var $allLinksToAnchorContent = $(configObj.selectorForLinksToElementsToShowAndHide);
        this.handleChapterClicks($allLinksToAnchorContent, tocLinksSelector, $tocLinks, configObj.oneItemAlwaysSelected);
        this.showInitialChapter($anchorContentElements, $toc, configObj.oneItemAlwaysSelected);
    },
    handleChapterClicks: function ($allLinksToAnchorContent, tocLinksSelector, $tocLinks, oneItemAlwaysSelected) {
        var that = this;
        $allLinksToAnchorContent.click(function (e) {
            e.preventDefault();
            var link = $(this);
            var tocContainer = link.closest(tocLinksSelector);
            if (tocContainer.length > 0) {
                that.showChapter(link, oneItemAlwaysSelected);
            }
            else {
                //this handles link external to tab module that show/hide specific tab content pane
                $tocLinks.filter('a[href="' + link.attr("href") + '"]').click();
            }
        });
    },
    showChapter: function ($tocLink, oneItemAlwaysSelected) {
        var chapterLink = $tocLink.attr("href");
        var $chapter = $(chapterLink);
        if (oneItemAlwaysSelected) {
            $chapter.show().addClass("visibleTab").siblings().hide().removeClass("visibleTab");
            $tocLink.closest("li").addClass("selected").siblings().removeClass("selected");
        }
        else {
            $chapter.toggle().siblings().hide();
            $tocLink.closest("li").toggleClass("selected").siblings().removeClass("selected");
        }
        $tocLink.trigger("blur");
        
        //redraw ordered lists within just-shown chapter ONLY IN IE 9
        //this addresses IE 9-only bug where each item's number in an ordered list shows 0 after their parent elements have been set to display: none (which is used in the hide/show above)
        if (navigator.appVersion.indexOf("MSIE 9.") != -1) {
			$chapter.find("ol").hide().children().first().hide(1, function() {
				$(this).show();
			}).end().end().show();
        }
    },

    getUrlHash: function ($anchorContentElements) {
        var chapterUrlHash = null;
        var hash = window.location.hash;
        if (hash) {
            var hashWithoutPoundSign = (hash.charAt(0) == "#") ? hash.substring(1) : hash;
            var hashArr = hashWithoutPoundSign.split(",");
            var chapterElementIds = [];
            $anchorContentElements.each(function (index) {
                var id = $(this).attr("id");
                if (id) {
                    chapterElementIds.push(id);
                }
            });

            for (var i = 0; i < hashArr.length; i++) {
                var hashValue = hashArr[i];
                for (var j = 0; j < chapterElementIds.length; j++) {
                    var tabContentId = chapterElementIds[j];
                    //alert("tabContentId: " + tabContentId + " hashValue: " + hashValue);
                    if (hashValue == tabContentId) {
                        return "#" + tabContentId;
                    }
                }
            }
        }
        return chapterUrlHash;
    },
    showInitialChapter: function ($anchorContentElements, $tocList, showFirstTab) {
        var $tocLinks = $tocList.find("a");
        var urlHash = this.getUrlHash($anchorContentElements);
        if (urlHash) {
            //window.scroll(0, 0);
            window.location.hash = "";
            $tocLinks.filter('a[href="' + urlHash + '"]').click();
        }
        else if (showFirstTab) {
            $tocList.each(function () {
                //console.log("tocList", this);
                $(this).find("a").first().trigger("click");
            });
        }
    }
};

app.shell = {
	viewportWidth: 1200, 
	smallViewport: false,
	
	init: function() {
		this.setSmallViewport();
		
		this.mobileHeaderMenu.init();
		this.desktopHeaderMenu.init();

		this.solutionsForMenu.init();
		this.populateEmailLink();
		this.addDropdownCloseToggleEvents();
		
		var that = this;
		$(window).on("resize", function() {
			if (this.resizeTO) {
				clearTimeout(this.resizeTO);
			}
			this.resizeTO = setTimeout(function() {
				//console.log("done resizing. trigger viewportTypeChanged if the value of smallViewport has changed, and resizeEnd in either case");
				var oldMobileMenuDisplayValue = that.mobileMenuDisplayValue;
				that.setSmallViewport();
				//console.log("small viewport bool has changed from " + oldSmallViewportValue + " to " + that.smallViewport);
				if (oldMobileMenuDisplayValue !== that.mobileMenuDisplayValue) {
					//console.log("viewport header type changed");
					$(window).trigger({
						type: "viewportTypeChanged"
					});
				}
				//console.log("resizeEnd");
				$(window).trigger({
					type: "resizeEnd"
				});
			}, 200);
		});
	}, 
	populateEmailLink: function() {
		var $container = $("div.aux");
		if ($container.length) {
			var $emailLink;
			$container.find("a").each(function(i, elem) {
				var $a = $(elem);
				var linkText = $a.text();
				if (linkText && linkText.toLowerCase().indexOf("email") > -1) {
					if (!$a.attr("href")) { //only replace url if the existing url is blank
						$emailLink = $a;
					}
					return false;
				}
			});
			if ($emailLink) {			
				var subject = document.title || "Page on UHC.edu";
				var body = "I'd like to share this page on UHC.edu with you.";
				var url = window.location.href;
		
				var mailtoLink = "mailto:?" + "subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body) + "%0A%0A" + encodeURIComponent(url);
				
				$emailLink.attr("href", mailtoLink);
			}
		}
	}, 
	getDropdownCloseMarkup: function() {
		return "<p class='close'><a href=''><span>Close</span></a></p>";
	}, 
	addDropdownCloseToggleEvents: function() {
		$("body").on("click", "p.close a", function(e) {
			var $associatedNavigationLink = $(this).closest("div.dropdown").data("navItem");
			if ($associatedNavigationLink) {
				$associatedNavigationLink.trigger("click");
			}
			e.preventDefault();
		});
	}, 
	getPopulatedDropdownContainer: function($content, $triggerLink) {
		if (!this.dropdownContainer) {
			var $headerContainer = $triggerLink.closest("div.header");
			if (!$headerContainer.length) {
				$headerContainer = $triggerLink.closest("div.mheader");
			}
			
			var $dropdownContainer = $headerContainer.find("div.dropdown");
			if ($dropdownContainer.length && false) {
				this.dropdownContainer = $dropdownContainer;
			}
			else {
				this.dropdownContainer = $("<div class='dropdown'></div>").hide();
				var $elemToPrependTo = $headerContainer.children("div.solutionsfor");
				if (!$elemToPrependTo.length) {
					$elemToPrependTo = $headerContainer.find("div.uhcnav");
				}
				
				if ($elemToPrependTo.length) {
					$elemToPrependTo.before(this.dropdownContainer);
				}
				else {
					this.dropdownContainer.appendTo($headerContainer);
				}
			}
		}
		this.dropdownContainer.hide().empty().html($content).append(app.shell.getDropdownCloseMarkup()).data("navItem", $triggerLink);
		
		return this.dropdownContainer;
	}, 
	desktopHeaderMenu: {
		init: function() {
			this.enableHeaderClickability();
			
			this.toggleDropdownOnHeaderClick();
	
			this.makeKeyboardFocusedSpansClickable();
			
			var that = this;
			$(window).on("viewportTypeChanged", function() {
				that.enableHeaderClickability();
				that.resetDesktopMenu();
			});
			
			//hide menu on left swipe
			$("body").touchwipe({
				wipeLeft: function (e) {
					if ($("body").hasClass("withMobileMenu")) {
						$("ul.mobilemenu").children("li.nav").children("a").trigger("click");
					}
				},
				wipeRight: function () {},
				min_move_x: 20,
				min_move_y: 20,
				preventDefaultEvents: false
			});
		}, 
		makeKeyboardFocusedSpansClickable: function() {
			$("span").on("keyup", function(e) {
				if (e.which == 13) {
					$(this).trigger("click");
					return false;
				}
			});
		}, 
			
		
		
		toggleDropdownOnHeaderClick: function() {
			var that = this;
			$("div.nav").on("click", "span.head.clickable", function(e) {
				var $navItem = $(this);
				var $navItemLi = $navItem.closest("li");
				var $dropdown;
				
				if (!$navItemLi.hasClass("selected")) {
					var $div = $("<div />");
					var $innerWrappedContents = $div.clone().html($navItemLi.children("ul").clone()).addClass("inner");
					var $dropdownContents = $div.html($innerWrappedContents).addClass("navlist");
					
					$dropdown = app.shell.getPopulatedDropdownContainer($dropdownContents, $navItem);
				}
				else {
					$dropdown = $("div.dropdown");
				}
				
				$navItemLi.toggleClass("selected").siblings(".selected").removeClass("selected");
				$dropdown.slideToggle(200);
				$navItem.trigger("blur");
			});
			$("div.auxnav").on("click", "span.head.clickable", function(e) {
				var $navItem = $(this);
				var $navItemLi = $navItem.closest("li");
				
				if (!$navItemLi.hasClass("selected")) {
					app.genericCarousel.pause();
					
					//close menu if clicking elsewhere on document
					$("body").on("click", function(e) {
						$(this).off("click");
						$navItem.trigger("click");
					});
				}
				else {
					app.genericCarousel.unpause();
					
					$("body").off("click");
				}
				
				$navItemLi.children("ul").fadeToggle(200, function() {
					$navItemLi.toggleClass("selected");
					$(this).removeAttr("style");
				});
				$navItem.trigger("blur");
				
				return false;
			});
		}, 
		enableHeaderClickability: function() {
			if (app.shell.smallViewport) {
				$("div.nav").find("span.head.clickable").removeClass("clickable").removeAttr("tabIndex");
			}
			else {
				$("div.header").find("span.head").addClass("clickable").attr("tabIndex", "0");
			}
			$("div.mheader").find("span.head").addClass("clickable").attr("tabIndex", "0");
		}, 
		resetDesktopMenu: function() {
			//$("div.dropdown").empty().removeAttr("style");
			$("div.dropdown").hide();
			$("div.header").find("li.selected").removeClass("selected");
		}
	}, 
	setSmallViewport: function() {
		this.viewportWidth = Math.max($(window).width(), $("body").width());
		this.mobileMenuDisplayValue = $("ul.mobilemenu").css("display");
		this.smallViewport = (this.mobileMenuDisplayValue != "none");
		//console.log("small viewport?", this.smallViewport);
	}, 
	mobileHeaderMenu: {
		init: function() {
			var $elem = $("ul.mobilemenu");			
			this.reset($elem);
			
			var that = this;
			$elem.on("click", "a", function(e) {
				var $a = $(this);
				var $li = $a.closest("li");
				if ($li.hasClass("login")) {
					that.toggleItemDisplay($a);
				}
				else if ($li.hasClass("search")) {
					that.toggleItemDisplay($a);
				}
				else if ($li.hasClass("nav")) {
					that.toggleNav($a);
				}
				e.preventDefault();
			});
			
			var that = this;
			$(window).on("viewportTypeChanged", function() {
				that.reset($elem);
			});
		}, 
		getAssociatedDomElem: function($a) {
			return $($a.attr("href"));
		}, 
		reset: function($elem) {
			//console.log("resetting mobile menu");
			var that = this;
			$elem.children().filter(".selected").removeClass("selected").end().find("a").each(function() {
				that.getAssociatedDomElem($(this)).removeAttr("style").removeClass("dropdown");
			});
			
			this.resetMobileNavMenu();
		},
		toggleNav: function($a) {
			var $navElement = this.getAssociatedDomElem($a);
			this.toggleMobileNavMenu($navElement);
			this.closeOpenSiblings($a);
			$a.closest("li").siblings(".selected").removeClass("selected");
		},
		toggleMobileNavMenu: function ($menu) {
			var duration = 200;
			var $body = $("body");
			var $page = $("div.page").first();
			var that = this;

			if ($body.hasClass("withMobileMenu")) {
				$page.animate({
					left: "0"
				}, duration, function () {
					$(this).removeAttr("style");
					$menu.removeAttr("style");
					$body.removeClass("withMobileMenu");
					that.mobileMenuIsVisible = false;
				});
			}
			else {
				$body.addClass("withMobileMenu");
				$menu.children().addBack().show();
				$page.css({
					"position": "relative",
					width: $(window).width()
				}).animate({
					left: "260px"
				}, duration);
				that.mobileMenuIsVisible = true;
			}
		},
		resetMobileNavMenu: function() {
			$("body").removeClass("withMobileMenu")
			$("div.page").removeAttr("style");
			$("div.nav").removeAttr("style");
		}, 
		toggleItemDisplay: function($a) {
			var $elemToShowOrHide = this.getAssociatedDomElem($a);
			var $dropdown;
			var linkWasSelected = $a.closest("li").hasClass("selected");
			if (!linkWasSelected) {
				$dropdown = app.shell.getPopulatedDropdownContainer($elemToShowOrHide.clone(), $a);
			}
			else {
				$dropdown = $("div.dropdown");
			}
			var that = this;
			$dropdown.slideToggle(300, function(e) {
				that.toggleNavItemSelection($a);
				if (linkWasSelected) {
					$dropdown.empty();
				}
			});
			
			this.closeOpenSiblings($a);
		}, 
		closeOpenSiblings: function($a) {
			$a.closest("li").siblings(".selected").each(function(i) {
				$($(this).find("a").attr("href")).removeAttr("style").removeClass("dropdown");
			});
		}, 
		toggleNavItemSelection: function($a) {
			$a.closest("li").toggleClass("selected").siblings(".selected").removeClass("selected");
		}
	}, 
	solutionsForMenu: {
		headingHasDropdownStyle: null, 
		init: function() {
			var $elem = $("div.solutionsfor").addClass("collapsed");
			if ($elem.length) {
				this.initializeDropdown($elem);
				this.addClickEvents($elem);

				var that = this;
				$(window).on("resizeEnd", function() {
					that.initializeDropdown($elem);
				});
			}
		}, 
		addClickEvents: function($elem) {
			$elem.on("click", "p.clickable", function(e) {
				$elem.find("ul").slideToggle(200, function(e) {
					$elem.toggleClass("collapsed");
					$(this).removeAttr("style");
				});
				e.preventDefault();
			});
		}, 
		initializeDropdown: function($elem) {
			var $heading = $elem.find("p");
			var headingHasDropdownStyle = ($heading.css("paddingLeft") != "0px");
			
			if (headingHasDropdownStyle != this.headingHasDropdownStyle) {
				//console.log("initialize");
				if (headingHasDropdownStyle) {
					$heading.addClass("clickable").end().addClass("collapsed");
				}
				else {
					$heading.removeClass("clickable").end().removeClass("collapsed");
				}
				this.headingHasDropdownStyle = headingHasDropdownStyle;
			}
			else {
				//console.log("window was resized but type hasn't changed.");
			}
		}
	}
};

app.backtotop = {
    scrollDistance: 500,
    init: function () {
        var that = this;
        $(document).ready(function () {
            that.$document = $(document);
            var $footer = $("div.footer");
            var clearedFooterHeight = $footer.outerHeight() + 20;
            that.$bttElem = $("p.btt").css({ right: "auto", left: "-999em" }).show().removeAttr("style").css("bottom", clearedFooterHeight + "px");

            $(window).on("scroll", function () {
                that.toggleVisibility(that.$document);
            });
        });
    },
    toggleVisibility: function ($scrollingElem) {
        if ($scrollingElem.scrollTop() > this.scrollDistance) {
            this.$bttElem.fadeIn();
        }
        else {
            this.$bttElem.fadeOut();
        }
    }
};

app.leftColumnToDropdown = {
	init: function() {
		var that = this;
		$("div.col-secondary").each(function() {
			var $sidebar = $(this);
			var $heading = that.getSidebarHeading($sidebar);
			var $sidebarContent = $sidebar.children().not($heading);
			$("<div />").addClass("columncontent").html($sidebarContent).insertAfter($heading);
			
			$heading.on("click", function(e) {
				$sidebar.children("div.columncontent").slideToggle(500, function() {
					$sidebar.toggleClass("expanded");
				});
			}).addClass("clickable");
			
		});
		
		//sidebar heading is visible only in the small viewport version
		var $dropdowntriggers = $(".sidebartitle");
		$(window).on("resizeEnd", function() {
			$dropdowntriggers.each(function() {
				var $heading = $(this);
				if (!($heading.css("display") != "none")) {
					$heading.siblings().removeAttr("style");
					$heading.closest("div.col-secondary").removeClass("expanded");
				}
			});
		});
	}, 
	getSidebarHeading: function($sidebar) {
		var $headingElem = $sidebar.find(".sidebarhead").first();
		var headingText = $headingElem.html();
		if (!headingText) {
			headingText = "View page sidebar";
		}
		return $("<h2 class='sidebartitle'>" + headingText + "</h2>").prependTo($sidebar);
	}
};

app.forms = {
    init: function () {
        this.placeholders.init();
        //this.addPrevAndNextToPagesList.init();
        this.disableDoubleSubmit();

        //add code to set select widths to auto (for IE only since only IE has this problem)
        var isIE = /*@cc_on!@*/false;
        if (isIE) {
            this.ieSelects.init();
        }
    },
    ieSelects: {
        init: function () {
            var that = this;
            $("div.main").find("select").each(function () {
                var $select = $(this);
                $select.after($select.clone().addClass("cloned").css({
                    position: "absolute",
                    marginLeft: "-" + $select.outerWidth(true) + "px",
                    minWidth: $select.width()
                }).on("mousedown", function () {
                    $(this).css("width", "auto");
                }).on("blur", function () {
                    that.undoAutoWidth($(this), $select);
                }).on("change", function () {
                    that.undoAutoWidth($(this), $select);
                })).css({
                    visibility: "hidden"
                }).attr("tabIndex", "-1").removeAttr("name").removeAttr("id");
            });
        },
        undoAutoWidth: function ($selectClone, $originalSelect) {
            $selectClone.css("width", $originalSelect.width());
        }
    },
    disableDoubleSubmit: function() {
    	$("form").on("submit", function(e) {
    		$(this).find("*[type=submit]").attr("disabled", "disabled");
    	}).find("*[type=submit]").removeAttr("disabled");
    }, 
    addPrevAndNextToPagesList: {
    	init: function() {
    		var that = this;
    		$("div.pages ul").each(function() {
    			that.addPrevAndNextLis($(this));
    		});
    	}, 
    	addPrevAndNextLis: function($ul) {
			$ul.prepend("<li class='prev'><a href=''><span class='access'>Previous</span>&lsaquo;</a></li>");
			$ul.append("<li class='next'><a href=''><span class='access'>Next</span>&rsaquo;</a></li>");
			this.enablePrevAndNext($ul);
			this.addPrevAndNextClickEvents($ul);
    	}, 
    	addPrevAndNextClickEvents: function($ul) {
    		var that = this;
    		$ul.on("click", "a", function(e) {
    			var $a = $(this);
    			var $li = $a.closest("li");
    			
    			if ($li.hasClass("disabled")) {
    				return false;
    			}
    			
    			if ($li.hasClass("prev") || $li.hasClass("next")) {
    				var $selectedLi = that.getSelectedItem($ul);
    				var $liToSelect;
    				
    				if ($li.hasClass("prev")) {
    					$liToSelect = $selectedLi.prev();
					}
					else if ($li.hasClass("next")) {
						$liToSelect = $selectedLi.next();
					}
					
					if (!$liToSelect.hasClass("disabled") && !$liToSelect.hasClass("prev") && !$liToSelect.hasClass("next")) {
						$liToSelect.children("a")[0].click();
						//$liToSelect.children("a").closest("li").addClass("active").siblings().removeClass("active");
					}
					
    				e.preventDefault();
    			}
    		});
    	}, 
    	getSelectedItem: function($ul) {
    		var $lis = $ul.children();
    		var $selectedLi = $lis.filter(".active");
    		return $selectedLi;
    	},
    	enablePrevAndNext: function($ul) {
    		var $lis = $ul.children();
    		var $selectedLi = $lis.filter(".active");
    		var $prevLink = $lis.filter(".prev");
    		var $nextLink = $lis.filter(".next");
    		
    		var $liBeforeActive = $selectedLi.prev();
    		if ($liBeforeActive.length && !$liBeforeActive.hasClass("prev")) {
    			$prevLink.removeClass("disabled");
    		}
    		else {
    			$prevLink.addClass("disabled");
    		}
    		
    		var $liAfterActive = $selectedLi.next();
    		if ($liAfterActive.length && !$liAfterActive.hasClass("next")) {
    			$nextLink.removeClass("disabled");
    		}
    		else {
    			$nextLink.addClass("disabled");
    		}
    	}
    }, 
    placeholders: {
        init: function () {
            if (!this.browserSupportsPlaceholders()) {
                var that = this;
                $("input[placeholder]").each(function () {
                	var $input = $(this);
                	if ($input.is("input[type=password]")) {
                		var $inputProxy = $("<input />").data("original", $input).attr("placeholder", $input.attr("placeholder")).attr("class", $input.attr("class"));
                		that.setValueToPlaceholder($inputProxy);
                		$inputProxy.insertAfter($input).on("focus", function() {
            				$(this).hide().data("original").show().focus(); 		
                		});
                		$input.hide().on("blur", function() {
                			var value = $input.val();
                			if (!value) {
                				$input.hide().next("input").show();
                			}
                		});
                	}
                	else {
						$input.on("focus", function () {
							that.removePlaceholderValue($(this));
						}).on("blur", function () {
							that.setValueToPlaceholder($(this));
						}).closest("form").on("submit", function () {
							$(this).find("input.placeholderAsValue").each(function () {
								that.removePlaceholderValue($(this));
							});
						});
						that.setValueToPlaceholder($input);
                    }
                });
            }
        },
        setValueToPlaceholder: function ($input) {
            var placeholder = $input.attr("placeholder");
            var value = $input.val();
            if (!value || value == placeholder) {
                $input.val(placeholder).addClass("placeholderAsValue");
            }
            else {
                $input.removeClass("placeholderAsValue");
            }
        },
        removePlaceholderValue: function ($input) {
            var placeholder = $input.attr("placeholder");
            var value = $input.val();
            if (value && value == placeholder) {
                $input.val("").removeClass("placeholderAsValue");
            }
        },
        browserSupportsPlaceholders: function () {
            var i = document.createElement("input");
            return ("placeholder" in i);
        }
    }
};

app.modal = {
	init: function() {
		this.initializeMarketingHomeVideo();
		
		var that = this;
		$(window).on("resizeEnd", function() {
			that.initializeMarketingHomeVideo();
		});
	},
	
	initializeMarketingHomeVideo: function() {
		var that = this;
		
		var $youtubeLink = $("div.intelligence").find("a[href*='youtube.com/']");
		if ($youtubeLink.length) {
			var oldSmallViewportValue = this.getSmallViewportValue($youtubeLink);
			this.setSmallViewport($youtubeLink);
			var updatedSmallViewportValue = this.getSmallViewportValue($youtubeLink);
			if (oldSmallViewportValue !== updatedSmallViewportValue) {
				//console.log("small viewport value changed to", updatedSmallViewportValue);
				if (!updatedSmallViewportValue) {
					this.initializeMarketingHomeVideoModal($youtubeLink);
				}
				else {
					this.initializeInlineVideo($youtubeLink);
				}
			}
			if (updatedSmallViewportValue) {
				this.scaleVideoHeightToWidth($youtubeLink.next("iframe"));
			}
		}
	}, 
	getSmallViewportValue: function($youtubeLink) {
		return $youtubeLink.data("smallViewport");
	}, 
	setSmallViewport: function($youtubeLink) {
		//var videoWidth = $youtubeLink.attr("data-videowidth") || 800;
		//var videoHeight = $youtubeLink.attr("data-videoheight") || 600;
		
		var smallViewport = (app.shell.viewportWidth < 700);
		$youtubeLink.data("smallViewport", smallViewport);
	},
	initializeMarketingHomeVideoModal: function($youtubeLink) {
		this.addHtml();
		
		var that = this;
		$youtubeLink.show().on("click", function(e) {
			that.showYoutubeVideoIframe($(this));
			return false;
		}).next("iframe").remove();
	}, 
	initializeInlineVideo: function($youtubeLink) {
		var $youtubePlayerElem = $(this.getYoutubePlayerHtml($youtubeLink, false));
		$youtubeLink.after($youtubePlayerElem).hide();
	}, 
	scaleVideoHeightToWidth: function($iframe) {
		var widthAttr = $iframe.attr("width");
		var heightAttr = $iframe.attr("height");
		var currentWidth = $iframe.width();
		if (currentWidth && widthAttr && heightAttr && (widthAttr != currentWidth)) {
			var scaledHeight = currentWidth * heightAttr / widthAttr;
			$iframe.css("height", scaledHeight);
		}
	},
	addHtml: function() {
		if (!$("#overlay").length) {
			this.$body = $("body");
		
			var that = this;
			this.$overlay = $('<div id="overlay" />').appendTo(this.$body).on("click", function(e) {
				that.close();
			});
			this.$overlayContentWrapper = $('<div id="overlay-content" />').appendTo(this.$body).on("click", "a.close", function(e) {
				that.close();
				return false;
			});
		}
	}, 
	getYoutubePlayerHtml: function($youtubelink, autoplay) {
		var videoId = this.getYoutubeVideoId($youtubelink.attr("href"));
		var protocol = ("https:" == document.location.protocol) ? "https" : "http";
		var autoplayAttribute = (autoplay) ? "autoplay=1" : "";
		//return '<iframe class="youtube-player" type="text/html" width="640" height="360" src="' + protocol + '://www.google.com/' + videoId + '?' + autoplayAttribute + '" allowfullscreen="allowfullscreen" frameborder="0"></iframe>';
		return '<iframe class="youtube-player" type="text/html" width="640" height="360" src="' + protocol + '://www.youtube.com/embed/' + videoId + '?' + autoplayAttribute + '" allowfullscreen="allowfullscreen" frameborder="0"></iframe>';
	}, 
	getYoutubeVideoId: function(url) {
		//http://www.youtube.com/watch?v=bf8Itx8swpc
		//http://www.youtube.com/embed/bf8Itx8swpc
		
		var delimitingChars = ["/", "&", "?"];
		var trimExtraDataFromIdEnd = function(str) {
			var delimitingCharIndexes = [];
			if (str) {
				for (var i = 0; i < delimitingChars.length; i++) {
					var delimitingCharIndex = str.indexOf(delimitingChars[i]);
					if (delimitingCharIndex > 0) {
						delimitingCharIndexes.push(delimitingCharIndex);
					}
				}
				if (delimitingCharIndexes.length > 0) {
					var firstDelimitingCharIndex = Math.min.apply(null, delimitingCharIndexes);
					return str.substr(0, firstDelimitingCharIndex);
				}
				return str;
			}
			return "";
		}
		if (url) {
			if (url.indexOf("youtube.com/watch") > 0) {
				var startVideoParamArr = url.split("v=");
				if (startVideoParamArr.length > 1) {
					for (var i = 0; i < startVideoParamArr.length; i++) {
						var precedingUrlSegment = startVideoParamArr[i];
						var followingUrlSegment = startVideoParamArr[i + 1];
						for (var j = 0; j < delimitingChars.length; j++) {
							if (precedingUrlSegment.slice(-1) == delimitingChars[j]) {
								return trimExtraDataFromIdEnd(followingUrlSegment);
							}
						}
					}
				}
			}
			else {
				var embedSyntax = "youtube.com/embed/";
				var embedStartIndex = url.indexOf(embedSyntax);
				if (embedStartIndex > -1) {
					return trimExtraDataFromIdEnd(url.substr(embedStartIndex + embedSyntax.length));
				}
			}
		}
		return "";
	}, 
	showYoutubeVideoIframe: function($youtubelink) {
		this.showOverlay();
		this.showHtml(this.getYoutubePlayerHtml($youtubelink, true), "video");
	}, 
	showOverlay: function() {
		this.$overlay.show();
		this.showHtml("<p>...</p>");
	}, 
	showHtml: function(html, cssClass) {
		var containerClass = cssClass || "";
		var viewportHeight = $(window).height();
		this.$overlayContentWrapper.html("<div class='wrapper'><div id='overlay-content-raw'>" + html + "</div>" + "<a href='#' class='close'><span>Close window</span></a>" +  "</div>").addClass(containerClass);
		var modalContentHeight = this.$overlayContentWrapper.outerHeight();
		//var $innerModalContent = this.$overlayContentWrapper.find("#overlay-content-raw");
		//var modalContentWidth = $innerModalContent.width();
		
		//console.log("viewport= " + viewportHeight + " modal=" + modalContentHeight);
		
		var topValue = $(document).scrollTop();
		if (viewportHeight > modalContentHeight) {
			topValue += ((viewportHeight - modalContentHeight)/2);
		}
		else {
			topValue += 20;
		}
		
		this.$overlayContentWrapper.css("top", topValue).show();
	}, 
	close: function() {
		this.$overlay.hide();
		this.$overlayContentWrapper.hide().removeAttr("class").removeAttr("style").empty();
	}
};

app.spotlightsCarousel = {
	init: function() {
		var $spotlightContainers = $("div.spotlights");
		this.initializeSpotlightContainers($spotlightContainers);
		
		var that = this;
		$(window).on("resizeEnd", function(e) {
			$spotlightContainers.each(function(i) {
				var $spotlightContainer = $(this);
				var oldItemsPerPage = $spotlightContainer.data("itemsPerPage");
				if (oldItemsPerPage != that.getItemsPerPage($spotlightContainer)) {
					//console.log("items per page has changed; reinitialize");
					$("div.listwrapper").find("ul").addBack().removeAttr("style");
					that.initializeSpotlightContainer($spotlightContainer);
				}
			});
		});
	}, 
	initializeSpotlightContainers: function($spotlightContainers) {
		var that = this;
		$spotlightContainers.each(function(i) {
			that.initializeSpotlightContainer($(this));
		});
	}, 
	initializeSpotlightContainer: function($spotlightContainer) {
		$spotlightContainer.data("visiblePage", 1);
		this.showOrUpdateTableOfContents($spotlightContainer);
		this.updatePagination($spotlightContainer);
	
		var $itemList = this.getItemList($spotlightContainer);
		var $items = this.getItems($spotlightContainer);
		var $firstItem = $items.first();
		var firstItemWidth = $firstItem.outerWidth(true);

		$spotlightContainer.addClass("initialized");
		$itemList.width(Math.ceil($items.length * firstItemWidth) + 5); //5 added here just to give some wiggle room; android can wrap otherwise
		var wrapperWidth = (this.getItemsPerPage($spotlightContainer) * firstItemWidth);
		this.getListWrapper($spotlightContainer).width(wrapperWidth);
	}, 
	getItemsPerPage: function($spotlightContainer) {
		//fully visible items
		var containerWidth = this.getListWrapper($spotlightContainer).parent().width();
		var itemWidth = this.getItems($spotlightContainer).first().outerWidth(true);
		var itemsPerPage = Math.floor(containerWidth/itemWidth) || 1;
		$spotlightContainer.data("itemsPerPage", itemsPerPage);
		return itemsPerPage;
	}, 
	getNumberOfPages: function($spotlightContainer) {
		var $items = this.getItems($spotlightContainer);
		var itemCount = $items.length;
		if (itemCount) {
			var $firstItem = $items.first();
			if ($firstItem.length) {
				var itemWidth = $firstItem.outerWidth();
				if (itemWidth) {
					var itemsPerPage = this.getItemsPerPage($spotlightContainer);
					return Math.ceil(itemCount/itemsPerPage);
				}
			}
		}
		return 1;
	}, 
	getListWrapper: function($spotlightContainer) {
		if (!$spotlightContainer.data("listwrapper")) {
			$spotlightContainer.data("listwrapper", $spotlightContainer.find("div.listwrapper"));
		}
		return $spotlightContainer.data("listwrapper");
	}, 
	getItemList: function($spotlightContainer) {
		if (!$spotlightContainer.data("list")) {
			var $list = this.getListWrapper($spotlightContainer).find("ul");
			$spotlightContainer.data("list", $list);
		}
		return $spotlightContainer.data("list");
	}, 
	getItems: function($spotlightContainer) {
		return this.getItemList($spotlightContainer).children();
	}, 
	/*getItem: function($spotlightContainer, itemNumber) {
		return this.getItems($spotlightContainer).eq(itemNumber - 1);
	}, */
	getTableOfContentsElem: function($spotlightContainer) {
		if (!$spotlightContainer.data("tableOfContents")) {
			var $toc = $spotlightContainer.find("ul.toc");
			if (!$toc.length) {
				var that = this;
				$toc = $("<ul />").addClass("toc").insertAfter(this.getListWrapper($spotlightContainer)).on("click", "a", function(e) {
					that.clickTableOfContentsLink($(this));
					e.preventDefault();
				});
			}
			$spotlightContainer.data("tableOfContents", $toc);
		}
		return $spotlightContainer.data("tableOfContents");
	}, 
	getPaginationElem: function($spotlightContainer) {
		if (!$spotlightContainer.data("pagination")) {
			var $pagination = $spotlightContainer.find("ul.pagination");
			if (!$pagination.length) {
				var that = this;
				$pagination = $("<ul />").addClass("pagination").html("<li class='prev'><a href=''><span class='access'>Previous</span>&lsaquo;</a></li><li class='next'><a href=''><span class='access'>Next</span>&rsaquo;</a></li>").appendTo($spotlightContainer).on("click", "a", function(e) {
					var $a = $(this);
					var $li = $a.closest("li");
					var $selectedTocItem = that.getTableOfContentsElem($spotlightContainer).find("li.selected");
					
					if (!$li.hasClass("disabled") && $li.hasClass("prev")) {
						var $previousTocItem = $selectedTocItem.prev();
						if (!$previousTocItem.length) {
							$previousTocItem = $selectedTocItem.siblings().last();
						}
						$previousTocItem.find("a").trigger("click");
					}
					else if(!$li.hasClass("disabled")) {
						var $nextTocItem = $selectedTocItem.next();
						if (!$nextTocItem.length) {
							$nextTocItem = $selectedTocItem.siblings().first();
						}
						$nextTocItem.find("a").trigger("click");
					}
					e.preventDefault();
				});
			}
			$spotlightContainer.data("pagination", $pagination);
			this.enableSwipeEvents($spotlightContainer);
		}
		return $spotlightContainer.data("pagination");
	}, 
	enableSwipeEvents: function($spotlightContainer) {
		var $paginationElem = $spotlightContainer.data("pagination");
		if ($paginationElem) {
			$spotlightContainer.touchwipe({
				wipeLeft: function () {
					//alert("left");
					$paginationElem.children("li.next").children("a").trigger("click");
				},
				wipeRight: function () {
					//alert("right");
					$paginationElem.children("li.prev").children("a").trigger("click");
				},
				min_move_x: 20,
				min_move_y: 20,
				preventDefaultEvents: false
			});
		}
	},
	showOrUpdateTableOfContents: function($spotlightContainer) {
		var $toc = this.getTableOfContentsElem($spotlightContainer);
		var totalPages = this.getNumberOfPages($spotlightContainer);
		if (totalPages > 1) {
			var listMarkup = "";
			for (var i = 1; i <= totalPages; i++) {
				var selectedAttribute = (i == 1) ? " class='selected'" : "";
				listMarkup += "<li" + selectedAttribute + "><a href='#page" + i + "' data-page='" + i + "'>Page " + i + "</a></li>";
			}
			$toc.html(listMarkup).show();
		}
		else {
			$toc.hide();
		}
	},
	clickTableOfContentsLink: function($a) {
		var pageToShow = parseInt($a.attr("data-page")) || 1;
		
		var $spotlightContainer = $a.closest("div.spotlights");
		var itemNumberToShow = this.getItemsPerPage($spotlightContainer) * (pageToShow - 1) + 1;
		
		var $list = this.getItemList($spotlightContainer);
		var $firstItem = $list.children().first();
		var itemWidth = $firstItem.outerWidth(true);
		var leftMargin = -1 * (itemWidth * (itemNumberToShow - 1));
		
		var that = this;
		$list.animate({
			marginLeft: leftMargin
		}, 200, function() {
			$a.closest("li").addClass("selected").siblings().removeClass("selected");
			$spotlightContainer.data("visiblePage", pageToShow);
			that.updatePagination($spotlightContainer);
		});
	}, 
	updatePagination: function($spotlightContainer) {
		var $elem = this.getPaginationElem($spotlightContainer);
		var currentPage = ($spotlightContainer.data("visiblePage")) ? $spotlightContainer.data("visiblePage") : 1;
		var totalPages = this.getNumberOfPages($spotlightContainer);

		var $prev = $elem.find("li.prev");
		var $next = $prev.siblings(".next");
		if (currentPage == 1) {
			$prev.addClass("disabled");
		}
		else {
			$prev.removeClass("disabled");
		}
		if (currentPage == totalPages) {
			$next.addClass("disabled");
		}
		else {
			$next.removeClass("disabled");
		}
		if (totalPages == 1) {
			$spotlightContainer.addClass("noPagination");
		}
		else {
			$spotlightContainer.removeClass("noPagination");
		}
	}
};

app.eventsCalendar = {
	viewportWidthThreshold: 600, 
	calendarCreated: false, 
	init: function() {
		this.initializeForViewport();
		
		var that = this;
		$(window).on("resizeEnd", function() {
			that.initializeForViewport();
		});
	}, 
	initializeForViewport: function() {
		if (!this.calendarCreated && (app.shell.viewportWidth >= this.viewportWidthThreshold)) {
			this.createCalendar();
		}
	}, 
	createCalendar: function() {
		var that = this;
		$("div.myevents").each(function() {
			var $container = $(this);
			var $emptyCalendarNote = $container.find("p.note");
			if (!$emptyCalendarNote.length) {
				var $calendar = $container.find("div.calendar");
				if (!$calendar.length) {
					$calendar = $("<div>").addClass("calendar").prependTo($container);
				}
			
				$(this).find("*[datetime]").each(function(i) {
					var $dt = $(this);
					var dateStr = $dt.attr("datetime");

					if (i == 0) {
						var date = new Date(dateStr);
						var month = date.getMonth() + 1;
						var calendarHtml = that.getCalendarListHtml(month, date.getFullYear());
						//calendarHtml = that.getCalendarListHtml(2, 2009);
						var $newCalendarElem = $(calendarHtml);
						$calendar.replaceWith($newCalendarElem);
						$calendar = $newCalendarElem;
					}
				
					that.getLiByDatetimeAttribute($calendar, dateStr).wrapInner("<a href='' />");
				});
			
				var today = new Date();
				var todayDateStr = today.getFullYear() + "/" + that.getTwoDigitNumber((today.getMonth() + 1)) + "/" + that.getTwoDigitNumber(today.getDate());
				that.getLiByDatetimeAttribute($calendar, todayDateStr).addClass("today");
			}

		}).find("div.calendar li").hover(function(e) {
			var $li = $(this);
			var dateText = $li.attr("datetime");
			$li.closest("div.myevents").find("dt[datetime='" + dateText + "']").toggleClass("focused");
		}).on("click", "a", function(e) {
			return false;
		});
		this.calendarCreated = true;
	}, 
	getLiByDatetimeAttribute: function($calendar, datetimeAttr) {
		return $calendar.find("li[datetime='" + datetimeAttr + "']");
	}, 
	dayLabelArray: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], 
	monthLabelArray: ['January', 'February', 'March', 'April',
                     'May', 'June', 'July', 'August', 'September',
                     'October', 'November', 'December'], 
	daysInMonthArray: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], 
	getDaysInMonth: function(monthIndex, year) {
		var monthLength = this.daysInMonthArray[monthIndex];
		if (monthLength == 28) { // February
			if ((this.year % 4 == 0 && this.year % 100 != 0) || this.year % 400 == 0) {
				monthLength = 29;
			}
		}
		return monthLength;
	}, 
	getDaysInPreviousMonth: function(date) {
		var year = date.getFullYear();
		var month = date.getMonth();
		
		var previousMonth;
		if (month == 0) {
			previousYear = date.getFullYear() - 1;
			previousMonth = new Date(previousYear, 11, 1);
		}
		else {
			previousMonth = new Date(year, month - 1, 1);
		}
		return this.getDaysInMonth(previousMonth.getMonth(), previousMonth.getFullYear());
	}, 
	getTwoDigitNumber: function(i) {
		if (!i) {
			return "00";
		}
		if (i && i < 10) {
			return "0" + i;
		}
		return i;
	}, 
	getCalendarListHtml: function(month, year) {	
		var monthIndex = month - 1;
		var monthName = this.monthLabelArray[monthIndex];
		var dateLis = "";

		/*//day name row
		for (var i = 0; i < this.dayLabelArray.length; i++) {
			dateLis += ("<li>" + this.dayLabelArray[i] +  "</li>");
		}*/
		
		//previous month filler days
		var firstDayOfMonth = new Date(year, monthIndex, 1);
		var firstDayOfMonthDayIndex = firstDayOfMonth.getDay();
		//console.log("first day of " + monthName +  " is " + this.dayLabelArray[firstDayOfMonthDayIndex]);
		if (firstDayOfMonthDayIndex > 0) {
			var daysInPreviousMonth = this.getDaysInPreviousMonth(firstDayOfMonth);
			for (var i = firstDayOfMonthDayIndex; i > 0; i--) {
				dateLis += ("<li class='othermonth'>" + (daysInPreviousMonth - i + 1) +  "</li>");
			}
		}
		
		//active month days
		var monthLength = this.getDaysInMonth(monthIndex);
		for (var i = 1; i <= monthLength; i++) {
			var dateTimeAttr = " datetime='" + year + "/" + this.getTwoDigitNumber(month) + "/" + this.getTwoDigitNumber(i) + "'";
			dateLis += ("<li" + dateTimeAttr+ ">" + i +  "</li>");
		}
		
		//next month filler days
		var lastDayOfMonth = new Date(year, monthIndex, monthLength);
		var lastDayOfMonthDayIndex = lastDayOfMonth.getDay();
		//console.log("last day of " + monthName +  " is " + this.dayLabelArray[lastDayOfMonthDayIndex]);
		if (!(firstDayOfMonthDayIndex > 0) || (lastDayOfMonthDayIndex !== 6)) {
			//this adds a filler week to perfect 28-day februaries (like february 2009)
			if (!(firstDayOfMonthDayIndex > 0) && (lastDayOfMonthDayIndex == 6)) {
				lastDayOfMonthDayIndex = -1;
			}
			for (var i = 0; i < (7 - lastDayOfMonthDayIndex - 1); i++) {
				dateLis += ("<li class='othermonth'>" + (i + 1) +  "</li>");
			}
		}
		
		return [
			"<div class='calendar'>", 
			"<h3>", monthName, "</h3>", 
			"<ul>", dateLis, "</ul>", 
			"</div>"
		].join("");
	}
};

//e.g., home hero carousel
app.genericCarousel = {
	defaultSecondsToShowEachSlide: 6,
	animationDuration: 600,
	init: function() {
		var carouselContainerSelector = "div.carouselContainer";
		var tabConfigObject = {
			selectorForTabListOrTableOfContents: carouselContainerSelector + " ul.toc",
			selectorForElementsToShowAndHide: carouselContainerSelector + " div.itemContainer > div",
			selectorForLinksToElementsToShowAndHide: carouselContainerSelector + " ul.toc a",
			oneItemAlwaysSelected: true, 
			initializeImmediately: true
		};
		this.registerTabs(tabConfigObject);
		
		app.spotlightsCarousel.getPaginationElem($(carouselContainerSelector));
		
		if (!$(carouselContainerSelector).attr("data-manualrotation")) {
			this.autoAdvanceToNextSlide($(tabConfigObject.selectorForTabListOrTableOfContents));
		}
		/*else {
			console.log("manual rotation only");
		}*/
	}, 
	autoAdvanceToNextSlide: function($tocList) {
    	var that = this;
    	var $selectedLi = $tocList.children("li.selected");
    	var $selectedSlide = $($selectedLi.children("a").attr("href"));
    	//console.log("selectedSlide", $selectedSlide.attr("id"));
    	
    	var secondsTillNextSlide = $selectedSlide.attr("data-slidedurationseconds") || this.defaultSecondsToShowEachSlide;
    	//console.log("Carousel: advance slide in " + secondsTillNextSlide + " seconds");
    	this.slideTimer = null;
    	this.slideTimer = setTimeout(function () {
    		//console.log("timer elapsed: " + secondsTillNextSlide + " seconds.");
    		
    		//go to next slide
    		var $nextLi = $selectedLi.next();
    		if (!$nextLi.length) {
    			$nextLi = $selectedLi.siblings().first();
    		}
    		that.showSlideWithFade($nextLi.children("a"), function() {
    			app.genericCarousel.autoAdvanceToNextSlide($tocList);
    		});
    		
		}, (secondsTillNextSlide * 1000));
    }, 
    pause: function() {
    	//console.log("pause carousel");
    	if (this.slideTimer) {
			//console.log("cancel timer");
			window.clearTimeout(this.slideTimer);
			this.slideTimer = null;
		}
    }, 
    stop: function() {
    	//console.log("stop carousel auto-rotate");
    	this.pause();
    	this.stopped = true;
    }, 
    unpause: function() {
    	//console.log("autoplay carousel", !this.stopped);
    	if (!this.stopped){
    		this.autoAdvanceToNextSlide($("div.carouselContainer").find("ul.toc"));
    	}
    }, 
	registerTabs: function (configObj) {
        if ($(configObj.selectorForTabListOrTableOfContents).length) {
            app.tabs.register(configObj);
            this.overrideShowChapter(configObj);
        }
    },
    overrideShowChapter: function (configObj) {
    	var $tocList = $(configObj.selectorForTabListOrTableOfContents);
        var $navLinks = $tocList.find("a");
        var that = this;

        //turn off the default tabs click event (handleChapterClicks)
        //then implement this custom click event (with slide) to replace showChapter
        $navLinks.off("click").on("click", function (e) {
        	that.stop();

            that.showSlideWithFade($(this));

            e.preventDefault();
        });
        
        //initialize the first selected slide
        $tocList.find("li.selected").find("a").trigger("click");
        this.stopped = false;
    },
    showSlideWithFade: function ($tocLink, postAnimationCallbackFunction) {
        var slideLink = $tocLink.attr("href");
        var $slide = $(slideLink);
        var $oldSelectedSlide = $slide.siblings(".visibleTab").addClass("disappearing");
        
        this.initializeSlide($slide);
        
        $slide.addClass("visibleTab").css("z-index", "2").fadeIn(this.animationDuration, function(e) {
        	$(this).addClass("visibleTab").removeAttr("style");
        });
        $oldSelectedSlide.fadeOut(this.animationDuration, function(e) {
        	$(this).removeClass("visibleTab").removeClass("disappearing").removeAttr("style");
        	$tocLink.closest("li").addClass("selected").siblings().removeClass("selected");
        	$tocLink.trigger("blur");
        	
        	if (postAnimationCallbackFunction && typeof(postAnimationCallbackFunction) == "function") {
        		postAnimationCallbackFunction();
        	}
        });
        
        this.initializeNextSlide($tocLink);
    },
    initializeNextSlide: function($tocLink) {
        var $nextTocLi = $tocLink.closest("li").next();
        if ($nextTocLi.length) {
        	this.initializeSlide($($nextTocLi.children("a").attr("href")));
        }
    }, 
    initializeSlide: function($slide) {
    	if (!$slide.data("initialized")) {
    		//console.log("initializing", $slide.attr("id"));
        	var slideImageUrl = $slide.attr("data-imageurl");
        	if (slideImageUrl) {
        		var $slideImageContainer = $slide.find("div.img").filter(".placeholder");
        		var $slideImage = $slideImageContainer.find("img");
        		var $img = $("<img />").on("load", function() {
        			//console.log("image loaded", $(this).attr("src"));
        			$slideImage.attr("src", slideImageUrl);
        			$slideImageContainer.removeClass("placeholder");
        		}).attr("src", slideImageUrl);
        	}
        	var slideImageType = $slide.attr("data-imagetype") || "";
			if (slideImageType == "dark") {
				$slide.addClass("darkPhoto");
			}
			var slideTextPlacementType = $slide.attr("data-textplacement") || "";
			if (slideTextPlacementType == "right") {
				$slide.addClass("textOnRight");
			}
        	
        	$slide.data("initialized", true);
        }
    }
};

app.responsiveTabs = {
	exceedsViewportWidthThreshold: null,
	maxTocItemsPerPage: 5, 
	init: function() {
		var genericTabConfig = {
			selectorForTabListOrTableOfContents: "div.tabsContainer ul.nav",
			selectorForElementsToShowAndHide: "div.tabsContainer div.tabContent > div",
			selectorForLinksToElementsToShowAndHide: "div.tabsContainer ul.nav > li > a",
			oneItemAlwaysSelected: true, 
			initializeImmediately: true
		};
		this.initializeAccordionOrTabs(genericTabConfig, false);
		
		var latestNewsTabConfig = {
			selectorForTabListOrTableOfContents: "div.mycontent.latestnews ul.contents",
			selectorForElementsToShowAndHide: "div.mycontent.latestnews div.tabContent > div",
			selectorForLinksToElementsToShowAndHide: "div.mycontent.latestnews ul.contents > li > a",
			oneItemAlwaysSelected: true, 
			initializeImmediately: false
		};
		this.initializeAccordionOrTabs(latestNewsTabConfig, true);
		
		var $kcNav = $("div.kc").find("div.sectionnav").find("div.mycontent");
		if ($kcNav.length) {
			this.getPageTocElem($kcNav);
			this.paginateTableOfContents($kcNav.find("ul").first(), "div.mycontent", 8, true);
		}
	}, 
	initializeAccordionOrTabs: function(tabConfig, paginateTableOfContents) {
		app.tabs.register(tabConfig);
		
		var $tocLinks = $(tabConfig.selectorForTabListOrTableOfContents).children().children("a");
		if ($tocLinks.length) {
			this.initializeForViewport($tocLinks, paginateTableOfContents);

			var that = this;
			$(window).on("resizeEnd", function() {
				that.initializeForViewport($tocLinks, paginateTableOfContents);
			});
		}
	}, 
	initializeForViewport: function($tocLinks, paginateTableOfContents) {
		var oldexceedsViewportWidthThresholdValue = this.exceedsViewportWidthThreshold;
		var $tocLinksList = $tocLinks.first().closest("ul");
		this.exceedsViewportWidthThreshold = !($tocLinksList.css("float") == "none" && $tocLinksList.css("display") == "block");
		
		if (oldexceedsViewportWidthThresholdValue !== this.exceedsViewportWidthThreshold) {
			//console.log("latest news viewport type changed", $tocLinks.length);
			this.reset($tocLinks);
			
			if (!this.exceedsViewportWidthThreshold) {
				//console.log("small viewport", $tocLinks.length);
				this.initializeForSmallViewport($tocLinks);
			}
			else {
				//console.log("large viewport");
				this.initializeForLargeViewport($tocLinks, paginateTableOfContents);
			}
		}
	}, 
	reset: function($tocLinks) {
		//move news items back to their original container
		$tocLinks.closest("ul").find("div").each(function() {
			var $item = $(this);
			var $divHomeContainer = $item.data("homeContainer");
			if ($divHomeContainer) {
				$divHomeContainer.append($item);
			}
		});
	}, 
	initializeForLargeViewport: function($tocLinks, paginateTableOfContents) {
		var that = this;
        $tocLinks.off("click").on("click", function (e) {
            app.tabs.showChapter($(this), true);
            e.preventDefault();
        });
        
        //show first item if none are selected
        $tocLinks.closest("ul").each(function() {
        	var $tocList = $(this);
        	var $selectedTocItem = $tocList.children(".selected");
        	if (!$selectedTocItem.length) {
				$tocList.children().first().children("a").trigger("click");
			}
			
			if (paginateTableOfContents) {
				that.paginateTableOfContents($tocList);
			}
        });
		
		
	}, 
	initializeForSmallViewport: function($tocLinks) {
		//console.log("latest news small viewport initialization");
		this.overrideShowItemForSmallViewport($tocLinks);
		
		//initialize the first selected item
		var that = this;
		$tocLinks.closest("ul").children("li.selected").each(function() {
			var $selectedTocLink = $(this).children("a");
			that.toggleItemForSmallViewport($selectedTocLink, true);
		});
	},
	overrideShowItemForSmallViewport: function($tocLinks) {
        var that = this;

        //turn off the default tabs click event (handleChapterClicks)
        //then implement this custom click event to replace showChapter
        $tocLinks.off("click").on("click", function (e) {
            that.toggleItemForSmallViewport($(this));
            e.preventDefault();
        });
	}, 
	toggleItemForSmallViewport: function ($tocLink, showOnly) {
		
        var itemSelector = $tocLink.attr("href");
        var $item = $(itemSelector);
        var $tocLi = $tocLink.closest("li");
        
        if ($tocLi.hasClass("selected") && !showOnly) {
        	$item.slideUp(200, function(e) {
        		$tocLi.removeClass("selected");
        		$item.appendTo($item.data("homeContainer"));
        	});
        }
        else {
        	if (!$item.data("homeContainer")) {
        		$item.data("homeContainer", $item.parent());
        	}
        	$item.hide().appendTo($tocLi).slideDown(200, function(e) {
        		$tocLi.addClass("selected");
        	});
        	$tocLi.siblings(".selected").children("a").trigger("click");
        }
        
        $tocLink.trigger("blur");
    },
	getPageTocElem: function($container) {
		if (!$container.data("toc")) {
			var $toc = $container.find("ul.toc");
			if (!$toc.length) {
				$toc = $("<ul class='toc'></ul>").appendTo($container);
			}
			$container.data("toc", $toc);
		}
		return $container.data("toc");
	},
	paginateTableOfContents: function($toc, containerSelector, maxTocItemsPerPage, allowExtraItemInPaginationSpace) {
		if (!$toc.data("paginationInitialized")) {
			//console.log("latestnews.paginateTableOfContents");
			var itemCount = $toc.children().length;
			var maxTocItemsPerPage = maxTocItemsPerPage || this.maxTocItemsPerPage;
			if ((!allowExtraItemInPaginationSpace && itemCount > maxTocItemsPerPage) || (allowExtraItemInPaginationSpace && itemCount > maxTocItemsPerPage + 1)) {
				var numberOfPages = Math.ceil(itemCount/maxTocItemsPerPage);
				var paginationLis = "";
				for (var i = 0; i < numberOfPages; i++) {
					paginationLis += "<li><a href='#page" + (i + 1) + "'>" + "Page " + (i + 1) + "</a></li>";
				}
				var containerSelector = containerSelector || "div.latestnews";
				var $paginationToc = this.getPageTocElem($toc.closest(containerSelector)).html(paginationLis);

				var pageNumber = 1;
				var that = this;
				$toc.children().each(function(i) {
					var itemNumber = i+1;
					if (itemNumber > that.maxTocItemsPerPage) {
						pageNumber = Math.ceil(itemNumber/maxTocItemsPerPage);
					}
					$(this).addClass("page" + pageNumber);
				});
			
				$paginationToc.on("click", "a", function(e) {
					var $a = $(this);
					var pageClass = $a.attr("href") || "#page0";
					pageClass = (pageClass[0] == "#") ? pageClass.substring(1) : pageClass.split("#")[1];
					$toc.children().hide().filter("." + pageClass).show().first().addClass("first");
					$a.closest("li").addClass("selected").siblings().removeClass("selected");
					$a.trigger("blur");
					e.preventDefault();
				});
				
				$paginationToc.children().first().find("a").trigger("click");
				
				$toc.css("min-height", $toc.innerHeight() + "px");
			}
			else {
				var $tocElem = this.getPageTocElem($toc.closest(containerSelector));
				if ($tocElem) {
					$tocElem.hide();
				}
			}
			$toc.data("paginationInitialized", true);
		}
	}
};

app.ourExperts = {
	init: function() {
		var that = this;
		$("div.module.experts").find("div.myhead").each(function() {
			var $heading = $(this);
			if (!$heading.closest("div.mymodule").hasClass("imageModule")) {
				$heading.addClass("clickable").attr("tabIndex", "0");
				that.toggleContainerClass($heading);
			}
		}).end().on("click", "div.myhead.clickable", function(e) {
			that.toggleExpert($(this).trigger("blur"));
		}).on("keyup", "div.myhead.clickable", function(e) {
			//keyboard compatibility for clickable headings
			if (e.which == 13) {
				$(this).trigger("click");
				return false;
			}
		}).each(function() {
			$(this).find("div.myhead.clickable").first().trigger("click");
		});
	}, 
	toggleExpert: function($heading) {
		$heading.next().slideToggle(200, function() {
			$heading.closest("div.mymodule").toggleClass("collapsed");
		});
	}, 
	toggleContainerClass: function($heading) {
		$heading.closest("div.mymodule").toggleClass("collapsed");
	}
};	

app.myTools = {
	init: function() {
		var $mystuffContainer = $("div.mystuff");
		this.initializeCollapsibleModules($mystuffContainer);
		this.showHeaderCountBadges($mystuffContainer);
		this.tooltips.init();
		
		var that = this;
		$mystuffContainer.on("ajaxHtmlLoad", function(e, newModuleElem) {
			var $newModule = $(newModuleElem);
			that.initializeCollapsibleModule($newModule);
			that.showHeaderCountBadge($newModule);
		});
	}, 
	initializeCollapsibleModules: function($container) {
		var that = this;
		$container.find("div.myhead").each(function(i) {
			if (i) {
				that.initializeCollapsibleModule($(this));
			}
		});
		
		$container.on("click", "h2.clickable", function(e) {
			var $module = $(this).closest("div.mymodule");
			$module.find("ul").slideToggle(200, function(e) {
				$module.toggleClass("collapsed");
			});
		});
	}, 
	showHeaderCountBadges: function($container) {
		var that = this;
		$container.find("div.mymodule").each(function() {
			that.showHeaderCountBadge($(this));
		});
	}, 
	initializeCollapsibleModule: function($module) {
		var $moduleHeading;
		if ($module.hasClass("myhead")) {
			$moduleHeading = $module;
		}
		else {
			$moduleHeading = $module.find("div.myhead");
		}
		$moduleHeading.find("h2").addClass("clickable");
	}, 
	showHeaderCountBadge: function($module) {
		var $alerts = $module.find("span.alert");
		var alertCount = $alerts.length;
		if (alertCount) {
			var $moduleHead = $module.find("div.myhead");
			var $moduleHeadAlert = $moduleHead.find("span.alert");
			if (!$moduleHeadAlert.length) {
				$moduleHeadAlert = $("<span class='alert'>" + alertCount +  "<span class='access'> alert(s)</span></span>").prependTo($moduleHead);
			}
		}
	}, 
	tooltips: {
		unhoverTimer: null, 
		init: function() {
			this.initHover();
		}, 
		initClick: function() {
			var that = this;
			$("div.main").on("click", "span.alert a", function(e) {
				var $tooltipTrigger = $(this);
				that.toggleTooltip($tooltipTrigger);
				e.preventDefault();
			});
		}, 
		initHover: function() {
			var that = this;
			$("div.main").on("mouseenter mouseleave", "span.alert a", function(event) {
				var $tooltipTrigger = $(this);
				
				if (event.type == "mouseleave") {
					//console.log("disappear in 5 secs");
					app.myTools.tooltips.unhoverTimer = setTimeout(function () {
						//console.log("timeout executed");
						that.toggleTooltip($tooltipTrigger);
					}, 500);
				}
				else {
					that.cancelTooltipDisappearance();
					that.toggleTooltip($tooltipTrigger);
				}
				return false;
			}).on("click", "span.alert a", function(e) {
				return false;	
			});
		}, 
		cancelTooltipDisappearance: function() {
			if (app.myTools.tooltips.unhoverTimer) {
				//console.log("cancel previous timer");
				clearTimeout(app.myTools.tooltips.unhoverTimer);
				app.myTools.tooltips.unhoverTimer = null;
			}
		}, 
		toggleTooltip: function($tooltipTrigger) {
			var tooltipSelector = $tooltipTrigger.attr("href");
			if (tooltipSelector && tooltipSelector.charAt(0) != "#") {
				var poundCharIndex = tooltipSelector.indexOf("#");
				tooltipSelector = tooltipSelector.slice(poundCharIndex);
			}
			var $tooltipElem = $(tooltipSelector);
			if ($tooltipElem.length) {
				var triggerPosRelativeToBody = $tooltipTrigger.offset();
				$tooltipElem.appendTo("body"); //move before getting dimensions, otherwise there's a jump
				var topVal = triggerPosRelativeToBody.top - $tooltipElem.outerHeight();
				var leftVal = triggerPosRelativeToBody.left - ($tooltipElem.outerWidth() / 2);
				$tooltipElem.toggleClass("visible").css({"top": topVal, "left": leftVal});
				$("p.alertdetails").not($tooltipElem).removeClass("visible");
			}
		}
	}
};

app.notificationsList = {
	init: function() {
		var that = this;
		$("div.notificationsList").on("click", "a.remove", function(e) {
			var $a = $(this);
			var removeUrl = $a.attr("href");
			$.ajax({
				url: removeUrl, 
				success: function(data) {
					that.removeNotification($a.closest("li"));
				},
				error: function(jqXHR, textStatus, errorThrown) {
					console.log(errorThrown);
					that.removeNotification($a.closest("li"));
				}
			});
			e.preventDefault();
		});
	}, 
	removeNotification: function($li) {
		var that = this;
		var $ul = $li.closest("ul");
		$li.fadeOut(200, function(e) {
			$(this).remove();
			that.showNoNotificationsMessage($ul);
		});
	}, 
	showNoNotificationsMessage: function($ul) {
		if ($ul.children().length < 1) {
			$ul.after("<p class='note'>You have no notifications.</p>").remove();
		}
	}
};

app.ajaxData = {
	init: function() {
		var that = this;
		$("div.ajax-placeholder").each(function() {
			that.getAndLoadHtml($(this));
		});
	}, 
	getAndLoadHtml: function($placeholderElem) {
		var dataUrl = $placeholderElem.attr("data-htmlurl");
		if (dataUrl) {
			var that = this;
			$.ajax({
				url: dataUrl, 
				dataType: "html", 
				success: function(data) {
					
					//simulate delay
					setTimeout(function () {
						
						that.loadHtml($placeholderElem, data);
						that.notifyParentOfChange($placeholderElem);
						$placeholderElem.remove();
			
					}, (5 * 1000));
					
					
					/*that.loadHtml($placeholderElem, data);
					that.notifyParentOfChange($placeholderElem);
					$placeholderElem.remove();*/
				},
				error: function(jqXHR, textStatus, errorThrown) {
					console.log(errorThrown);
				}
			});
		}
	}, 
	loadHtml: function($placeholderElem, ajaxHtml) {
		$placeholderElem.before(ajaxHtml);
	}, 
	notifyParentOfChange: function($placeholderElem) {
		var parentSelector = $placeholderElem.attr("data-parenttotell");
		if (parentSelector) {
			$placeholderElem.closest(parentSelector).trigger("ajaxHtmlLoad", $placeholderElem.prev());
		}
	}
};

app.searchPage = {
	$facetsSidebar: null, 
	$form: null, 
	
	init: function() {
		this.$facetsSidebar = $("div.facets:first");
		this.$form = this.$facetsSidebar.closest("form").removeClass("loading");
		
		this.initializeLeftSidebar();
		this.initializeResultsArea();
		
		this.updateResults.init(this.$form);
		//delete above line and uncomment below line to enable ajax form submissions (1/2)
		//this.updateResults.initAjax(this.$form);
	}, 
	initializeLeftSidebar: function() {
		this.checkboxProxies.init();
		
		var that = this;
		this.$facetsSidebar.bind("click", function(e) {
			var $elem = $(e.target);
			if ($elem.is("input:checkbox")) {
				that.checkboxProxies.updateProxyWithCheckboxState($elem);
				app.searchPage.updateResults.go($elem.closest("form"));
			}
			else if ($elem.is("a.clear")) {
				var $form = $elem.closest("form");
				
				//pause updating on facet toggle so all boxes can be unchecked without triggering submit
				that.updateResults.pause($form);
				$(this).find("input:checked").each(function() {
					$(this).trigger("click");
				});
				
				//resume updating on facet toggle
				that.updateResults.resume($form);
				
				//now update the results
				that.updateResults.go($form);
				e.preventDefault();
			}
		});
	}, 
	initializeResultsArea: function() {
		this.sortProxies.init();
		this.pagination.init();
		this.searchTermInputs.init();
	}, 
	searchTermInputs: {
		initialized: false,
		init: function() {
			var $searchTermForms = $("div.keyword");
			
			//if there is only one search form, add a second at the bottom
			if ($searchTermForms.length == 1) {
				var $resultsArea = $searchTermForms.closest("form").find("div.results").first();
			
				//append a second bottom miniform if it's not there in the markup
				if (!this.initialized) {
					if (!$resultsArea.next().hasClass("div.keyword")) {
						$searchTermForms.clone().insertAfter($resultsArea);
						$searchTermForms = $("div.keyword");
					}
					this.initialized = true;
				}
			}
		
			this.syncBoxes($searchTermForms);
		}, 
		syncBoxes: function($searchTermForms) {
			var $searchTermInputs = $searchTermForms.find("input:text");			
			$searchTermInputs.on("keyup", function(e) {
				var $input = $(this);
				var term = $input.val();
				$searchTermInputs.not($input).val(term);
			});
		}
	}, 
	sortProxies: {
		init: function() {
			$("fieldset.sort").find("input").addClass("access").bind("click", function() {
				var $input = $(this);
				$input.closest("label").addClass("selected").siblings().removeClass("selected");
				app.searchPage.updateResults.go($input.closest("form"));
			});
			this.sync();
		}, 
		sync: function() {
			$("fieldset.sort").find("input:checked").closest("label").addClass("selected").siblings().removeClass("selected");
		}
	}, 
	pagination: {
		init: function() {
			var that = this;
			$("div.pages").each(function(i) {
				var $elem = $(this);
				that.addActivePageClass($elem);
				that.addClickEvents($elem);
				app.forms.addPrevAndNextToPagesList.init();
			});
		}, 
		reset: function() {
			var $elem = $("div.pages");
			var that = this;
			$elem.each(function() {
				var $input = that.getPaginationInput($(this));
				$input.val(1);
			});
		}, 
		getPaginationInput: function($elem) {
			return $elem.find("input");
		}, 
		getCurrentPage: function($elem) {
			var $pageFormElement = this.getPaginationInput($elem);			
			return $pageFormElement.val() || "1";
		}, 
		getPageNumber: function($elem) {
			var text = $.trim($elem.text());
			var pageNumber = parseInt(text, 10);
			if (!isNaN(pageNumber)) {
				return pageNumber;
			}
			return null;
		}, 
		addActivePageClass: function($elem) {
			var currentPage = this.getCurrentPage($elem);
			var $lis = $elem.find("ul").children();
			var that = this;
			$lis.each(function(i, elem) {			
				var $li = $(this);
				var liFromPage = that.getPageNumber($li);
				if (liFromPage == currentPage) {
					$li.addClass("active").siblings().removeClass("active");
					return false;
				}
			});
		}, 
		addClickEvents: function($elem) {
			var that = this;
			$elem.find("ul").on("click", "a", function(e) {
				var pageNumber = that.getPageNumber($(this));
				if (pageNumber) {
					//console.log("go to page ", pageNumber);
					//set hidden input to page value
					that.getPaginationInput($elem).val(pageNumber);
					
					//now update the results
					app.searchPage.updateResults.preservePagination = true;
					app.searchPage.updateResults.go($elem.closest("form"));
					
					e.preventDefault();
				}
			});
		}
	}, 
	checkboxProxies: {
		$lastChangedCheckbox: null, 
		init: function() {
			var $checkboxes = app.searchPage.$facetsSidebar.find("input:checkbox");
			var that = this;
			$checkboxes.each(function() {
				var $checkbox = $(this);
				that.addProxyToDOM($checkbox);
				that.updateProxyWithCheckboxState($checkbox);
				$checkbox.bind("focus", function() {
					$(this).closest("label").addClass("focused");
				}).bind("blur", function() {
					$(this).closest("label").removeClass("focused");
				}).bind("click", function() {
					$(this).trigger("blur");
				});
			});
		}, 
		addProxyToDOM: function($checkbox) {
			var $label = $checkbox.closest("label");
			$checkbox.after("<span class=\"check\" />");
			$label.addClass("proxied");
		}, 
		updateProxyWithCheckboxState: function($checkbox) {
			this.$lastChangedCheckbox = $checkbox;
			if ($checkbox.is(":checked")) {
				this.getCheckboxProxy($checkbox).addClass("checked").closest("label").addClass("checked");
			}
			else {
				this.getCheckboxProxy($checkbox).removeClass("checked").closest("label").removeClass("checked");
			}
			
			var $countElem = this.getCheckboxCountElem($checkbox);
			if ($countElem.text() == "0") {
				$checkbox.attr("disabled", "disabled");
			}
			else {
				$checkbox.removeAttr("disabled");
			}
			
			if ($checkbox.attr("disabled")) {
				$checkbox.closest("label").addClass("disabled");
			}
			else {
				$checkbox.closest("label").removeClass("disabled");
			}
		},
		getCheckboxProxy: function($checkbox) {
			if (!$checkbox.data("proxy")) {
				$checkbox.data("proxy", $checkbox.closest("label.proxied").find("span.check:first"));
			}
			return $checkbox.data("proxy");
		}, 
		getCheckboxCountElem: function($checkbox) {
			if (!$checkbox.data("count")) {
				$checkbox.data("count", $checkbox.closest("label").find("span.count:first").children("span"));
			}
			return $checkbox.data("count");
		}
	}, 
	updateResults: {
		paused: false, 
		preservePagination: false, 
		init: function($form) {
			var that = this;
			$form.on("submit", function(e) {
				if (!that.preservePagination) {
					app.searchPage.pagination.reset();
				}
			});
		}, 
		initAjax: function($form) {
			var that = this;
			$form.on("submit", function(e) {
				if (!that.preservePagination) {
					app.searchPage.pagination.reset();
				}
				app.searchPage.updateResults.go($form);
				return false;
			});
		}, 
		go: function($form) {
			if (!this.paused) {
				$form.addClass("loading");
				this.getUpdatedResults($form.get(0).action + "?" + $form.serialize());
			}
		},
		pause: function($form) {
			this.paused = true;
		}, 
		resume: function($form) {
			this.paused = false;
		}, 
		getUpdatedResults: function(resultsUrl) {
			app.searchPage.$form.trigger("submit");
			
			//remove above line and 
			//uncomment below lines to enable ajax form submissions (2/2)
			/*
			console.log("updating search results", resultsUrl);
			var that = this;
			$.ajax({
				url: resultsUrl, 
				dataType: "html", 
				cache: true, 
				success: function(data) {
					//window.setTimeout(function() {
					that.showUpdatedResults(data);
					//}, 1000);
				}, 
				error: function() { 
					window.location = resultsUrl;
				}
			});*/
		}, 
		showUpdatedResults: function(pageHtml) {
			var $updatedResultsPage = $(pageHtml);

			//update page html
			app.searchPage.$form.html($updatedResultsPage.find("form.searchpage").html());
			app.searchPage.init();
			
			//reinitialize responsive sidebar-as-dropdown
			app.leftColumnToDropdown.init();
			
			//show form with updated data
			app.searchPage.$form.removeClass("loading");
			
			//reset pagination
			app.searchPage.updateResults.preservePagination = false;
		}
	}
};

app.moreDropdown = {
	init: function() {
		$("div.morelist").find("p.current").on("click", function(e) {
			var $currentSectionElem = $(this);
			$currentSectionElem.next("ul").fadeToggle(200, function() {
					//$(this).toggleClass("expanded");
					//$(this).removeAttr("style");
			});
			$currentSectionElem.trigger("blur");
		}).addClass("clickable").attr("tabIndex", "0").on("keyup", function(e) {
			if (e.which == 13) {
				$(this).trigger("click");
				return false;
			}
		});
	}
};

app.solutionsSort = {
	byCategoryText: "By Category", 
	byCategoryId: "categorized", 
	byAlphaId: "alpha", 
	categoryList: [], 
	categoryMap: {}, 
	alphaList: [], 
	alphaMap: {}, 
	itemNameToHtmlMap: {}, 
	init: function() {
		var that = this;
		var $toggleUl = $("ul.toggleSolutionsSort");
		$toggleUl.each(function() {
			that.addByCategoryLink($(this));
		});
		
		this.buildOrUpdateAlphaNav($toggleUl);
		this.processListItems();
		this.addSortedList(this.alphaList, this.alphaMap, this.byAlphaId);
		this.buildOrUpdateAlphaNav($toggleUl);
		this.addSortedList(this.categoryList, this.categoryMap, this.byCategoryId);
		this.addCategoryTableOfContents($toggleUl);
		
		$toggleUl.closest("div.inpagenav").parent().on("click", "ul.toggleSolutionsSort a", function(e) {
			var $a = $(this);
			var $li = $a.closest("li");
			if (!$li.hasClass("selected")) {
				var href = $a.attr("href");
				var typeId = (href[0] == "#") ? href.substring(1) : href.split("#")[1];
				var $typeList = $("#" + typeId);
				var $typeNav = $("#nav-" + typeId);
				$typeList.add($typeNav).siblings().hide().end().show();
			}
			e.preventDefault();
		});
	}, 
	caseInsensitiveSortFunction: function(a, b) {
		return a.toLowerCase().localeCompare(b.toLowerCase());
	}, 
	addByCategoryLink: function($ul) {
		$ul.children().first().clone().removeClass("selected").children("a").text(this.byCategoryText).attr("href", "#" + this.byCategoryId).end().appendTo($ul);
	}, 
	processListItems: function() {
		var that = this;
		$("#" + this.byAlphaId).find("div.toolsList").find("div.name").each(function() {
			var $itemHeading = $(this).find("h3");
			var toolName = $itemHeading.text();
			that.itemNameToHtmlMap[toolName] = $itemHeading.closest("li")[0].outerHTML;
			
			var categoryName = $itemHeading.next("span").text();
			if (!that.categoryMap[categoryName]) {
				that.categoryMap[categoryName] = {
					itemNamesArray: []
				};
				that.categoryList.push(categoryName);
			}
			
			that.categoryMap[categoryName]["itemNamesArray"].push(toolName);
			
			var toolFirstLetter = toolName.charAt(0).toUpperCase();
			if (!that.alphaMap[toolFirstLetter]) {
				that.alphaMap[toolFirstLetter] = {
					itemNamesArray: []
				};
				that.alphaList.push(toolFirstLetter);
			}

			that.alphaMap[toolFirstLetter]["itemNamesArray"].push(toolName);
		});
		this.alphaList.sort(this.caseInsensitiveSortFunction);
		this.categoryList.sort(this.caseInsensitiveSortFunction);
	},
	buildOrUpdateAlphaNav: function($toggleUl) {
		var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		var alphaLis = [];
		for (var i = 0; i < alphabet.length; i++) {
			var letter = alphabet[i];
			if (this.alphaMap[letter]) {
				alphaLis.push("<li><a href='#", this.getCategoryId(letter), "'>", letter, "</a></li>");
			}
			else {
				alphaLis.push("<li>", letter, "</li>");
			}
		}
		
		var listMarkup = "<ul>" + alphaLis.join("") + "</ul>";
		var $contentContainer = $toggleUl.closest("div.mycontent");
		var $navList = $contentContainer.children("ul");
		if ($navList.length) {
			$navList.replaceWith(listMarkup);
		}
		else {
			$contentContainer.append(listMarkup);
		}
	}, 
	getCategoryId: function(name) {
		if (name.length == 1) {
			return name.toUpperCase();
		}
		return name.toLowerCase().split(" ").join("-").split("&").join("").split("--").join("-");
	}, 
	addCategoryTableOfContents: function($toggleList) {
		var $alphaTocModule = $toggleList.closest("div.inpagenav");
		var $categoryTocModule = $alphaTocModule.clone();
		$categoryTocModule.find("ul.toggle").children("li.selected").removeClass("selected").siblings().addClass("selected");
		var categoryLis = "";
		for (var i = 0; i < this.categoryList.length; i++) {
			var categoryName = this.categoryList[i];
			categoryLis += ("<li><a href='#" + this.getCategoryId(categoryName) + "'>" + this.categoryList[i] + "</a></li>");
		}
		$categoryTocModule.find("div.mycontent").children("ul").addClass("category").html(categoryLis);
		$categoryTocModule.find("h2").text(this.byCategoryText);
		
		$alphaTocModule.attr("id", "nav-" + this.byAlphaId);
		$categoryTocModule.attr("id", "nav-" + this.byCategoryId).insertAfter($("#" + this.byAlphaId)).hide();
	}, 
	addSortedList: function(sectionList, sectionMap, sectionTypeId) {
		var $sectionTemplate = $("div.listmodule").first().clone();
		var sectionHtml = "";
		for(var i = 0; i < sectionList.length; i++) {
			var sectionName = sectionList[i];
			var sectionId = this.getCategoryId(sectionName);
			$sectionTemplate.find("div.listhead").find("h2").html(sectionName).attr("id", sectionId);
			var $itemList = $sectionTemplate.find("div.toolsList").children("ul").empty();
			var itemListHtml = "";
			
			sectionMap[sectionName]["itemNamesArray"].sort(this.caseInsensitiveSortFunction);
			for (var j = 0; j < sectionMap[sectionName]["itemNamesArray"].length; j++) {
				var itemName = sectionMap[sectionName]["itemNamesArray"][j];
				itemListHtml += this["itemNameToHtmlMap"][itemName];
			}
			$itemList.html(itemListHtml);
			
			sectionHtml += $sectionTemplate[0].outerHTML;
		}
		
		var $section = $("<div />").attr("id", sectionTypeId).html(sectionHtml);
		var $existingSection = $("#" + sectionTypeId);
		if ($existingSection.length) {
			$existingSection.replaceWith($section);
		}
		else {
			$("div.results").first().append($section.hide());
		}
	}
};

app.init = function() {
	$("html").removeClass("no-js");
	app.forms.init();
	app.shell.init();
	app.genericCarousel.init();
	app.ajaxData.init();
	app.leftColumnToDropdown.init();
	app.myTools.init();
	app.modal.init();
	app.moreDropdown.init();
	app.responsiveTabs.init();
	app.eventsCalendar.init();
	app.ourExperts.init();
	app.spotlightsCarousel.init();
	app.notificationsList.init();
	app.solutionsSort.init();
	app.searchPage.init();
	app.backtotop.init();
};
app.init();
