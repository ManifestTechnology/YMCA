#import <Foundation/Foundation.h>

@interface PSPasswordPreference : NSObject

@property (nonatomic, assign) NSUInteger characterLength;
@property (nonatomic, assign) BOOL useNumbers;
@property (nonatomic, assign) BOOL useSymbols;
@property (nonatomic, assign) BOOL useUppercaseLetters;
@property (nonatomic, assign) BOOL useLowercaseLetters;
@property (nonatomic, assign) BOOL isReadable;

-(instancetype)initWithLength:(NSUInteger)len
                      Numbers:(BOOL)numbers
                      Symbols:(BOOL)symbols
                    Uppercase:(BOOL)upLetters
                    Lowercase:(BOOL)lowLetters
                     Readable:(BOOL)readable;

@end
