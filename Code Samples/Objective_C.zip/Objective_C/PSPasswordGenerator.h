#import <Foundation/Foundation.h>

@class PSPasswordPreference;

@interface PSPasswordGenerator : NSObject

+(NSString*)passwordWithPreference:(PSPasswordPreference*)pref;

@end