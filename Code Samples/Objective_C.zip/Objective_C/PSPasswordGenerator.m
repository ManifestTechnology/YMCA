#import "PSPasswordGenerator.h"
#import "PSPasswordPreference.h"

@implementation PSPasswordGenerator

+(NSString*)passwordWithPreference:(PSPasswordPreference*)pref {
    NSString* fullCharacterList = [self characterListForPreference:pref];
    NSString* oneOfEachType = [self requiredCharsForPreference:pref];
    
    NSMutableString* generatedString = [NSMutableString stringWithCapacity:pref.characterLength];
    [generatedString appendString:oneOfEachType];
    
    NSUInteger modLen = pref.characterLength - oneOfEachType.length;
    
    for (int count = 0; count < modLen; count++) {
        [generatedString appendString:[self randomCharInString:fullCharacterList]];
    }
    
    return [self mixString:generatedString];
}

+(NSString*)characterListForPreference:(PSPasswordPreference*)pref {
    NSString* nums = (pref.useNumbers) ? [self numbers:pref.isReadable] : @"";
    NSString* syms = (pref.useSymbols) ? [self symbols:pref.isReadable] : @"";
    NSString* ups = (pref.useUppercaseLetters) ? [self uppercaseLetters:pref.isReadable] : @"";
    NSString* lows = (pref.useLowercaseLetters) ? [self lowercaseLetters:pref.isReadable] : @"";
    
    return [NSString stringWithFormat:@"%@%@%@%@%@%@",lows,syms,nums,ups,syms,nums];
}

+(NSString*)requiredCharsForPreference:(PSPasswordPreference*)pref {
    NSString* num = (pref.useNumbers) ? [self randomCharInString:[self numbers:pref.isReadable]] : @"";
    NSString* sym = (pref.useSymbols) ? [self randomCharInString:[self symbols:pref.isReadable]] : @"";
    NSString* up = (pref.useUppercaseLetters) ? [self randomCharInString:[self uppercaseLetters:pref.isReadable]] : @"";
    NSString* low = (pref.useLowercaseLetters) ? [self randomCharInString:[self lowercaseLetters:pref.isReadable]] : @"";
    
    return [NSString stringWithFormat:@"%@%@%@%@", num,sym,up,low];
}

+(NSUInteger)randomIntWithLimit:(NSUInteger)limit {
    return arc4random_uniform((int32_t)limit);
}

+(NSString*)randomCharInString:(NSString*)targetString {
    NSUInteger targetIndex = [self randomIntWithLimit:targetString.length];
    return [targetString substringWithRange:NSMakeRange(targetIndex, 1)];
}

+(NSString*)numbers:(BOOL)readable {
    return (readable) ? @"23456789" : @"0123456789";
}

+(NSString*)lowercaseLetters:(BOOL)readable {
    return (readable) ? @"abcdefghijkmnopqrstwxyz" : @"abcdefghijklmnopqrstuvwxyz";
}

+(NSString*)uppercaseLetters:(BOOL)readable {
    return (readable) ? @"ABCDEFGHJKLMNPQRSTWXYZ" : @"ABCDEFGHIJKLMNOPQRSTUVWXYZ";
}

+(NSString*)symbols:(BOOL)readable{
    return (readable) ? @"@%}$#?]" : @"@%!}$#?]+[{";
}

+(NSString*)mixString:(NSString*)toBeMixed{
    NSUInteger randomIndex = [self randomIntWithLimit:toBeMixed.length];
    NSRange charRange = NSMakeRange(randomIndex, 1);
    NSString* randomChar = [toBeMixed substringWithRange:charRange];
    NSString* oneLessString = [toBeMixed stringByReplacingCharactersInRange:charRange withString:@""];
    
    NSString* stringToAppend = (oneLessString.length == 1) ? oneLessString : [self mixString:oneLessString];
    
    return [NSString stringWithFormat:@"%@%@", randomChar, stringToAppend];
}

@end
