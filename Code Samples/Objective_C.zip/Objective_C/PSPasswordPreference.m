#import "PSPasswordPreference.h"

@implementation PSPasswordPreference

-(instancetype)initWithLength:(NSUInteger)len
                      Numbers:(BOOL)numbers
                      Symbols:(BOOL)symbols
                    Uppercase:(BOOL)upLetters
                    Lowercase:(BOOL)lowLetters
                     Readable:(BOOL)readable
{
    self = [super init];
    if (self) {
        _useNumbers = numbers;
        _useSymbols = symbols;
        _useLowercaseLetters = lowLetters;
        _useUppercaseLetters = upLetters;
        _characterLength = len;
        _isReadable = readable;
    }
    return self;
}

@end