<?php
/**
 * @file
 * Zen theme's implementation to display a node.
 *
 * Available variables:
 * - $title: the (sanitized) title of the node.
 * - $content: An array of node items. Use render($content) to print them all,
 *   or print a subset such as render($content['field_example']). Use
 *   hide($content['field_example']) to temporarily suppress the printing of a
 *   given element.
 * - $user_picture: The node author's picture from user-picture.tpl.php.
 * - $date: Formatted creation date. Preprocess functions can reformat it by
 *   calling format_date() with the desired parameters on the $created variable.
 * - $name: Themed username of node author output from theme_username().
 * - $node_url: Direct url of the current node.
 * - $display_submitted: Whether submission information should be displayed.
 * - $submitted: Submission information created from $name and $date during
 *   template_preprocess_node().
 * - $classes: String of classes that can be used to style contextually through
 *   CSS. It can be manipulated through the variable $classes_array from
 *   preprocess functions. The default values can be one or more of the
 *   following:
 *   - node: The current template type, i.e., "theming hook".
 *   - node-[type]: The current node type. For example, if the node is a
 *     "Blog entry" it would result in "node-blog". Note that the machine
 *     name will often be in a short form of the human readable label.
 *   - node-teaser: Nodes in teaser form.
 *   - node-preview: Nodes in preview mode.
 *   - view-mode-[mode]: The view mode, e.g. 'full', 'teaser'...
 *   The following are controlled through the node publishing options.
 *   - node-promoted: Nodes promoted to the front page.
 *   - node-sticky: Nodes ordered above other non-sticky nodes in teaser
 *     listings.
 *   - node-unpublished: Unpublished nodes visible only to administrators.
 *   The following applies only to viewers who are registered users:
 *   - node-by-viewer: Node is authored by the user currently viewing the page.
 * - $title_prefix (array): An array containing additional output populated by
 *   modules, intended to be displayed in front of the main title tag that
 *   appears in the template.
 * - $title_suffix (array): An array containing additional output populated by
 *   modules, intended to be displayed after the main title tag that appears in
 *   the template.
 *
 * Other variables:
 * - $node: Full node object. Contains data that may not be safe.
 * - $type: Node type, i.e. story, page, blog, etc.
 * - $comment_count: Number of comments attached to the node.
 * - $uid: User ID of the node author.
 * - $created: Time the node was published formatted in Unix timestamp.
 * - $classes_array: Array of html class attribute values. It is flattened
 *   into a string within the variable $classes.
 * - $zebra: Outputs either "even" or "odd". Useful for zebra striping in
 *   teaser listings.
 * - $id: Position of the node. Increments each time it's output.
 *
 * Node status variables:
 * - $view_mode: View mode, e.g. 'full', 'teaser'...
 * - $teaser: Flag for the teaser state (shortcut for $view_mode == 'teaser').
 * - $page: Flag for the full page state.
 * - $promote: Flag for front page promotion state.
 * - $sticky: Flags for sticky post setting.
 * - $status: Flag for published status.
 * - $comment: State of comment settings for the node.
 * - $readmore: Flags true if the teaser content of the node cannot hold the
 *   main body content. Currently broken; see http://drupal.org/node/823380
 * - $is_front: Flags true when presented in the front page.
 * - $logged_in: Flags true when the current user is a logged-in member.
 * - $is_admin: Flags true when the current user is an administrator.
 *
 * Field variables: for each field instance attached to the node a corresponding
 * variable is defined, e.g. $node->body becomes $body. When needing to access
 * a field's raw values, developers/themers are strongly encouraged to use these
 * variables. Otherwise they will have to explicitly specify the desired field
 * language, e.g. $node->body['en'], thus overriding any language negotiation
 * rule that was previously applied.
 *
 * @see template_preprocess()
 * @see template_preprocess_node()
 * @see zen_preprocess_node()
 * @see template_process()
 */
?>


<div class="banner <?php print($content['field_default_banner_photo']['#items'][0]['value']); ?>">
	<div class="inner">
		<?php
			$title = $content['field_product_display_name_text']['#items'][0]['value'] ? $content['field_product_display_name_text']['#items'][0]['value'] : $title;
		?>
		<h1><?php print $title ?></h1>
		
		<?php 
			$subtitle = isset($content['field_product_name_subtitle']['#items'][0]) ? $content['field_product_name_subtitle']['#items'][0]['value'] : false;
		?>
		<?php if ($subtitle && $subtitle != " "): ?>
			<p class="ex">(<?php print $subtitle; ?>)</p>
		<?php endif; ?>
	</div>
</div><!-- close div.banner -->

			

			
<div class="tabsContainer">
	<div class="inner">
		<ul class="nav">
			<li class="selected"><a href="#overview">Product Overview</a></li>
			<li><a href="#riders">Living Benefits/Riders</a></li>
			<li><a href="#alternatives">Alternative Solutions</a></li>
			<li><a href="#insights">Customer Insights</a></li>
		</ul>
	</div>
	<div class="tabsContent">
		<div id="overview">
			<div class="inner">
				<div class="col-wrapper">
					<div class="col-main">
						<h2><?php print $title; ?> Overview</h2>
						
						<?php print $content['field_overview']['#items'][0]['value'] ?>
						
						<p class="disc">Product solutions recommended to customers should be based on their individual needs.<br /> The products displayed here only serve as a guide.</p>
					</div>
					<div class="col-secondary">
						<?php 
							$customer_description = isset($content['field_customer_description']['#items'][0]) ? $content['field_customer_description']['#items'][0]['value'] : false;
						?>
						<?php if ($customer_description): ?>
							<h3>For potential customers who...</h3>
							<?php print $customer_description; ?>
						<?php endif; ?>
					</div>
				</div><!-- close div.col-wrapper -->
			</div>
			
			<div class="details">
				<div class="inner">
					<div class="col-wrapper">
						<div class="col-main">
							<h3>Details</h3>
							
							<?php print $content['field_details']['#items'][0]['value'] ?>

						</div>
						<div class="col-secondary">
							<?php 
								$supplDetails = isset($content['field_details_supplemental_']['#items'][0]) ? $content['field_details_supplemental_']['#items'][0]['value'] : false;
							?>
							<?php if ($supplDetails): ?>
								<?php print $supplDetails; ?>
							<?php endif; ?>
							
							<div class="links">
								<h3>Links</h3>
								<?php print render($content['field_links']); ?>
							</div>
						
							<div class="disclosures">
								<h3>Disclosures</h3>
								<p><a target="_blank" href="/disclosures/">View Disclosures</a></p>
							</div>
						</div>
					</div><!-- close div.col-wrapper -->
				</div>
			</div><!-- close div.details -->
		</div>
		<div class="inner" id="riders">
				<div class="col-wrapper">
					<div class="col-main">
						<h2><?php print $title; ?> Riders</h2>
						
						<?php print $content['field_riders_tab_content']['#items'][0]['value']; ?>
						
					</div>
					<div class="col-secondary">
						<h3>Resources</h3>
						<ul>
							<li><a target="_blank" href="<?php print url('riders/table/'); ?>">View all Allstate Riders</a></li>
						</ul>
						
						<div class="disclosures">
							<h3>Disclosures</h3>
							<p><a target="_blank" href="/disclosures/">View Disclosures</a></p>
						</div>
					</div>
				</div><!-- close div.col-wrapper -->
		</div>
		<div class="inner" id="alternatives">
			<h2>Alternative Solutions</h2>
			
			<?php 
				//use drupal url() to include view params on these links as necessary so language selection persists
				
				$alternativeSolutionsContent = $content['field_alternative_product_conten']['#items'][0]['value'];
				
				$urlMap = array();
				$pieces = explode('href="/', $alternativeSolutionsContent);
				foreach ($pieces as $key => $value) {
					if ($key > 0 && $value) {
						$urlEndIndex = strpos($value, '"');						
						$hrefValue = substr($value, 0, $urlEndIndex);
						$urlMap["/" . $hrefValue] = url($hrefValue);				
					}
				}
				
				foreach($urlMap as $key => $value) {
					$alternativeSolutionsContent = str_replace($key, $value, $alternativeSolutionsContent);
				}
			 	print $alternativeSolutionsContent; 
			?>
			
			<p class="disc">Product solutions recommended to customers should be based on their individual needs.<br> The products displayed here only serve as a guide.</p>
		
		</div>
		<div id="insights">
			<div class="inner insightPlaceholder">
				<p><a href="/insights/">View Customer Insights</a></p>
			</div>
		</div>
	</div>
</div><!-- close div.tabsContainer -->