<?php
/**
 * @file
 * Returns the HTML for a single Drupal page.
 *
 * Complete documentation for this file is available online.
 * @see https://drupal.org/node/1728148
 */
?>

<div class="page" id="page">
	<div class="bg"></div>
	<?php include_once './' . drupal_get_path('theme', 'knowtheproducts') . '/includes/header.inc'; ?>

<div class="main">
	
	
    <div class="banner">
    			<div class="inner">
    				<h1>Know the Products. <br />Connect with Customers.</h1>
					<p>Life can be complicated. Helping customers find the right financial solution doesn't have to be. Learn more about new Allstate Life and Retirement solutions in a few simple steps. </p>
    			</div>
    		</div>
    		
    <div class="inner">			
    			<form action="" method="get">
    				<div class="questionnaire">
    			
						<div class="progress">
							<ol>
								<li><a href="#stage">Life Stage</a></li>
								<li><a href="#need">Need</a></li>
								<li><a href="#period">Coverage</a></li>
								<li><a href="#risk">Risk</a></li>
								<li><a href="#payment">Schedule</a></li>
							</ol>
						</div><!-- close div.progress -->
				
						<div class="summary">
							<p data-dynamicsummarytext="A solution for {stage} looking for {need}. The policy covers the insured for {period} {risk} {payment}."></p>
							<a href="<?php print $front_page; ?>" class="btn">Start over</a>
						</div>
				
						<div class="prompts">
			
							<div class="prompt" id="stage">
								<h2>Life Stage</h2>
								<p>In what life stage is the customer?</p>
								<fieldset>
									<legend>Life Stage</legend>
									<label class="emerging">
										<input type="radio" name="stage" value="1" data-summarytext="<strong>emerging adults</strong>" />
										<span>
											<span>Emerging Adult</span>
											<span class="desc">Twenty somethings who are just grasping the basics of finances and insurance.</span></span>
									</label>
									<label class="young">
										<input type="radio" name="stage" value="2" data-summarytext="<strong>young households</strong>" />
										<span>
											<span>Young Household</span>
											<span class="desc">Young families facing a world of firsts – first home, first child – and the responsibilities they bring.</span>
										</span>
									</label>
									<label class="established">
										<input type="radio" name="stage" value="3" data-summarytext="<strong>established households</strong>" />
										<span>
											<span>Established Household</span>
											<span class="desc">Families on the verge of entering their prime earning years, generally with roots in the community and children in their tweens/teens.</span>
										</span>
									</label>
									<label class="mature">
										<input type="radio" name="stage" value="4" data-summarytext="<strong>mature households</strong>" />
										<span>
											<span>Mature Household</span>
											<span class="desc">Families that may have adult children, the prospect of retirement on the horizon, and care for aging parents.</span>
										</span>
									</label>
									<label class="retirees">
										<input type="radio" name="stage" value="5" data-summarytext="<strong>retirees</strong>" />
										<span>
											<span>Retiree</span>
											<span class="desc">Retired customers who want to enjoy life and leave their legacy.  </span>
										</span>
									</label>
								</fieldset>

								<div class="actions">
									<ul>
										<li><a href="#need" class="btn next">Next</a></li>
									</ul>
								</div>
								
								<div class="dyk">
									<h3>Did you know?</h3>
									<p class="1">Emerging Adults generally don’t seek professional financial advice but are open to Allstate serving as a trusted financial advisor. They also tend to be more interested in growth than protection.</p>
									<p class="2">Young Households prefer individualized solutions that meet their unique needs. They are open to Allstate serving as a trusted financial advisor and have the greatest near-term growth potential because of all the &ldquo;first&rdquo; events in their lives.</p>
									<p class="3">Established Households like to be educated on financial topics but don’t like to be pressured into making decisions. They tend to prefer working with established companies they trust, like Allstate.</p>
									<p class="4">Mature Households want simple financial advice they can trust. They may have a difficult time seeing Allstate as more than a home and auto insurance provider but are open to being made aware of financial services.</p>
									<p class="5">Retirees often consult with loved ones and may need more time to make financial decisions. They have likely worked with a financial advisor before but may be interested in a second opinion on their retirement income plans.</p>
								</div><!-- close div.dyk -->
							</div><!-- close div.prompt -->
			
							<div class="prompt" id="need">
								<h2>Coverage</h2>
								<p>Why does the customer want life insurance?</p>
								<fieldset>
									<legend>Coverage</legend>
									<label>
										<input type="radio" name="need" value="1" data-summarytext="<strong>protection only</strong>" />
										<span>
											<span>Protection only</span>
											<span class="desc">The customer is focused entirely on providing a death benefit.</span>
										</span>
									</label>
									<label>
										<input type="radio" name="need" value="2" data-summarytext="<strong>protection with a savings/investment component</strong>" />
										<span>
											<span>Protection with a savings/investment component</span>
											<span class="desc"> The customer is focused on providing a death benefit but wants the ability to build cash value.</span>
										</span>
									</label>
								</fieldset>

								<div class="actions">
									<ul>
										<li><a href="#period" class="btn next">Next</a></li>
										<li><a href="#stage" class="btn back">Back</a></li>
									</ul>
								</div>
								
								<div class="dyk">
									<h3>Did you know?</h3>
									<p class="1" data-showcondition="stage=1">83% of Allstate policies purchased by Emerging Adults provide only a death benefit. These policies are typically more affordable and fit with their tight budgets.</p>
									<p class="1" data-showcondition="stage=2">Young Households may not not understand all that life insurance can do for them, like building a nest egg they can borrow against in the future.<sup><a target="_blank" href="/disclosures/#6">6</a></sup> 86% of Allstate policies purchased by Young Households provide only a death benefit.</p>
									<p class="1" data-showcondition="stage=3">While 82% of Allstate policies purchased by Established Households provide only a death benefit, they may not understand all that life insurance can do for them, like being able to borrow money from their policy to cover college expenses for their children.<sup><a target="_blank" href="/disclosures/#6">6</a></sup></p>
									<p class="1" data-showcondition="stage=4">While 70% of Allstate policies purchased by Mature Households provide only a death benefit, they may benefit from a policy with cash value growth potential that can help with expenses as they near retirement.<sup><a target="_blank" href="/disclosures/#6">6</a></sup></p>
									<p class="1" data-showcondition="stage=5">53% of Allstate retirees have life insurance that only provides a death benefit. Talk to them about their retirement income plans to determine which solutions might help them do more.</p>
									<p class="2" data-showcondition="stage=1">While only 16% of Allstate policies purchased by Emerging Adults have an investment component, this type of policy can help them protect their future while building cash value that they can borrow against if they need it.<sup><a target="_blank" href="/disclosures/#6">6</a></sup></p>
									<p class="2" data-showcondition="stage=2">While only 12% of Allstate policies purchased by Young Households have an investment component, they may not realize all the benefits of this type of policy and how it can help protect for today and grow for tomorrow.</p>
									<p class="2" data-showcondition="stage=3">While only 13% of Allstate policies purchased by Established Households have an investment component, they have the most to protect and may benefit from a policy that can provide benefits in the here and now, in addition to protecting and planning for their future.</p>
									<p class="2" data-showcondition="stage=4">64% of Pre-Retirees report they are very or somewhat concerned about their finances in the five years after retirement (Source: SOA 2013 Risks and Process of Retirement Survey). A life insurance policy with an investment component can provide an extra source of cash for use during retirement.<sup><a target="_blank" href="/disclosures/#6">6</a></sup></p>
									<p class="2" data-showcondition="stage=5">43% of Retirees report they are very or somewhat concerned about their current finances (Source: SOA 2013 Risks and Process of Retirement Survey). A life insurance policy with an investment can provide an extra source of cash for use during retirement.<sup><a target="_blank" href="/disclosures/#6">6</a></sup></p>
								</div><!-- close div.dyk -->
							</div><!-- close div.prompt -->
			
							<div class="prompt" id="period">
								<h2>Time</h2>
								<p>For how long does the customer want life insurance coverage?</p>
								<fieldset>
									<legend>Coverage Period</legend>
									<label>
										<input type="radio" name="period" value="1" data-summarytext="<strong>life</strong>" />
										<span>For life</span>
									</label>
									<label>
										<input type="radio" name="period" value="2" data-summarytext="a <strong>temporary period of time</strong>" />
										<span>For a temporary period of time</span>
									</label>
								</fieldset>
								
								<div class="actions">
									<ul>
										<li><a href="#risk" class="btn next">Next</a></li>
										<li><a href="#need" class="btn back">Back</a></li>
									</ul>
								</div>

								<div class="dyk">
									<h3>Did you know?</h3>
									<p class="1">For consumers under age 25, having guaranteed coverage for life was the top factor they considered when purchasing life insurance. (Source: LIMRA 2014 Insurance Barometer Study)</p>
									<p class="2" data-showcondition="stage=1">Emerging Adults purchase more term life insurance than any other solution because of its affordability.</p>
									<p class="2" data-showcondition="stage=2">Young Households purchase more term life insurance than any other solution because they get more coverage for their money.</p>
									<p class="2" data-showcondition="stage=3">Established Households purchase more term life insurance than any other solution but could benefit from understanding the benefits of whole life.</p>
									<p class="2" data-showcondition="stage=4">Mature Households purchase more term life insurance than any other solution but could benefit from understanding the benefits of whole life.</p>
									<p class="2" data-showcondition="stage=5">Even though age restrictions begin to limit the term periods available to Retirees, 1 out of every 6 term policies in the industry were purchased by those aged 55 and over.  (Source: LIMRA 2013 Sales Data)</p>
								</div><!-- close div.dyk -->
							</div><!-- close div.prompt -->
			
							<div class="prompt" id="risk">
								<h2>Risk</h2>
								<p>What return potential is the customer looking for within their life insurance policy?</p>
								<fieldset>
									<legend>Risk</legend>
									<label>
										<input type="radio" name="risk" value="1" data-summarytext="with <strong>higher return potential</strong> and works for customers who " />
										<span>
											<span>Higher return potential</span>
											<span class="desc">The customer is willing to accept more risk in exchange for higher upside potential.</span>
										</span>
									</label>
									<label>
										<input type="radio" name="risk" value="2" data-summarytext="with <strong>moderate return potential</strong> and works for customers who " />
										<span>
											<span>Moderate return potential</span>
											<span class="desc">The customer wants some upside potential but is looking for downside protection.</span>
										</span>
									</label>
									<label>
										<input type="radio" name="risk" value="3" data-summarytext="and works for customers who are <strong>not concerned with performance</strong> and " />
										<span>
											<span>The customer wants coverage with guarantees</span>
										</span>
									</label>
								</fieldset>

								<div class="actions">
									<ul>
										<li><a href="#payment" class="btn next">Next</a></li>
										<li><a href="#period" class="btn back">Back</a></li>
									</ul>
								</div>
								
								<div class="dyk">
									<h3>Did you know?</h3>
									<p class="1 2" data-showcondition="stage=1">LIMRA found that Emerging Adults have little tolerance for investment risk, yet this is the time when they should be more aggressive about their long-term financial goal portfolio to achieve the growth needed to reach their long-term financial goals. (Source: LIMRA survey, May 2012)</p>
									<p class="1 2" data-showcondition="stage=2">LIMRA found that Young Households have little tolerance for investment risk, yet this is the time when they should be more aggressive about their long-term financial goal portfolio to achieve the growth needed to reach their long-term financial goals. (Source: LIMRA survey, May 2012)</p>
									<p class="1 2" data-showcondition="stage=3">LIMRA found that Established Households have little tolerance for investment risk, yet this is the time when they should be more aggressive about their long-term financial goal portfolio to achieve the growth needed to reach their long-term financial goals. (Source: LIMRA survey, May 2012)</p>
									<p class="1 2" data-showcondition="stage=4">Mature Households are more likely than retirees to express concern about various retirement risks. They also express a high level of concern about depleting their savings and maintaining a reasonable standard of living (Source: SOA 2013 Risks and Process of Retirement Survey)</p>
								</div><!-- close div.dyk -->
							</div><!-- close div.prompt -->
							
							<div class="prompt" id="payment">
								<h2>Payments</h2>
								<p>Does the customer want payments that stay the same and are on a schedule, or do they prefer payment flexibility?</p>
								<fieldset>
									<legend>Schedule</legend>
									<label>
										<input type="radio" name="payment" value="1" data-summarytext="prefer <strong>premiums that stay the same</strong>" />
										<span>
											<span>Stay the same and are on a schedule</span>
											<span class="desc">Predictable premiums that don't change each month. </span>
										</span>
									</label>
									<label>
										<input type="radio" name="payment" value="2" data-summarytext="prefer <strong>flexible premiums</strong>" />
										<span>
											<span>Prefer to have more flexibility</span>
											<span class="desc">Premiums that can change based on your personal circumstances. </span>
										</span>
									</label>
								</fieldset>
								
								<div class="actions">
									<ul>
										<li><a href="" class="btn next result">See result</a></li>
										<li><a href="#risk" class="btn back">Back</a></li>
									</ul>
								</div>
				
								<div class="dyk">
									<h3>Did you know?</h3>
									<p class="1">The importance of a fixed premium price is more important to customers age 45 and older compared to their younger counterparts. (Source: LIMRA 2014 Insurance Barometer Study)</p>
									<p class="2">Older customers tend to purchase more universal life policies, which offer flexible premium payments. However, Indexed Universal Life is one of the most consistently sold products irrespective of the customer's age.</p>
								</div><!-- close div.dyk -->
							</div><!-- close div.prompt -->
				
						</div><!-- close div.prompts -->
				
					</div><!-- close div.questionnaire -->
				
				</form>
    		
    		</div>
</div><!-- close div.main -->
  
  <footer>
	<div class="footer"><div class="inner">
  <?php print render($page['footer']); ?>
  	</div></div>
  </footer>
</div>