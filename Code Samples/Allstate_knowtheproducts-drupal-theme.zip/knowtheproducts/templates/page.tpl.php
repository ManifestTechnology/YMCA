<?php
/**
 * @file
 * Returns the HTML for a single Drupal page.
 *
 * Complete documentation for this file is available online.
 * @see https://drupal.org/node/1728148
 */
?>

<div class="page" id="page">
	<div class="bg"></div>
	<?php include_once './' . drupal_get_path('theme', 'knowtheproducts') . '/includes/header.inc'; ?>

  <div class="main">
  	<?php print render($page['highlighted']); ?>
  	 <?php print $messages; ?>
  	 
      <?php print render($tabs); ?>
      <?php print render($page['help']); ?>
      <?php if ($action_links): ?>
        <ul class="action-links"><?php print render($action_links); ?></ul>
      <?php endif; ?>
      
      <?php print render($page['content']); ?>
  </div>
  
  <?php if ($page['footer']): ?>
	  <footer>
		<div class="footer"><div class="inner">
	  <?php print render($page['footer']); ?>
		</div></div>
	  </footer>
  <?php endif; ?>

</div>

<?php print render($page['bottom']); ?>
