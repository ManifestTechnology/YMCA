window.console = window.console || {log: function() {}, warn: function() {}};

var app = app || {};
app.tabs = {
    sampleConfigObject: {
        selectorForTabNavList: "ul.tabs",
        selectorForElementsToShowAndHide: "div#main div.tabContent",
        selectorForLinksToElementsToShowAndHide: "a.tabLink",
        //if this is false, the first item will not be selected & shown by default, and clicking an item a second time will hide it
        oneItemAlwaysSelected: true, 
        initializeImmediately: false
    },
    register: function (configObj) {
    	if (configObj.initializeImmediately) {
			this.init(configObj);
        }
        else {
        	var that = this;
			$(document).ready(function () {
				that.init(configObj);
			});
        }
    },
    init: function (configObj) {
        var $anchorContentElements = $(configObj.selectorForElementsToShowAndHide).hide();
        var tabNavLinksSelector = configObj.selectorForTabNavList;
        var $tabNav = $(tabNavLinksSelector);
        var $tabNavLinks = $tabNav.find('a');
        var $allLinksToAnchorContent = $(configObj.selectorForLinksToElementsToShowAndHide);
        this.handleChapterClicks($allLinksToAnchorContent, tabNavLinksSelector, $tabNavLinks, configObj.oneItemAlwaysSelected);
        this.showInitialChapter($anchorContentElements, $tabNav, configObj.oneItemAlwaysSelected);
    },
    handleChapterClicks: function ($allLinksToAnchorContent, tabNavLinksSelector, $tabNavLinks, oneItemAlwaysSelected) {
        var that = this;
        $allLinksToAnchorContent.add($tabNavLinks).click(function (e) {
            e.preventDefault();
            var link = $(this);
            var tabNavContainer = link.closest(tabNavLinksSelector);
            if (tabNavContainer.length > 0) {
                that.showChapter(link, oneItemAlwaysSelected);
            }
            else {
                //this handles link external to tab module that show/hide specific tab content pane
                $tabNavLinks.filter('a[href="' + link.attr("href") + '"]').click();
            }
        });
    },
    showChapter: function ($tabNavLink, oneItemAlwaysSelected) {
        var chapterLink = $tabNavLink.attr("href");
        var $chapter = $(chapterLink);
        if (oneItemAlwaysSelected) {
            $chapter.show().addClass("visibleTab").siblings().hide().removeClass("visibleTab");
            $tabNavLink.closest("li").addClass("selected").siblings().removeClass("selected");
        }
        else {
            $chapter.toggle().siblings().hide();
            $tabNavLink.closest("li").toggleClass("selected").siblings().removeClass("selected");
        }
        return $chapter;
    },
    getUrlHash: function ($anchorContentElements) {
        var chapterUrlHash = null;
        var hash = window.location.hash;
        if (hash) {
            var hashWithoutPoundSign = (hash.charAt(0) == "#") ? hash.substring(1) : hash;
            var hashArr = hashWithoutPoundSign.split(",");
            var chapterElementIds = [];
            $anchorContentElements.each(function (index) {
                var id = $(this).attr("id");
                if (id) {
                    chapterElementIds.push(id);
                }
            });

            for (var i = 0; i < hashArr.length; i++) {
                var hashValue = hashArr[i];
                for (var j = 0; j < chapterElementIds.length; j++) {
                    var tabContentId = chapterElementIds[j];
                    //alert("tabContentId: " + tabContentId + " hashValue: " + hashValue);
                    if (hashValue == tabContentId) {
                        return "#" + tabContentId;
                    }
                }
            }
        }
        return chapterUrlHash;
    },
    showInitialChapter: function ($anchorContentElements, $tabNavList, showFirstTab) {
        var $tabNavLinks = $tabNavList.find("a");
        var urlHash = this.getUrlHash($anchorContentElements);
        if (urlHash) {
            //window.scroll(0, 0);
            window.location.hash = "";
            $tabNavLinks.filter('a[href="' + urlHash + '"]').click();
        }
        else if (showFirstTab) {
            $tabNavList.each(function () {
                //console.log("tabNavList", this);
                $(this).find("a").first().trigger("click");
            });
        }
    }
};

app.forms = {
	init: function() {
		this.checkboxProxies.init();
		
		var that = this;
		$("div.prompts").bind("click", function(e) {
			var $elem = $(e.target);
			if ($elem.is("input:radio")) {
				that.checkboxProxies.updateProxyWithCheckboxState($elem);
			}
		});
	}, 
	checkboxProxies: {
		init: function() {
			var $checkboxes = $("input:radio");
			var that = this;
			$checkboxes.each(function() {
				var $checkbox = $(this);
				that.addProxyToDOM($checkbox);
				that.updateProxyWithCheckboxState($checkbox);
				$checkbox.bind("focus", function() {
					$(this).closest("label").addClass("focused");
				}).bind("blur", function() {
					$(this).closest("label").removeClass("focused");
				}).bind("click", function() {
					$(this).trigger("blur");
				});
			});
		}, 
		addProxyToDOM: function($checkbox) {
			var $label = $checkbox.closest("label");
			$checkbox.after("<span class=\"check\" />");
			$label.addClass("proxied");
		}, 
		updateProxyWithCheckboxState: function($checkbox) {
			if ($checkbox.prop("checked")) {
				this.getCheckboxProxy($checkbox).addClass("checked").closest("label").addClass("checked").siblings().removeClass("checked");
			}
			else {
				this.getCheckboxProxy($checkbox).removeClass("checked").closest("label").removeClass("checked");
			}
		},
		getCheckboxProxy: function($checkbox) {
			if (!$checkbox.data("proxy")) {
				$checkbox.data("proxy", $checkbox.closest("label.proxied").find("span.check:first"));
			}
			return $checkbox.data("proxy");
		}
	}
};

app.shell = {
	init: function() {
		this.menu();
		this.viewSwitchDropdown();
		this.productSupportDropdown();
	}, 
	menu: function() {
		app.tabs.register({
			selectorForTabNavList: "div.nav ul",
			selectorForElementsToShowAndHide: "div.drop",
			oneItemAlwaysSelected: false
		});
		
		//open external nav dropdown links in a new window
		$("div.nav-sections").find("a").each(function() {
			var $a = $(this);
			if ($a.attr("href").indexOf("http") == 0) {
				$a.attr("target", "_blank");
			}
		});
	}, 
	productSupportDropdown: function() {
		$("div.support").on("click", "h3.clickable", function() {
			var $elem = $(this).closest("div.support").toggleClass("expanded");
			if ($elem.hasClass("expanded")) {
				app.track.SiteCatalyst.ProductSupportDropdownClick();
			}
			
		}).find("h3").addClass("clickable").prop("tabindex", "0").on("keyup", function(e) {
			if (e.which == 13) {
				$(this).trigger("click");
			}
		});
	}, 
	viewSwitchDropdown: function() {
		$("div.viewswitch").on("click", "a.session-active", function(e) {
			var $elem = $(this).closest("div.viewswitch").toggleClass("expanded");
			if ($elem.hasClass("expanded")) {
				//app.track.SiteCatalyst.ProductSupportDropdownClick();
			}
			e.preventDefault();
		});
	}, 
	helpIE8: function() {
		//use classes for nth-child selectors. css supports both
		$("table").find("tr:nth-child(2n+1)").addClass("alt");
		$("div.progress").find("li:nth-child(2n+1)").addClass("alt");
	}
};

app.questionnaire = {
	init: function() {
		this.initializeAndOverrideTabs();
		
		var that = this;
		$("div.prompt").each(function() {
			var $container = $(this);

			var $answerOptions = $container.find("input");
			$answerOptions.on("click", function(e) {
				that.updateSelection($(this));
			});
			
			var $submitButton = $container.find("button");
			$submitButton.on("click", function(e) {
				that.processAnswers($(this));
				return false;
			});
			
			var $selectedOption = $answerOptions.filter("input:checked");
			if ($selectedOption.length) {
				that.updateSelection($selectedOption);
			}
			else {
				var $nextButton = that.getNextButton($container);
				if ($nextButton) {
					$nextButton.addClass("disabled");
				}
			}
			
		});
			
	}, 
	getSerializedForm: function($form) {
		var $form = $form || $("div.questionnaire");
		if ($form.length) {
			return $form.find("input").serialize();
		}
		return "";
	}, 
	productToURLMap: {
		"Future-Growth-IUL": "/products/futuregrowth-iul/", 
		"FutureBuilder-UL": "/products/futurebuilder-ul", 
		"Total-Accumulator-VUL": "/products/totalaccumulator-vul/", 
		"Truefit-Term": "/products/truefit/", 
		"Whole-Life-Advantage": "/products/whole-life-advantage/"
	}, 
	processAnswers: function($submit) {
		var url = "";
		
		var qs = this.getSerializedForm($submit.closest("div.questionnaire"));

		var needAnswer = app.productDetail.getQueryParamVariable('need', qs);
		var timeAnswer = app.productDetail.getQueryParamVariable('period', qs);
		var riskAnswer = app.productDetail.getQueryParamVariable('risk', qs);
		var paymentScheduleAnswer = app.productDetail.getQueryParamVariable('payment', qs);

		//period = temporary, answer is truefit
		
		//coverage = protection, answer is whole life or truefit
		
		if (needAnswer == 1 && timeAnswer == 1) {
			//coverage need = protection && coverage period = life
			url = this.productToURLMap["Whole-Life-Advantage"];
		}
		else if (timeAnswer == 2) {
			//coverage period == temporary
			url = this.productToURLMap["Truefit-Term"];
		}
		else if (needAnswer == 2) {
			//coverage need = protection + savings
			//coverage period = life

			if (riskAnswer == 1) {
				//risk tolerance = high
				url = this.productToURLMap["Total-Accumulator-VUL"];
			}
			else if (riskAnswer == 2) {
				//risk tolerance = med
				url = this.productToURLMap["Future-Growth-IUL"];
			}
			else {
				//risk = guarantee
				if (paymentScheduleAnswer == 1) {
					//payments = fixed
					url = this.productToURLMap["Whole-Life-Advantage"];
				}
				else {
					//payments = flexible
					url = this.productToURLMap["FutureBuilder-UL"];
				}
			}
		}
		url += "?" + qs;
		
		//carry over query string params
		if (window.location.search) {
			var params = window.location.search;
			if (params[0] == "?") {
				params = params.substring(1);
			}
			url += "&" + params;
		}
		
		var $prompt = $submit.closest("div.prompt");
		var $nextButton = this.getNextButton($prompt);
		if ($nextButton) {
			$nextButton.attr("href", url).off("click");
		}
	}, 
	getNextButton: function($container) {
		if (!$container.data("$nextbutton")) {
			var $nextbutton = $container.find("div.actions .next");
			$container.data("$nextbutton", $nextbutton);
		}
		return $container.data("$nextbutton");
	}, 
	initializeAndOverrideTabs: function() {
		var tabConfig = {
			selectorForTabNavList: "div.questionnaire > div.progress > ol",
			selectorForElementsToShowAndHide: "div.questionnaire div.prompts > div",
			selectorForLinksToElementsToShowAndHide: "div.actions a",
			oneItemAlwaysSelected: true, 
			initializeImmediately: true
		};
		app.tabs.register(tabConfig);

		var $tocList = $(tabConfig.selectorForTabNavList);
        var $navLinks = $tocList.children("li").children("a");
        var that = this;

        //turn off the default tabs click event (handleChapterClicks)
        //then implement this custom click event to replace showChapter
        $navLinks.off("click").on("click", function (e) {
        	var $a = $(this);
        	if ($a.closest("li").attr("data-enabled")) {
				that.showChapter($a);
				
				app.track.SiteCatalyst.ReportQuestionnaireProgress($a);
        	}

            e.preventDefault();
        });
        
        //re-initialize the currently selected chapter
        //var $currentlySelectedNavLink = $navLinks.first().parent().siblings().andSelf().filter(".selected");
        //this.showChapter($currentlySelectedNavLink);
	},
	showChapter: function($a) {
		var $chapter = app.tabs.showChapter($a);
		$a.closest("li").prevAll().attr("data-enabled", true).addClass("enabled").end().nextAll().andSelf().removeAttr("data-enabled").removeClass("enabled");
		
		var $inputs = $chapter.find("input");
		this.updateSelection($inputs);
	}, 
	updateSelection: function($input) {
		var $prompt = $input.closest("div.prompt");
		var $nextbutton = this.getNextButton($prompt);
		var $checkedInput = $input.filter(":checked");
		
		if ($checkedInput.length && $nextbutton) {
			$nextbutton.removeClass("disabled");
			this.updateSummaryText($checkedInput, $prompt);
			this.updateDidYouKnow($checkedInput, $prompt);
		}
		else {
			this.updateSummaryText($input, $prompt);
			this.updateDidYouKnow($input, $prompt);
		}
		
	}, 
	updateDidYouKnow: function($input, $prompt) {
		if (!$prompt) {
			$prompt = $input.closest("div.prompt");
		}
		
		var $didYouKnow = $prompt.find("div.dyk");		
		var $relevantDykItems = [];
		if ($input.prop("checked") && $input.val()) {
			var $dykItems = $didYouKnow.find("p");
			$relevantDykItems = $dykItems.filter("." + $input.val()).show();
			
			var $conditionalRelevantDykItems = $relevantDykItems.filter("[data-showcondition]");
			if ($conditionalRelevantDykItems.length) {
				$relevantDykItems = [];
				var qs = this.getSerializedForm($prompt.closest("div.questionnaire"));
				$conditionalRelevantDykItems.each(function() {
					var $item = $(this);
					var conditional = $item.attr("data-showcondition");
					if (app.productDetail.showConditionIsTrue(conditional, qs)) {
						$relevantDykItems = $item;
						return false;
					}
				});
			}
			
			$dykItems.not($relevantDykItems).hide();
		}

		if (!$relevantDykItems.length) {
			$didYouKnow.slideUp(400, function() {
				$(this).hide();
			});
		}
		else {
			//$didYouKnow.show();
			$didYouKnow.css("opacity", "0").slideDown(400, function() {
				$(this).fadeTo(600, 1);
			});
		}
	}, 
	updateSummaryText: function($input, $prompt) {
		var $container = $prompt.closest("div.questionnaire");
		var $selectedOptions = $prompt.prevAll().find("input:checked");
		if ($input.prop("checked")) {
			$selectedOptions = $selectedOptions.add($input);
			$container.find("div.progress").find("li.selected").next().attr("data-enabled", true);
		}
		
		var $summaryP = $container.children("div.summary").children("p");
		var summaryText = $summaryP.attr("data-dynamicsummarytext");
		$selectedOptions.each(function(i) {
			var $input = $(this);
			var optionName = $input.attr("name");
			var optionText = $input.attr("data-summarytext");
			var optionPlaceholder = "{" + optionName + "}";
			
			summaryText = summaryText.replace(optionPlaceholder, optionText);
		});
		
		var nextPlaceholderIndex = summaryText.indexOf("{");
		if (nextPlaceholderIndex > -1) {
			summaryText = summaryText.substring(0, nextPlaceholderIndex) + '<span class="placeholder">...</span>';
			$summaryP.parent().removeClass("complete");
		}
		else {
			$summaryP.parent().addClass("complete");
			this.processAnswers($input);
		}

		//$summaryP.html(summaryText).parent().show();
		$summaryP.html("<span>" + summaryText + "</span>").parent().slideDown(400);
	}
};

app.productDetail = {
	init: function() {
		this.updateBannerImage();
		this.updateAlternativeProducts();
		//this.setAnalyticsProperty(); //called directly by analytics init method
	}, 
	setAnalyticsProperty: function() {
		var lifestageValue = this.getQueryParamVariable("stage");
		if (lifestageValue) {
			var urlBeforeQs = window.location.href.split("?")[0];
			if (urlBeforeQs[urlBeforeQs.length - 1] == "/") {
				urlBeforeQs = urlBeforeQs.substring(0, urlBeforeQs.length - 1);
			}
			var slashIndex = urlBeforeQs.lastIndexOf("/");
			if (slashIndex > -1) {
				app.track.resultCode = urlBeforeQs.substring(slashIndex + 1);
			}
		}
	}, 
	lifestageParamToBannerClassMap: {
		"1": "emerging", 
		"2": "young", 
		"3": "established", 
		"4": "mature", 
		"5": "retirees"
	}, 
	updateBannerImage: function() {
		var lifestageValue = this.getQueryParamVariable("stage");
		if (lifestageValue) {
			var bannerClass = this.lifestageParamToBannerClassMap[lifestageValue];
			if (bannerClass) {
				$("div.banner").attr("class", "banner " + bannerClass);
			}
		}
	}, 
	updateAlternativeProducts: function() {
		var that = this;
		$("div.alternate").each(function(i) {
			var $container = $(this);
			var $alternativeProducts = $container.children();
			that.findAndShowAlternative($alternativeProducts, $container);
		});
		
		$("div.why").each(function(i) {
			var $container = $(this);
			that.findAndShowAlternative($container.children("p"), $container);
		});
		
		$("span.why").each(function() {
			var $container = $(this);
			var $alternatives = $container.children("span");
			that.findAndShowAlternative($alternatives, $container);
			
			if (!$container.hasClass("irrelevant")) {
				$container.show();
				
				//copy why text to overview tab, but without the alternative products introduction
				var $whyText = $container.clone().find("span.irrelevant").remove().end().html(function () {
					var html = $.trim($(this).html());
					if (html.slice(-1) == ":") {
						var sentenceEnd = html.lastIndexOf(".");
						return html.substring(0, sentenceEnd + 1);
					}
					return html;
				}).wrap("<p></p>").parent();
				
				$("#overview").find("h2").first().after($whyText);
			}
		});
	}, 
	findAndShowAlternative: function($alternatives, $container) {
		var $defaultAlternative = null;
		var selectionFound = false;
			
		var that = this;
		$alternatives.each(function() {
			var $alternative = $(this);
			var showCondition = $alternative.attr("data-showcondition");
			if (showCondition) {
				if (that.productIsDefault(showCondition)) {
					$defaultAlternative = $alternative;
				}
				else {
					if (that.showConditionIsTrue(showCondition)) {
						that.showSelectedAndHideOthers($alternative, $alternatives);
						selectionFound = true;
						return false;
					}
				}
			}
		});
		
		if (!selectionFound && $defaultAlternative) {
			that.showSelectedAndHideOthers($defaultAlternative, $alternatives);
		}
		else if (!selectionFound) {
			that.hideIrrelevantItems($alternatives, $container);
		}
	}, 
	showSelectedAndHideOthers: function($selected, $all) {
		if ($selected) {
			$selected.addClass("active");
			if ($all) {
				$all.not($selected).addClass("irrelevant");
			}
		}
	}, 
	hideIrrelevantItems: function($items, $container) {
		$items.addClass("irrelevant");
		$container.addClass("irrelevant");
	}, 
	productIsDefault: function(showCondition) {
		return (showCondition == "default");
	}, 
	showConditionIsTrue: function(showCondition, queryString) {
		var conditionStr = $.trim(showCondition);
	
		if (conditionStr) {
			if (this.queryStringContainsText(conditionStr, queryString)) {
				return true;
			}
			
			var andConditionsArray = conditionStr.split("&");
			if (andConditionsArray.length > 1) {
				var allConditionsAreTrue = true;
				for (var i = 0; i < andConditionsArray.length; i++) {
					var testCondition = andConditionsArray[i];
					if (testCondition && !this.queryStringContainsText(testCondition, queryString)) {
						allConditionsAreTrue = false;
						break;
					}
				}
				if (allConditionsAreTrue) {
					return true;
				}
				else {
					return false;
				}
			}

			var conditionArray = conditionStr.split(",");
			if (conditionArray.length > 1) {
				for (var i = 0; i < conditionArray.length; i++) {
					var condition = conditionArray[i];
					if (this.queryStringContainsText(condition, queryString)) {
						return true;
					}
				}
			}
		}
		return false;
	}, 
	
	queryStringContainsText: function(text, qs) {
		var qs = qs || window.location.search;
		if (qs.indexOf(text) > -1) {
			return true;
		}
		return false;
	}, 
	
	getQueryParamVariable: function(param, qs) {
		var url = qs || window.location.search.substring(1);
		var vars = url.split("&");
		for (var i = 0; i < vars.length; i++) {
			var pair = vars[i].split("=");
			if (pair[0] == param) {
				return pair[1];
			}
		}
		return false;
	}
};

app.riderList = {
	riderMarkup: null, 
	init: function() {
		this.initializeOverlayMarkup();
		var that = this;
		$("ul.riderlist").add("span.rider").on("click", "a", function(e) {
			var $a = $(this);
			var riderPageUrl = $a.attr("href") || "";
			var riderPageId = that.getHashValueFromUrl(riderPageUrl);
			
			if (riderPageUrl.indexOf("rider") > 0 && riderPageId) {
				that.showMask();
				if (that.riderMarkup) {
					that.showRiderInOverlay(that.riderMarkup, riderPageId);
				}
				else {
					that.showContentInOverlay('<p class="loading">Loading rider information...</p>');
					
					$.ajax({
						url: riderPageUrl, 
						cache: true, 
						success: function(data) {
							that.riderMarkup = $.trim(data);
							that.showRiderInOverlay(that.riderMarkup, riderPageId);
						},
						error: function(jqXHR, textStatus, errorThrown) {
							console.log(errorThrown);
							that.showContentInOverlay('<p class="loading">Unable to load rider information.</p>');
						}
					});
				}
				e.preventDefault();
			}
		});
	}, 
	initializeOverlayMarkup: function() {
		if (!this.markupInitialized) {
			$("body").append('<div id="overlay"></div><div id="overlayContentWrapper" class="overlayContentWrapper"><a href="#" class="close">Close</a><div id="overlayContent"></div></div>');
			var that = this;
			$("#overlay").on("click", function() {
				that.hideMask();
			});
			$("#overlayContentWrapper").on("click", "a.close", function(e) {
				that.hideMask();
				e.preventDefault();
			});
			$("body").on("keyup", function(e) {
				if (e.which == 27) {
					that.hideMask();
				}
			});
			this.markupInitialized = true;
		}
	}, 
	
	getHashValueFromUrl: function(url) {
    	if (url) {
    		var urlArr = url.split("#");
    		if (urlArr.length > 1) {
    			return urlArr[1];
    		}
    	}
    	return null;
    }, 
    showContentInOverlay: function(markup) {
		var topPosition = $(document).scrollTop() + 100;
		$("#overlayContent").html(markup).parent().css("top", topPosition).show();
	}, 
	showRiderInOverlay: function(html, riderId) {
		var $rider = $(html).find("#" + riderId);
		this.showContentInOverlay($rider);
	},
	showMask: function() {
		$("#overlay").show();
	}, 
	hideMask: function() {
		$("#overlay").hide();
		$("#overlayContentWrapper").hide();
	}
};

app.riderTable = {
    sidebarFitsInViewport: false,
    workspaceHasBeenScrolled: false,
    init: function () {
    	var $container = $("div.ridertable");
    	if ($container.length) {
    		this.initializeMarkup($container);
    		
    		var $table = $container.children("table");
    		var tableWidth = $table.outerWidth();
    		$table.css("width", tableWidth + "px");
    		
    		var $firstCell = $table.find("th").first();
    		var firstCellWidth = $firstCell.outerWidth();
    		var firstCellHeight = $firstCell.outerHeight();
    		
    		var $rowClone = $container.clone().attr("class", "clone").removeAttr("style").insertAfter($table);
    		var $colClone = $rowClone.clone().attr("class", "clone colclone").insertAfter($table);
    		var $bothClone = $rowClone.clone().attr("class", "clone bothclone").insertAfter($table);
    		
    		$rowClone.css("width", firstCellWidth + "px");
    		$colClone.css("height", firstCellHeight + "px");
    		$bothClone.css({
    			"width": firstCellWidth + "px", 
    			"height": firstCellHeight + "px"
    		});
    		
    		$container.on("scroll", function() {
    			var horizontalScrollDistance = $container.scrollLeft();
    			$rowClone.add($bothClone).css("left", horizontalScrollDistance + "px");
    			
    			var verticalScrollDistance = $container.scrollTop();
    			$colClone.add($bothClone).css("top", verticalScrollDistance + "px");
    		});
    		
    		var that = this;
    		$(window).off("resize").on("resize", function() {
				if (this.resizeTO) {
					clearTimeout(this.resizeTO);
				}
				this.resizeTO = setTimeout(function() {
					//console.log("resizeEnd");
					$(window).trigger({
						type: "resizeEnd"
					});
				}, 500);
			}).off("resizeEnd").on("resizeEnd", function() {
				that.reset();
				that.init();
			});
    	}
    }, 
    initializeMarkup: function($container) {
    	var $viewport = $(window);
		var viewportHeight = $viewport.height();
		var viewportWidth = $viewport.width();
		viewportWidth = Math.min(980, viewportWidth - 30);
		$container.css({
			"max-height": viewportHeight + "px", 
			"max-width": viewportWidth + "px"
		});
		var containerOffset = $container.offset();
		if (containerOffset && containerOffset.top) {
			var availableViewportArea = viewportHeight - containerOffset.top;
			if (availableViewportArea > 300) {
				$container.css("max-height", viewportHeight - containerOffset.top);
			}
			else if (!$("body").hasClass("short")) {
				$("body").addClass("short");
				this.initializeMarkup($container);
			}
		}
    }, 
    reset: function() {
    	$("body").removeClass("short");
    	var $container = $("div.ridertable").removeAttr("style");
    	$container.find("div.clone").remove();
    	$container.find("table").removeAttr("style");
    }
};

app.tooltip = {
	markupCacheMap: {url: "html"}, 
	init: function() {
		this.initializeMarkup();
		var that = this;
		
		var browserSupportsTouchstart = ("ontouchstart" in document.documentElement);
		if (browserSupportsTouchstart) {
			$("a.tooltip").on("click", function(e) {
				var $a = $(this);
				if ($a.is(that.visibleTooltipLink)) {
					that.hideTooltip();
					return false;
				}

				if (that.visibleTooltipLink) {
					that.hideTooltip();
				}
				that.loadAndShowTooltipContent($a);
				e.preventDefault();
			});
		}
		else {
			$("a.tooltip").on("mouseenter mouseleave focus blur", function(e) {
				if (!that.tooltipIsVisible) {
					that.loadAndShowTooltipContent($(this));
					e.preventDefault();
				}
				else {
					that.hideTooltip();
				}			
			}).on("click", function() {
				return false;
			});
		}
	}, 
	loadAndShowTooltipContent: function($a) {
		var notePageUrl = $a.attr("href");
		var noteId = "";
		
		var noteArr = notePageUrl.split("#");
		if (noteArr.length > 1) {
			noteId = noteArr[1];
			notePageUrl = noteArr[0];
		}
		
		if (this.markupCacheMap[notePageUrl]) {
			var $html = this.markupCacheMap[notePageUrl];
			var $noteContent = $html.find("#" + noteId);
			this.showTooltip($noteContent.clone(), $a);
		}
		else {
			var that = this;
			$.ajax({
				url: notePageUrl, 
				cache: true, 
				success: function(data) {
					var notePageMarkup = $.trim(data);
					var $markup = $(notePageMarkup);
					that.markupCacheMap[notePageUrl] = $markup;
					that.showTooltip($markup.find("#" + noteId).clone(), $a);
				},
				error: function(jqXHR, textStatus, errorThrown) {
					console.log(errorThrown);
					that.showTooltip('<p class="loading">Unable to load note information.</p>', $a);
				}
			});
		}
	},
	showTooltip: function(tooltipContent, $a) {
		//var tooltipContent = this.getLinkTooltipContent($a);
		if (tooltipContent) {
			var positionObj = $a.offset();
			if (positionObj) {
				var $tooltip = $("#tooltip").html(tooltipContent).show();
				var topPosition = positionObj.top - $tooltip.outerHeight() - 15;
				var leftPosition = positionObj.left;
				
				$tooltip.css({
					top: topPosition, 
					left: leftPosition
				});
				this.adjustTooltipPlacement($tooltip, $a);
			}
		}
		this.visibleTooltipLink = $a;
		this.tooltipIsVisible = true;
	}, 
	hideTooltip: function() {
		$("#tooltip").hide();
		this.visibleTooltipLink = null;
		this.tooltipIsVisible = false;
	}, 
	adjustTooltipPlacement: function($tooltip, $linkToTooltip) {
		var tooltipPos = $tooltip.offset();
		var tooltipWidth = $tooltip.outerWidth();
		var viewportWidth = $(window).outerWidth();
		if (tooltipPos && (tooltipPos.left + tooltipWidth > viewportWidth)) {
			$tooltip.addClass("onleft");
			var positionObj = $linkToTooltip.offset();
			if (positionObj) {
				var leftPosition = positionObj.left - tooltipWidth + $linkToTooltip.outerWidth();
				$tooltip.css({
					left: leftPosition
				});
			}
		}
		else {
			$tooltip.removeClass("onleft");
		}
	},
	initializeMarkup: function() {
		if (!this.markupInitialized) {
			//var $tooltip = $('<div class="tooltip"></div>');
			$("body").append('<div class="tooltip" id="tooltip"></div>');
		
			this.markupInitialized = true;
		}
	}
};

app.insightsTab = {
	init: function() {
		var $insightsPlaceholder = $("div.insightPlaceholder");
		if ($insightsPlaceholder.length) {
			var that = this;
			$.ajax({
					url: "/insights/", 
					cache: true, 
					success: function(data) {
						var html = $.trim(data);
						var $insightsHtml = $(html).find("div.insights");
						$insightsPlaceholder.before($insightsHtml).remove();
						that.hideIrrelevantInsights($insightsHtml);
					},
					error: function(jqXHR, textStatus, errorThrown) {
						console.log(errorThrown);
					}
				});
		}
	}, 
	hideIrrelevantInsights: function($insightsHtml) {
		var queryString = window.location.search.substring(1) || "";
		if (queryString) {
			var $insightBlocks = $insightsHtml.find("div[data-showcondition]");
			$insightBlocks.each(function(i) {
				var $insightBlock = $(this);
				var showConditionAttr = $insightBlock.attr("data-showcondition");
				if (app.productDetail.showConditionIsTrue(showConditionAttr)) {
					$insightBlocks.not($insightBlock).hide();
					return false;
				}
			});
		}
	}
};

app.track = {
    siteCatalystAccount: "allstateglobal,allstatemyallstatefinancial",
    siteCatalystServer: "http://alrknowtheproducts.com",
    siteChannel: "KTP",
    pageTitlePrefix: "KnowTheProducts", 
    pageTitle: "UnknownTitle", 
    resultCode: "", 
    init: function () {
        this.PageLoad();
        app.productDetail.setAnalyticsProperty();

        var that = this;
        $("body").on("click", "a", function(e) {
        	var $a = $(this);
        	if ($a.hasClass("result")) {
        		that.SiteCatalyst.CompleteQuestionnaire($a.text(), this);
        	}
            else if ($a.closest("ul.nav").length) {
            	//product detail tab clicks
            	that.ClickLink("Category_" + $a.text(), null);
            }
            else if ($a.closest("div.nav-sections").length) {
            	//header support dropdown click
            	that.SiteCatalyst.DropdownMenuClick($a);
            }
            else if ($a.closest("ul.riderlist").length) {
            	//rider tab rider click
            	that.ClickLink("Link Detail_" + $a.clone().find("sup").remove().end().text(), null);
            }
            else if ($a.is('[href$=".pdf"]')) {
            	//customer insights pdfs and product book pdfs
            	var downloadName = $a.text() || "UnknownPDF";
            	that.SiteCatalyst.FileDownload(downloadName);
            }
            else {
                //that.ClickLink($a.text(), $a.get(0));
            }
        	
        }).on("click", "div.links a", function(e) {
        	//quote tools
        	var $a = $(this);
        	if (!$a.is('[href$=".pdf"]')) {
            	//quote links
            	that.ClickLink($a.text(), this);
            }
        });
    },
    PageLoad: function () {
        var pageTitle = window.document.title;
        if (pageTitle) {
        	var siteNameDelimiter = pageTitle.lastIndexOf("|");
        	if (siteNameDelimiter > -1) {
        		pageTitle = $.trim(pageTitle.substring(0, siteNameDelimiter));
        	}
        }
        if (!pageTitle) {
            pageTitle = "Title Unknown";
        }
        this.pageTitle = this.pageTitlePrefix + "/" + pageTitle;

        //this line is called in-HTML at the bottom of the layout page
        //this.SiteCatalyst.PageLoad(this.pageTitle);
    },
    ClickLink: function (linkName, link) {
        if (linkName) {
            this.SiteCatalyst.LinkClick($.trim(linkName), link);
        }
    },
    SiteCatalyst: {
        PageLoad: function (pageName) {
            if (!pageName) {
                pageName = app.track.pageTitle;
            }
            console.log("SiteCatalyst.PageLoad: " + pageName);
            if (window.s) {
                s.pageName = pageName;
                s.server = app.track.siteCatalystServer;
                s.channel = "/" + app.track.siteChannel + "/";
                s.eVar3 = s.pageName;
                
                //explicit link tracking is implemented here so disable the auto tracking
                s.trackExternalLinks = false;
                s.trackDownloadLinks = false;

                if (app.track.resultCode) {
                	s.prop43 = app.track.resultCode;
                }
            }
        },
        FileDownload: function(downloadName) {
            console.log("SiteCatalyst.FileDownload: " + downloadName);
            if (window.s) {
            	//let the delay happen on this link since it may go to a new page (e.g., pdfs that load in-browser)
				s.linkTrackVars = "events,eVar7";
				s.linkTrackEvents = "event4";
				s.events = s.linkTrackEvents;
				s.eVar7 = downloadName;
				
				var elem = $('<a href="#">' + downloadName + "</a>").get(0);
				s.tl(elem, 'd', "File download");
				
				//clear out these vars for subsequent click events
				s.linkTrackVars = "";
				s.events = "";
				s.linkTrackEvents = "";
			}
        }, 
        ProductSupportDropdownClick: function() {
        	this.LinkClick("Header_Product Support");
        }, 
        DropdownMenuClick: function($a) {
        	if ($a) {
        		var linkName = $a.clone().find("span.ex").remove().end().find("sup").remove().end().text() || "LinkUnknown";
        		var $container = $a.closest("ul").parent();
        		var categoryName = $container.children("h3").text() || "CategoryUnknown";
        		var menuId = $container.closest("div.drop").attr("id");
        		var menuName = $("div.nav").find("a[href=#" + menuId + "]").text() || "MenuUnknown";
        		this.LinkClick("Header_" + menuName + "_" + categoryName + "_" + linkName, $a.get(0));
        	}
        }, 
        ReportQuestionnaireProgress: function($a) {
        	if ($a.length) {
        		var stepName = $a.text();
        		if (stepName) {
        			stepName = "Schedule_" + stepName.replace(/ /g, '');
        			if (!this.QuestionnaireStartEventSent) {
        				this.StartQuestionnaire(stepName, $a.get(0));
        				this.QuestionnaireStartEventSent = true;
        				return;
        			}
        			this.LinkClick(stepName, null);
        		}
        	}
        }, 
        QuestionnaireStartEventSent: false, 
        StartQuestionnaire: function(linkName, element) {
        	console.log("SiteCatalyst.StartQuestionnaire: " + linkName);
        	if (window.s) {
        		//prevent delay on this link since it is an in-page event
        		window.setTimeout(function() {
            		s.linkTrackVars = "events,prop12,prop13,prop14";
					s.linkTrackEvents = "event61";
					s.events = s.linkTrackEvents;
					s.prop12 = s.pageName;
					s.prop13 = linkName;
					s.prop14 = s.prop12 + "|" + s.prop13;
					var url = (element ? element.href : "") || "#";
					var elem = $('<a href="' + url + '">' + linkName + "</a>").get(0);
					s.tl(elem, 'o', "Click");
					
					//clear out these vars for subsequent click events
					s.linkTrackVars = "";
					s.events = "";
					s.linkTrackEvents = "";
            	}, 50);
			}
        }, 
        CompleteQuestionnaire: function(linkName, element) {
        	console.log("SiteCatalyst.CompleteQuestionnaire: " + linkName);
        	if (window.s) {
        		//let the delay happen on this link since it is going to a new page
        		s.linkTrackVars = "events,prop12,prop13,prop14";
				s.linkTrackEvents = "event62";
				s.events = s.linkTrackEvents;
				s.prop12 = s.pageName;
				s.prop13 = linkName;
				s.prop14 = s.prop12 + "|" + s.prop13;
				var url = (element ? element.href : "") || "#";
				var elem = $('<a href="' + url + '">' + linkName + "</a>").get(0);
				s.tl(elem, 'o', "Click");
			}
        }, 
        LinkClick: function (linkName, element) {
            console.log("SiteCatalyst.LinkClick: " + linkName);
            if (window.s) {
            	var overrideSiteCatalystDelay = !this.LinkLoadsNewPage(element);
            	if (overrideSiteCatalystDelay) {
            		console.log("override delay");
					var that = this;
					window.setTimeout(function() {
						that.LinkClickSiteCatalyst(linkName, element);
					}, 50);
            	}
            	else {
            		console.log("allow delay");
            		this.LinkClickSiteCatalyst(linkName, element);
            	}
            }
        }, 
        LinkClickSiteCatalyst: function(linkName, element) {
        	var url = (element ? element.href : "") || "#";
			var elem = $('<a href="' + url + '">' + linkName + "</a>").get(0);
						
        	s.linkTrackVars = "prop12,prop13,prop14";
			s.linkTrackEvents = "None";
			s.prop12 = s.pageName;
			s.prop13 = linkName;
			s.prop14 = s.prop12 + "|" + s.prop13;
			s.tl(elem, 'o', "Click");
        }, 
        LinkLoadsNewPage: function(a) {
        	if (!a || !a.tagName == "A" || !a.href || a.href == "#") {
        		return false;
        	}
        	return true;
        }
    }
};

app.init = function() {
	$("html").removeClass("no-js");
	app.tabs.register({
		selectorForTabNavList: "div.tabsContainer ul.nav",
		selectorForElementsToShowAndHide: "div.tabsContainer div.tabsContent > div",
		selectorForLinksToElementsToShowAndHide: "div.tabsContainer ul.nav a",
		oneItemAlwaysSelected: true, 
		initializeImmediately: true
	});
	
	app.shell.init();
	
	app.forms.init();
	
	app.questionnaire.init();
	
	app.productDetail.init();
	
	app.riderList.init();
	
	app.tooltip.init();
	
	app.insightsTab.init();
	
	app.riderTable.init();

	app.shell.helpIE8();
	
};

$(document).ready(function () {
	app.init();
});

app.track.init();