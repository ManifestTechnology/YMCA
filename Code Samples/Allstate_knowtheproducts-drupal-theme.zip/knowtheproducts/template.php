<?php

/**
 * Override or insert variables into the html template.
 *
 * @param $variables
 *   An array of variables to pass to the theme template.
 * @param $hook
 *   The name of the template being rendered. This is usually "html", but can
 *   also be "maintenance_page" since zen_preprocess_maintenance_page() calls
 *   this function to have consistent variables.
 */


/**
 * Preprocess variables for html.tpl.php
 *
 * @see system_elements()
 * @see html.tpl.php
 */

function knowtheproducts_js_alter(&$javascript) {
  //remove default drupal js for non-logged in users

  if (!user_is_logged_in()) {
    unset($javascript['misc/jquery.js']);
    unset($javascript['misc/jquery.once.js']);
    unset($javascript['misc/drupal.js']);
    unset($javascript['settings']);
  }
  else {
	//$javascript['misc/jquery.js']['data'] = drupal_get_path('theme', 'knowtheproducts') . '/js/jquery-1.11.1.min.js';
  }
}

function knowtheproducts_css_alter(&$css) {
  //remove default drupal css for non-logged in users

  if (!user_is_logged_in() && (current_path() !== "user/login")) {
    unset($css[drupal_get_path('module', 'system') . '/system.base.css']);
    unset($css[drupal_get_path('module', 'system') . '/system.menus.css']);
    unset($css[drupal_get_path('module', 'system') . '/system.messages.css']);
    unset($css[drupal_get_path('module', 'system') . '/system.theme.css']);
    unset($css[drupal_get_path('module', 'field') . '/theme/field.css']);
    unset($css[drupal_get_path('module', 'node') . '/node.css']);
    unset($css[drupal_get_path('module', 'search') . '/search.css']);
    unset($css[drupal_get_path('module', 'user') . '/user.css']);
    unset($css[drupal_get_path('module', 'views') . '/css/views.css']);
    unset($css[drupal_get_path('module', 'ckeditor') . '/css/ckeditor.css']);
    unset($css[drupal_get_path('module', 'ctools') . '/css/ctools.css']);
    unset($css[drupal_get_path('module', 'locale') . '/locale.css']);
  }
}
 
function knowtheproducts_preprocess_html(&$variables) {
  //add web font
  drupal_add_css('//cloud.typography.com/7570052/765066/css/fonts.css', array('type' => 'external'));

  // Compile a list of classes that are going to be applied to the body element.
  // This allows advanced theming based on context (home page, node of certain type, etc.).

  //clear out template_preprocess_html since there's cruft in it
  $variables['classes_array'] = array();
  
  // Add a class that tells us whether we're on the front page or not.
  if ($variables['is_front']) {
  	$variables['classes_array'][] = 'home';
  	return;
  }
  // Add a class that tells us whether the page is viewed by an authenticated user or not.
  //$variables['classes_array'][] = $variables['logged_in'] ? 'logged-in' : '';

  // If on an individual node page, add the node type to body classes.
  if ($node = menu_get_object()) {
  	$pageType = $node->type;
  	if ($pageType == "page" || $pageType == "rider_table") {
  		$variables['classes_array'][] = "pop";
  	}
    //$variables['classes_array'][] = drupal_html_class('node-type-' . $pageType);
  }  	
}

//this function makes page--page.tpl.php work

/*function knowtheproducts_preprocess_page(&$variables) {
    if (isset($variables['node']->type)) {
        $nodetype = $variables['node']->type;
        $variables['theme_hook_suggestions'][] = 'page__' . $nodetype;
    }
}*/

